package com.szsengel.wifichat.util

import android.net.wifi.p2p.WifiP2pDevice

/**
 * @Author: leavesCZY
 * @Desc:
 */
object WifiP2pUtils {

    fun getDeviceStatus(deviceStatus: Int): String {
        return when (deviceStatus) {
            WifiP2pDevice.AVAILABLE -> "可用的"
            WifiP2pDevice.INVITED -> "邀请中"
            WifiP2pDevice.CONNECTED -> "已连接"
            WifiP2pDevice.FAILED -> "失败的"
            WifiP2pDevice.UNAVAILABLE -> "不可用的"
            else -> "未知"
        }
    }

    // 解析 primaryDeviceType 字符串，获得类型
    fun getDeviceCategory(primaryDeviceType: String): String {
        // 验证 primaryDeviceType 是否符合特定格式：一或两位十六进制-六位十六进制-一位十六进制，例如 "10-0050F204-5"
        val regex = "^[0-9A-F]{1,2}-[0-9A-F]{8}-[0-9A-F]{1}$"
        if (!primaryDeviceType.matches(regex.toRegex())) {
            return "$primaryDeviceType 格式错误"
        }
        // 分割字符串获取各个部分
        val parts = primaryDeviceType.split("-").toTypedArray()
        // 获取类别ID（Category ID）
        val category = parts[0].uppercase()
        return when (category) {
            "1" -> "计算机"
            "6" -> "输入/输出外围设备"
            "10" -> "移动电话"
            "14" -> "网络基础设施"
            "31" -> "音频/视频设备"
            "48" -> "游戏设备"
            "63" -> "家用电器"
            else -> "未知类型"
        }
    }
}