package com.szsengel.wifichat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import androidx.annotation.RequiresApi
import com.szsengel.wifichat.util.Logger

interface DirectActionListener: WifiP2pManager.ChannelListener {
    fun wifiP2pEnabled(enabled: Boolean)
    fun onConnectionInfoAvailable(wifiP2pInfo: WifiP2pInfo)
    fun onDisconnection()
    fun onSelfDeviceAvailable(wifiP2pDevice: WifiP2pDevice)
    fun onPeersAvailable(wifiP2pDeviceList: Collection<WifiP2pDevice>)
}


class WifiP2PBroadcastReceiver(
    private val wifiP2pManager: WifiP2pManager,
    private val wifiP2pChannel: WifiP2pManager.Channel,
    private val directActionListener: DirectActionListener
): BroadcastReceiver() {

    companion object {
        private const val TAG = "WifiP2PBroadcastReceiver"
        fun getIntentFilter(): IntentFilter {
            // 设置广播接收器（BroadCast Receiver）和 P2P 管理器
            val intentFilter = IntentFilter()
            // 监听广播侦听 Wifi Direct P2P 的变化
            // 指示　Wi-Fi P2P　功能是否开启
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            // 对等节点列表发生变化
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            // 连接状态发生变化
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            // 设备的配置发生了变化
            intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
            return intentFilter
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onReceive(context: Context?, intent: Intent) {
        when (intent.action) {
            WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                val enabled = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                directActionListener.wifiP2pEnabled(enabled)
                // 如果wifi direct 功能关闭了，清理搜索列表
                if (!enabled) directActionListener.onPeersAvailable(emptyList())
                Logger.i(TAG, "Wi-Fi 直连功能 ${if (enabled) "已开启" else "已关闭"}")
            }
            WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                Logger.i(TAG, "对等节点列表发生变化，搜索开始")
                wifiP2pManager.requestPeers(wifiP2pChannel) { peers ->
                    Logger.i(TAG, "对等节点列表发生变化，搜索结束，找到  ${peers.deviceList.size} 个设备")
                    directActionListener.onPeersAvailable(peers.deviceList)
                }
            }
            WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                val networkInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                if (networkInfo?.isConnected == true) {
                    wifiP2pManager.requestConnectionInfo(wifiP2pChannel) {info ->
                        if (info != null) {
                            directActionListener.onConnectionInfoAvailable(info)
                            Logger.i(TAG, "获取到已连接设备的信息为：$info")
                        }
                        Logger.w(TAG, "获取不到已连接设备的信息")
                    }
                    Logger.i(TAG, "已连接")
                } else {
                    directActionListener.onDisconnection()
                    Logger.i(TAG, "已断开")
                }
            }
            WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                val wifiP2pDevice = intent.getParcelableExtra<WifiP2pDevice>(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE)
                if (wifiP2pDevice != null) {
                    directActionListener.onSelfDeviceAvailable(wifiP2pDevice)
                    Logger.i(TAG, "对等设备的信息有变化，更新为 $wifiP2pDevice")
                } else
                    Logger.w(TAG, "对等设备的信息有变化，但没有获取到数据")
            }
        }
    }
}