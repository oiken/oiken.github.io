package com.szsengel.wifichat

import android.graphics.ImageFormat
import android.hardware.Camera
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue

class ChatActivity : AppCompatActivity() {
    private enum class StreamDataType(val value: Int) {
        VIDEO_DATA(100),
        AUDIO_DATA(200),
        IS_FRONT_CAMERA(300),
        PLAY_AUDIO(400),
        GOOD_BYE(500),
    }

    private data class StreamData(val dataType: StreamDataType, val data: ByteArray?) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as StreamData

            if (dataType != other.dataType) return false
            if (data != null) {
                if (other.data == null) return false
                if (!data.contentEquals(other.data)) return false
            } else if (other.data != null) return false

            return true
        }

        override fun hashCode(): Int {
            var result = dataType.hashCode()
            result = 31 * result + (data?.contentHashCode() ?: 0)
            return result
        }
    }

    companion object {
        private const val TAG = "ChatActivity"
        const val INTENT_GROUP_OWNER_ADDRESS = "INTENT_GROUP_OWNER_ADDRESS"
        private const val SOCKET_PORT = 1982
        private const val SOCKET_CONNECT_TIMEOUT_SECONDS = 60 // 连接超时就退出
        private const val QUEUE_CAPACITY = 50
        private const val BYTE_LENGTH_FOR_COMMAND_TYPE = 4
        private const val COMMAND_TYPE_REPEAT_TIME = 3
        private const val VIDEO_WIDTH = 640
        private const val VIDEO_HEIGHT = 480
        private const val VIDEO_FRAME_RATE = 30
        private const val VIDEO_TIMEOUT_US = 10000L
        private const val AUDIO_SAMPLE_RATE = 16000
        private const val AUDIO_CHANNEL_CONFIG_IN = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_CHANNEL_CONFIG_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val AUDIO_STREAM_TYPE = AudioManager.STREAM_MUSIC
    }

    private val socketScope = CoroutineScope(Dispatchers.Default + Job())
    private val commandScope = CoroutineScope(Dispatchers.Default + Job())
    private var isExecutingCommand = false
    private var serverSocket: ServerSocket? = null
    private var socket: Socket? = null
    private val sendDataQueue = LinkedBlockingQueue<StreamData>(QUEUE_CAPACITY)
    private val receivedVideoQueue = LinkedBlockingQueue<ByteArray>(QUEUE_CAPACITY)
    private val receivedAudioQueue = LinkedBlockingQueue<ByteArray>(QUEUE_CAPACITY)
    private val receivedCommandQueue = LinkedBlockingQueue<StreamData>(QUEUE_CAPACITY)
    private var isSocketConnecting = false

    private val videoEncodeScope = CoroutineScope(Dispatchers.Default + Job())
    private val videoDecodeScope = CoroutineScope(Dispatchers.Default + Job())
    private var camera: Camera? = null
    private var isFrontCamera = true
    private var isReceivedDataFrontCamera = true
    private var videoEncoder: MediaCodec? = null
    private var videoDecoder: MediaCodec? = null

    private val audioRecordScope = CoroutineScope(Dispatchers.Default + Job())
    private val audioPlayScope = CoroutineScope(Dispatchers.Default + Job())
    private var recordBufferSize: Int = 0
    private var playBufferSize: Int = 0
    private var audioRecord: AudioRecord? = null
    private var audioRecordBufferSize = 0
    private var isAudioRecording = false
    private var audioTrack: AudioTrack? = null
    private var audioPlayBufferSize = 0
    private var isAudioPlaying = false

    private lateinit var svSmall: SurfaceView
    private lateinit var svBig: SurfaceView
    private var isServer = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_chat)

        recordBufferSize = AudioRecord.getMinBufferSize(AUDIO_SAMPLE_RATE, AUDIO_CHANNEL_CONFIG_IN, AUDIO_FORMAT)
        if (recordBufferSize == AudioRecord.ERROR_BAD_VALUE || recordBufferSize == AudioRecord.ERROR) {
            recordBufferSize = 2048
            Log.w(TAG, "获取 AudioRecord 缓冲区大小失败，使用默认值: $recordBufferSize")
        }
        audioRecordBufferSize = recordBufferSize // 初始化 audioRecordBufferSize

        playBufferSize = AudioTrack.getMinBufferSize(AUDIO_SAMPLE_RATE, AUDIO_CHANNEL_CONFIG_OUT, AUDIO_FORMAT)
        if (playBufferSize == AudioTrack.ERROR_BAD_VALUE || playBufferSize == AudioTrack.ERROR) {
            playBufferSize = 2048
            Log.w(TAG, "获取 AudioTrack 缓冲区大小失败，使用默认值: $playBufferSize")
        }

        audioPlayBufferSize = playBufferSize
        audioTrack = AudioTrack(
            AUDIO_STREAM_TYPE,
            AUDIO_SAMPLE_RATE,
            AUDIO_CHANNEL_CONFIG_OUT,
            AUDIO_FORMAT,
            audioPlayBufferSize,
            AudioTrack.MODE_STREAM
        )
        if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
            showToast("AudioTrack 初始化失败", true)
        }

        val btnReturn = findViewById<MaterialButton>(R.id.btnReturn)
        btnReturn.setOnClickListener {
            sendCommand(StreamDataType.GOOD_BYE)
            Handler(Looper.getMainLooper()).postDelayed({
                isSocketConnecting = false
                finish()
            }, 1000)
        }

        val btnChangeCamera = findViewById<MaterialButton>(R.id.btnChangeCamera)
        btnChangeCamera.setOnClickListener {
            isFrontCamera = !isFrontCamera
            stopCamera()
            startCamera(null)
            sendCommand(StreamDataType.IS_FRONT_CAMERA, if (isFrontCamera) 1 else 0)
        }

        val btnListenToMe = findViewById<MaterialButton>(R.id.btnListenToMe)
        btnListenToMe.setOnClickListener {
            if (isSocketConnecting) {
                stopPlaying()
                startRecording()
                sendCommand(StreamDataType.PLAY_AUDIO)
            }
        }

        svSmall = findViewById(R.id.svSmall)
        svBig = findViewById(R.id.svBig)
        setupSurfaces()
        val address = intent.getStringExtra(INTENT_GROUP_OWNER_ADDRESS)
        isServer = address == null // 没有地址就是自己当服务器
        startSocket(address)
        startExecutingCommand()
    }

    override fun onDestroy() {
        stopExecutingCommand()
        stopRecording()
        audioRecordScope.cancel()
        stopPlaying()
        audioPlayScope.cancel()
        stopCamera()
        releaseVideoEncoder()
        videoEncodeScope.cancel()
        releaseVideoDecoder()
        videoDecodeScope.cancel()
        stopSocket()
        runCatching {
            socket?.close()
            serverSocket?.close()
        }
        socketScope.cancel()
        Log.d(TAG, "onDestroy called, resources released")
        super.onDestroy()
    }

    private fun startRecording() {
        stopRecording()
        audioRecordScope.launch {
            if (isSocketConnecting && !isAudioRecording) {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    AUDIO_SAMPLE_RATE,
                    AUDIO_CHANNEL_CONFIG_IN,
                    AUDIO_FORMAT,
                    audioRecordBufferSize
                )
                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    showToast("录音初始化失败", true)
                    stopRecording()
                    return@launch
                }
                audioRecord?.startRecording()
                isAudioRecording = true
                val buffer = ByteArray(recordBufferSize)
                while (isAudioRecording && audioRecord != null) {
                    if (audioRecord!!.state == AudioRecord.STATE_INITIALIZED
                        && (audioRecord!!.recordingState == AudioRecord.RECORDSTATE_RECORDING)
                    ) {
                        val readSize = audioRecord?.read(buffer, 0, recordBufferSize) ?: 0
                        if (readSize > 0) {
                            sendDataQueue.offer(StreamData(StreamDataType.AUDIO_DATA, buffer.copyOf(readSize)))
                            continue
                        }
                    }
                    delay(1000)
                }
            }
        }
    }

    private fun stopRecording() {
        isAudioRecording = false
        try {
            audioRecord?.stop()
        } catch (e: Throwable) {
            Log.w(TAG, "释放 AudioRecord 时报错：$e")
        }
        audioRecord?.release()
        audioRecord = null
    }

    private fun startPlaying() {
        stopPlaying()
        audioPlayScope.launch {
            if (isSocketConnecting && !isAudioPlaying) {
                isAudioPlaying = true
                audioTrack?.play()
                while (isSocketConnecting && isAudioPlaying && audioTrack != null) {
                    val data = receivedAudioQueue.take()
                    val readSize = data.size
                    if (readSize > 0 && audioTrack != null
                        && (audioTrack!!.playState == AudioTrack.PLAYSTATE_PLAYING
                                || audioTrack!!.state == AudioTrack.STATE_INITIALIZED) // 使用 AudioTrack.STATE_INITIALIZED
                    ) {
                        audioTrack?.write(data, 0, readSize)
                    }
                }
                stopPlaying()
            }
        }
    }

    private fun stopPlaying() {
        isAudioPlaying = false
        try {
            audioTrack?.stop()
        } catch (e: Throwable) {
            Log.w(TAG, "停止 AudioTrack 时报错：$e")
        }
        receivedAudioQueue.clear()
    }

    private fun intToByteArray(value: Int): ByteArray {
        val buffer = ByteBuffer.allocate(4)
        buffer.putInt(value)
        return buffer.array()
    }

    private fun intFromByteArray(byteArray: ByteArray): Int {
        if (byteArray.size < 4) {
            throw IllegalArgumentException("ByteArray 长度不足 4 位，崩溃退出")
        }
        val buffer = ByteBuffer.wrap(byteArray, 0, 4)
        return buffer.int
    }

    private fun sendCommand(command: StreamDataType, value: Int = 0) {
        val streamData = when (command) {
            StreamDataType.IS_FRONT_CAMERA -> StreamData(StreamDataType.IS_FRONT_CAMERA, intToByteArray(value))
            StreamDataType.PLAY_AUDIO -> StreamData(StreamDataType.PLAY_AUDIO, null)
            StreamDataType.GOOD_BYE -> StreamData(StreamDataType.GOOD_BYE, null)
            else -> null
        }
        streamData?.let { sendDataQueue.offer(it) }
    }

    private fun stopExecutingCommand() {
        isExecutingCommand = false
        receivedCommandQueue.clear()
        commandScope.cancel()
    }

    private fun startExecutingCommand() {
        isExecutingCommand = true
        commandScope.launch {
            runCatching {
                while (isExecutingCommand) {
                    val streamData = receivedCommandQueue.take()
                    when (streamData.dataType) {
                        StreamDataType.IS_FRONT_CAMERA -> {
                            streamData.data?.takeIf { it.size >= 4 }?.let {
                                val dataIntValue = intFromByteArray(it)
                                val isTrue = dataIntValue != 0
                                Log.e(TAG, "收到切换摄像头命令值为：$isTrue")
                                this@ChatActivity.isReceivedDataFrontCamera = isTrue
                                this@ChatActivity.initDecoder()
                            }
                        }
                        StreamDataType.PLAY_AUDIO -> {
                            if (!isAudioPlaying) {
                                this@ChatActivity.stopRecording()
                                this@ChatActivity.startPlaying()
                            }
                        }
                        StreamDataType.GOOD_BYE -> {
                            this@ChatActivity.stopSocket()
                            this@ChatActivity.showToast("对方结束通话", null)
                            this@ChatActivity.finish()
                        }
                        else -> {}
                    }
                }
            }.onFailure {
                Log.e(TAG, "startExecutingCommand 执行命令时出错：$it")
                isExecutingCommand = false
            }
        }
    }

    private suspend fun streaming(outputStream: OutputStream?, inputStream: InputStream?, isSending: Boolean) {
        val dataCommandOne = ByteArray(BYTE_LENGTH_FOR_COMMAND_TYPE)
        try {
            while (isSocketConnecting) {
                if (isSending) {
                    withContext(Dispatchers.IO) {
                        val streamData = sendDataQueue.take()
                        // 三次数据类型，避免误会
                        repeat(COMMAND_TYPE_REPEAT_TIME) {
                            val byteArrayOfValue = intToByteArray(streamData.dataType.value)
                            outputStream?.write(byteArrayOfValue)
                        }

                        val dataSize = streamData.data?.size ?: 0
                        if (streamData.dataType.value != 100)
                            Log.d(TAG, "streamData.dataType.value = ${streamData.dataType.value} && 长度=$dataSize")
                        val byteArrayOfValue = intToByteArray(dataSize)
                        outputStream?.write(byteArrayOfValue)
                        if (dataSize > 0) {
                            outputStream?.write(streamData.data)
                        }
                        outputStream?.flush()
                    }
                } else {
                    var index = COMMAND_TYPE_REPEAT_TIME
                    var previousDataType: Int? = null
                    var dataType: Int = -1
                    while (index > 0) {
                        index--
                        val readResult = withContext(Dispatchers.IO) { inputStream?.read(dataCommandOne) }
                        if (readResult != dataCommandOne.size) {
                            previousDataType = null
                            index = COMMAND_TYPE_REPEAT_TIME
                        } else {
                            dataType = intFromByteArray(dataCommandOne)
                            if (previousDataType == null || dataType != previousDataType) {
                                previousDataType = dataType
                                index = COMMAND_TYPE_REPEAT_TIME - 1
                            }
                        }
                    }
                    val readResult = withContext(Dispatchers.IO) { inputStream?.read(dataCommandOne) }
                    if (readResult == dataCommandOne.size) {
                        val dataSize = intFromByteArray(dataCommandOne)
                        val data = ByteArray(dataSize)
                        var bytesRead = 0
                        var didGetFullData = true
                        while (bytesRead < dataSize) {
                            val result = withContext(Dispatchers.IO) {
                                inputStream?.read(data, bytesRead, dataSize - bytesRead)
                            }
                            if (result == null || result == -1) {
                                didGetFullData = false
                                break
                            }
                            bytesRead += result
                        }
                        if (isSocketConnecting && didGetFullData) {
                            when (dataType) {
                                StreamDataType.VIDEO_DATA.value -> {
                                    receivedVideoQueue.offer(data)
                                }
                                StreamDataType.AUDIO_DATA.value -> {
                                    receivedAudioQueue.offer(data)
                                    Log.d(TAG, "Received audio data, size: ${data.size}")
                                }
                                StreamDataType.IS_FRONT_CAMERA.value -> receivedCommandQueue.offer(StreamData(StreamDataType.IS_FRONT_CAMERA, data))
                                StreamDataType.PLAY_AUDIO.value -> receivedCommandQueue.offer(StreamData(StreamDataType.PLAY_AUDIO, data))
                                StreamDataType.GOOD_BYE.value -> receivedCommandQueue.offer(StreamData(StreamDataType.GOOD_BYE, data))
                                else -> Log.e(TAG, "未知的命令类型: $dataType")
                            }
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            isSocketConnecting = false
            showToast("即将返回，因未知错误: $e", true)
            stopSocket()
            withContext(Dispatchers.Main) {
                this@ChatActivity.finish()
            }
        }
    }

    private suspend fun startStreaming(socket: Socket, scope: CoroutineScope, isServer: Boolean) {
        val inputStream = withContext(Dispatchers.IO) { socket.getInputStream() }
        val outputStream = withContext(Dispatchers.IO) { socket.getOutputStream() }
        if (isServer) { // 先听
            stopRecording()
            startPlaying()
            scope.launch(Dispatchers.IO) { streaming(outputStream, null, true) }
            streaming(null, inputStream, false)
        } else { // 先说
            stopPlaying()
            startRecording()
            scope.launch(Dispatchers.IO) { streaming(null, inputStream, false) }
            streaming(outputStream, null, true)
        }
    }

    private fun stopSocket() {
        isSocketConnecting = false
    }

    private fun startSocket(address: String?) {
        socketScope.launch {
            try {
                isSocketConnecting = false
                val isServer = address == null
                if (isServer) {
                    serverSocket = ServerSocket().apply {
                        bind(InetSocketAddress(SOCKET_PORT))
                        reuseAddress = true
                    }
                    socket = serverSocket?.accept()
                } else {
                    socket = Socket().apply {
                        bind(null)
                        try {
                            connect(InetSocketAddress(address, SOCKET_PORT), SOCKET_CONNECT_TIMEOUT_SECONDS * 1000)
                        } catch (e: SocketTimeoutException) {
                            showToast("连接超时，请重试: $e", true)
                            return@launch
                        }
                    }
                }
                isSocketConnecting = true
                delay(500) // 延迟初始化
                stopCamera()
                startCamera(null)
                initDecoder()
                socket?.let {
                    startStreaming(it, this, isServer)
                    sendCommand(StreamDataType.IS_FRONT_CAMERA, if (isFrontCamera) 1 else 0)
                }
            } catch (e: Throwable) {
                Log.e(TAG, "startSocket 出错：$e")
                showToast("连接出错：$e", true)
            } finally {
                runCatching {
                    socket?.close()
                    serverSocket?.close()
                }
                withContext(Dispatchers.Main) {
                    this@ChatActivity.finish()
                }
            }
        }
    }

    private fun nv21ToNv12(nv21: ByteArray, nv12: ByteArray, width: Int, height: Int) {
        val frameSize = width * height
        System.arraycopy(nv21, 0, nv12, 0, frameSize)
        var i = 0
        while (i < frameSize / 2) {
            nv12[frameSize + i] = nv21[frameSize + i + 1]
            nv12[frameSize + i + 1] = nv21[frameSize + i]
            i += 2
        }
    }

    private fun encodeVideoData(nv21Data: ByteArray) {
        videoEncodeScope.launch {
            runCatching {
                val encoder = videoEncoder
                if (encoder == null) {
                    Log.e(TAG, "videoEncoder is null, cannot encode video data")
                    return@launch
                }
                val nv12Data = ByteArray(nv21Data.size)
                nv21ToNv12(nv21Data, nv12Data, VIDEO_WIDTH, VIDEO_HEIGHT)
                val inputBufferIndex = encoder.dequeueInputBuffer(VIDEO_TIMEOUT_US)
                if (inputBufferIndex >= 0) {
                    val inputBuffers = encoder.inputBuffers
                    val inputBuffer = inputBuffers[inputBufferIndex]
                    inputBuffer?.clear()
                    inputBuffer?.put(nv12Data)
                    encoder.queueInputBuffer(
                        inputBufferIndex, 0, nv12Data.size,
                        System.nanoTime() / 1000, 0
                    )
                }

                val bufferInfo = MediaCodec.BufferInfo()
                var outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, VIDEO_TIMEOUT_US)
                while (outputBufferIndex >= 0) {
                    val outputBuffers = encoder.outputBuffers
                    val outputBuffer = outputBuffers[outputBufferIndex]
                    outputBuffer?.let {
                        val encodedData = ByteArray(bufferInfo.size)
                        it.get(encodedData)
                        val streamData = StreamData(StreamDataType.VIDEO_DATA, encodedData)
                        sendDataQueue.offer(streamData)
                    }
                    encoder.releaseOutputBuffer(outputBufferIndex, false)
                    outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, VIDEO_TIMEOUT_US)
                }
            }.onFailure {
                Log.e(TAG, "encodeVideoData 出错：$it")
            }
        }
    }

    private fun startDecoding() {
        videoDecodeScope.launch {
            runCatching {
                while (isActive && isSocketConnecting) {
                    val encodedData = receivedVideoQueue.take()
                    val inputBufferIndex = videoDecoder?.dequeueInputBuffer(VIDEO_TIMEOUT_US) ?: -1
                    if (inputBufferIndex >= 0) {
                        val inputBuffers = videoDecoder?.inputBuffers
                        val inputBuffer = inputBuffers?.get(inputBufferIndex)
                        inputBuffer?.clear()
                        inputBuffer?.put(encodedData)
                        videoDecoder?.queueInputBuffer(
                            inputBufferIndex, 0, encodedData.size,
                            System.nanoTime() / 1000, 0
                        )
                    }

                    val bufferInfo = MediaCodec.BufferInfo()
                    var outputBufferIndex = videoDecoder?.dequeueOutputBuffer(bufferInfo, VIDEO_TIMEOUT_US) ?: -1
                    while (outputBufferIndex >= 0) {
                        videoDecoder?.releaseOutputBuffer(outputBufferIndex, true)
                        outputBufferIndex = videoDecoder?.dequeueOutputBuffer(bufferInfo, VIDEO_TIMEOUT_US) ?: -1
                    }
                }
            }.onFailure {
                Log.e(TAG, "startDecoding 出错：$it")
            }
        }
    }

    private fun releaseVideoEncoder() {
        videoEncoder?.apply {
            stop()
            release()
        }
        videoEncoder = null
    }

    private fun initEncoder() {
        try {
            val mimeType = "video/avc"
            val encoder = MediaCodec.createEncoderByType(mimeType)
            val format = MediaFormat.createVideoFormat(
                mimeType,
                VIDEO_WIDTH, VIDEO_HEIGHT
            )
            format.setInteger(MediaFormat.KEY_BIT_RATE, 1500000)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FRAME_RATE)
            format.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
            )
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            videoEncoder = encoder
        } catch (e: Exception) {
            Log.e(TAG, "初始化视频编码器出错：$e")
            videoEncoder = null
        }
    }

    private fun setRotation(format: MediaFormat, rotation: Int) {
        try {
            val keyRotationField = MediaFormat::class.java.getField("KEY_ROTATION")
            val keyRotation = keyRotationField.get(null) as String
            format.setInteger(keyRotation, rotation)
        } catch (e: Exception) {
            Log.e(TAG, "setRotation 出错：$e")
        }
    }

    private fun releaseVideoDecoder() {
        receivedVideoQueue.clear()
        runCatching {
            videoDecoder?.apply {
                stop()
                release()
            }
            videoDecoder = null
        }.onFailure {
            Log.e(TAG, "releaseDecoder 出错：$it")
        }
    }

    private fun initDecoder() {
        releaseVideoDecoder()
        try {
            val mimeType = "video/avc"
            videoDecoder = MediaCodec.createDecoderByType(mimeType).apply {
                val format = MediaFormat.createVideoFormat(
                    mimeType,
                    VIDEO_WIDTH, VIDEO_HEIGHT
                )
                if (isReceivedDataFrontCamera) {
                    setRotation(format, -90)
                } else {
                    setRotation(format, 90)
                }
                configure(format, svBig.holder.surface, null, 0)
                start()
            }
            startDecoding()
        } catch (e: Exception) {
            Log.e(TAG, "initDecoder 出错：$e")
        }
    }

    private fun getCorrectCameraOrientation(cameraInfo: Camera.CameraInfo): Int {
        val rotation = windowManager.defaultDisplay.rotation
        val degrees = when (rotation) {
            Surface.ROTATION_0 -> 0
            Surface.ROTATION_90 -> 90
            Surface.ROTATION_180 -> 180
            Surface.ROTATION_270 -> 270
            else -> 0
        }
        return if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            (360 - (cameraInfo.orientation + degrees) % 360) % 360
        } else {
            when (rotation) {
                Surface.ROTATION_0 -> (cameraInfo.orientation + 90) % 360 // 竖屏时，后置摄像头旋转 90 度
                Surface.ROTATION_90 -> (cameraInfo.orientation + 0) % 360 // 横屏时，后置摄像头旋转 0 度
                Surface.ROTATION_180 -> (cameraInfo.orientation + 270) % 360 // 倒竖屏时，后置摄像头旋转 270 度
                Surface.ROTATION_270 -> (cameraInfo.orientation + 180) % 360 // 反横屏时，后置摄像头旋转 180 度
                else -> 0
            }
        }
    }

    private fun stopCamera() {
        runCatching {
            camera?.apply {
                setPreviewCallback(null)
                stopPreview()
                release()
            }
            camera = null
        }.onFailure {
            Log.e(TAG, "stopCamera 出错：$it")
        }
    }

    private fun startCamera(surfaceHolder: SurfaceHolder?) {
        runCatching {
            val cameraInfo = Camera.CameraInfo()
            if (isFrontCamera) {
                Camera.getCameraInfo(Camera.CameraInfo.CAMERA_FACING_FRONT, cameraInfo)
                camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT)
            } else {
                camera = Camera.open()
            }
            camera?.apply {
                val params = parameters
                val orientation = getCorrectCameraOrientation(cameraInfo)
                setDisplayOrientation(orientation)
                params.setPreviewSize(VIDEO_WIDTH, VIDEO_HEIGHT)
                params.previewFormat = ImageFormat.NV21
                parameters = params
                if (surfaceHolder != null)
                    setPreviewDisplay(surfaceHolder)
                else {
                    val sv = if (isSocketConnecting) svSmall else svBig
                    setPreviewDisplay(sv.holder)
                }
                if (isSocketConnecting) initEncoder()
                setPreviewCallback { data, _ ->
                    if (isSocketConnecting) {
                        encodeVideoData(data)
                    }
                }
                startPreview()
                Log.d(TAG, "Camera started, isFrontCamera: $isFrontCamera")
            }
        }.onFailure {
            Log.e(TAG, "startCamera 出错：$it")
        }
    }

    private fun setupSurfaces() {
        svSmall.setZOrderMediaOverlay(true)
        svSmall.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                if (isSocketConnecting) {
                    startCamera(holder)
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                if (isSocketConnecting) {
                    stopCamera()
                    startCamera(holder)
                }
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (isSocketConnecting) {
                    stopCamera()
                }
            }
        })

        svBig.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                if (!isSocketConnecting) {
                    startCamera(holder)
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                if (!isSocketConnecting) {
                    stopCamera()
                    startCamera(holder)
                }
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (!isSocketConnecting) {
                    stopCamera()
                }
            }
        })
    }

    private fun showToast(msg: String, isError: Boolean?) {
        runOnUiThread {
            when (isError) {
                null -> Log.i(TAG, msg)
                true -> Log.e(TAG, msg)
                false -> Log.w(TAG, msg)
            }
            val isLongShow = when (isError) {
                true -> Toast.LENGTH_LONG
                else -> Toast.LENGTH_SHORT
            }
            if (isSocketConnecting) { // 没有连接就不报错，因为断开连接就要退出聊天界面了
                Toast.makeText(this@ChatActivity, msg, isLongShow).show()
            }
        }
    }
}
