package com.szsengel.wifichat

import android.net.wifi.p2p.WifiP2pDevice
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.szsengel.wifichat.databinding.WifiP2pItemPeerBinding
import com.szsengel.wifichat.util.WifiP2pUtils

class PeerAdapter(private val items: List<WifiP2pDevice>, private val onItemClickListener: OnItemClickListener) : RecyclerView.Adapter<PeerAdapter.ViewHolder>() {

    interface OnItemClickListener {
        fun onClicked(wifiP2pDevice: WifiP2pDevice)
    }

    class ViewHolder(binding: WifiP2pItemPeerBinding) : RecyclerView.ViewHolder(binding.root) {
        val tvName: TextView = binding.tvName
        val tvStatus: TextView = binding.tvStatus
        val tvType: TextView = binding.tvType
        val tvAddress: TextView = binding.tvAddress
        val tvIsGroupOwner : TextView = binding.tvIsGroupOwner
        val btnConnect: MaterialButton = binding.btnConnect
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = WifiP2pItemPeerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvName.text = "名字：${items[position].deviceName}"
        holder.tvStatus.text = "状态：${WifiP2pUtils.getDeviceStatus(items[position].status)}"
        val isGroupOwner = items[position].isGroupOwner
        holder.tvIsGroupOwner.text = "群组所有者：${if (isGroupOwner) "是的" else "不是的"}"
        holder.tvType.text = "类型：${WifiP2pUtils.getDeviceCategory(items[position].primaryDeviceType)}"
        holder.tvAddress.text = "地址：${items[position].deviceAddress}"
        holder.btnConnect.visibility = if (isGroupOwner) View.VISIBLE else View.GONE
        holder.btnConnect.setOnClickListener {
            onItemClickListener.onClicked(items[position])
        }
    }

    override fun getItemCount(): Int = items.size
}