package com.szsengel.wifichat.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Logger {
    private fun getCurrentMilliSecond() : String {
        val currentTimeMilliSecond = System.currentTimeMillis()
        val date = Date(currentTimeMilliSecond)
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
        return sdf.format(date)
    }

    fun d(tag: String, msg: Any?) : String {
        val timeString = getCurrentMilliSecond()
        val newMsg = "$timeString 调试：${msg?.toString() ?: "无"}"
        Log.d(tag, newMsg)
        return newMsg
    }

    fun i(tag: String, msg: Any?) : String{
        val timeString = getCurrentMilliSecond()
        val newMsg = "$timeString ${msg?.toString() ?: "无信息"}"
        Log.i(tag, newMsg)
        return newMsg
    }

    fun w(tag: String, msg: Any?): String {
        val timeString = getCurrentMilliSecond()
        val newMsg = "$timeString 警告：${msg?.toString() ?: "无信息"}"
        Log.w(tag, newMsg)
        return newMsg
    }

    fun e(tag: String, msg: Any?): String {
        val timeString = getCurrentMilliSecond()
        val newMsg = "$timeString 出错：${msg?.toString() ?: "但无信息"}"
        Log.e(tag, newMsg)
        return newMsg
    }
}