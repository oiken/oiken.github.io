package com.szsengel.wifichat

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.button.MaterialButton
import com.szsengel.wifichat.util.WifiP2pUtils

class WifiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wifi)
        initWifiP2p()
        discover() // 里面有停止刷新动画的语句
    }

    // Wifi Direct P2P
    private val peers = mutableListOf<WifiP2pDevice>()
    private val peerAdapter by lazy { // 因为这个比 wifiP2pDeviceList 的初始化提前了，所以用 lazy
        PeerAdapter(peers, object: PeerAdapter.OnItemClickListener {
            override fun onClicked(wifiP2pDevice: WifiP2pDevice) {
                this@WifiActivity.connectGroupOwner(wifiP2pDevice)
            }
        })
    }
    private lateinit var wifiP2pManager: WifiP2pManager
    private lateinit var wifiP2PChannel: WifiP2pManager.Channel
    private var wifiP2pBroadcastReceiver: BroadcastReceiver? = null
    private var wifiP2pEnabled = false
    private var wifiP2pInfo: WifiP2pInfo? = null
    // wifi p2p 属性之监听回调
    private val directActionListener = object: DirectActionListener {
        override fun wifiP2pEnabled(enabled: Boolean) {
            wifiP2pEnabled = enabled
        }

        override fun onConnectionInfoAvailable(wifiP2pInfo: WifiP2pInfo) {
            peerAdapter.notifyItemRangeRemoved(0, peers.size) // 先告诉 peerAdapter 我要删除哪些
            peers.clear() // 再真的删除
            this@WifiActivity.wifiP2pInfo = wifiP2pInfo
            if (wifiP2pInfo.groupFormed && !wifiP2pInfo.isGroupOwner) {
                val address = wifiP2pInfo.groupOwnerAddress?.hostAddress
                if (!address.isNullOrBlank()) {
                    this@WifiActivity.startChatActivity(address)
                }
            }
        }

        override fun onDisconnection() { // 用户主动断开连接，或如网络问题，或对方设备断开连接
            peerAdapter.notifyItemRangeRemoved(0, peers.size)
            peers.clear()
            wifiP2pInfo = null
        }

        override fun onSelfDeviceAvailable(wifiP2pDevice: WifiP2pDevice) {
            val strBuffer = StringBuffer()
            strBuffer.append("本设备名称: " + wifiP2pDevice.deviceName)
            strBuffer.append("        状态: " + WifiP2pUtils.getDeviceStatus(wifiP2pDevice.status))
            strBuffer.append("\n地址: " + wifiP2pDevice.deviceAddress)
            val tvContent = findViewById<TextView>(R.id.tvContent)
            tvContent.text = strBuffer.toString()
        }

        // 主动搜索可以快速收到这个通知，如果设备创建或移除了自己的群组，隔一段时间会收到新的数据
        override fun onPeersAvailable(wifiP2pDeviceList: Collection<WifiP2pDevice>) {
            this@WifiActivity.peerAdapter.notifyItemRangeRemoved(0, peers.size)
            this@WifiActivity.peers.clear()
            this@WifiActivity.peers.addAll(wifiP2pDeviceList)
            this@WifiActivity.peerAdapter.notifyItemRangeInserted(0, peers.size)
        }

        override fun onChannelDisconnected() { // WifiP2pManager 服务与应用程序之间的通信通道意外断开时，因为服务崩溃或其他系统级别的问题导致通道关闭。
        }
    }

    private fun createGroup() {
        stopDiscovering(true)
        removeGroup()
        if (checkPermission()) {
            wifiP2pManager.createGroup(wifiP2PChannel, object: WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    showToast("成功创建群组")
                    startChatActivity(null)
                }

                override fun onFailure(reason: Int) {
                    val reasonStr = wifiP2pReasonToString(reason)
                    showToast("创建群组失败，因为：$reasonStr")
                }
            })
        }
    }

    private fun removeGroup() {
        wifiP2pManager.removeGroup(wifiP2PChannel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { }

            override fun onFailure(reason: Int) {
                val msg = wifiP2pReasonToString(reason)
                showToast(msg)
            }
        })
    }

    private fun connectGroupOwner(wifiP2pDevice: WifiP2pDevice) {
        val wifiP2pConfig = WifiP2pConfig()
        wifiP2pConfig.deviceAddress = wifiP2pDevice.deviceAddress
        wifiP2pConfig.wps.setup = WpsInfo.PBC
        wifiP2pManager.connect(
            wifiP2PChannel, wifiP2pConfig,
            object: WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    showToast("连接群组成功，等待对方接受")
                }

                override fun onFailure(reason: Int) {
                    val reasonStr = wifiP2pReasonToString(reason)
                    showToast("连接群组失败，$reasonStr")
                }
            }
        )
    }

    private fun disconnect() {
        wifiP2pManager.cancelConnect(wifiP2PChannel, object: WifiP2pManager.ActionListener {
            override fun onSuccess() { }
            override fun onFailure(reason: Int) { }
        })
    }

    // 定义 ActivityResultLauncher
    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        val btnCreateGroup = findViewById<MaterialButton>(R.id.btnCreateGroup)
        btnCreateGroup.text = getString(R.string.btn_create_group)
        val sflPeers = findViewById<SwipeRefreshLayout>(R.id.sflPeers)
        sflPeers.isRefreshing = true
        discover()
    }

    fun startChatActivity(address: String?) { // 启动第二个 Activity
        val intent = Intent(this@WifiActivity, ChatActivity::class.java)
        if (address != null) {
            intent.putExtra(ChatActivity.INTENT_GROUP_OWNER_ADDRESS, address)
        }
        launcher.launch(intent)
    }

    private fun discover() {
        disconnect()
        removeGroup()
        stopDiscovering(false)
        if (checkPermission()) { // 只在不确定具体变化或需要完全重绘时才使用 notifyDataSetChanged()，类似这里用 notifyItemRangeRemoved
            peerAdapter.notifyItemRangeRemoved(0, peers.size)
            peers.clear()
            wifiP2pManager.discoverPeers(wifiP2PChannel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    showToast("搜索完毕")
                    stopRefreshAnimation()
                }

                override fun onFailure(reason: Int) {
                    val reasonStr = wifiP2pReasonToString(reason)
                    showToast("搜索失败，$reasonStr")
                    stopRefreshAnimation()
                }
            })
        }
    }

    private fun stopDiscovering(stopAnimating: Boolean) {
        if (stopAnimating) {
            stopRefreshAnimation()
        }
        wifiP2pManager.stopPeerDiscovery(wifiP2PChannel, object: WifiP2pManager.ActionListener {
            override fun onSuccess() {}

            override fun onFailure(reason: Int) {
                val reasonStr = wifiP2pReasonToString(reason)
                showToast("停止搜索失败，$reasonStr")
            }
        })
    }

    private fun stopRefreshAnimation() { // 停止刷新动画
        val sflPeers = findViewById<SwipeRefreshLayout>(R.id.sflPeers)
        sflPeers.isRefreshing = false
    }

    private fun wifiP2pReasonToString(reason: Int) : String {
        val resultStr: String = when (reason) {
            WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi P2P 不被支持，检测到 wifi 是 ${ if (wifiP2pEnabled) "打开" else "关闭" } 的。请打开 GPS 再试"
            WifiP2pManager.ERROR -> "原因不明"
            WifiP2pManager.BUSY -> "Wi-Fi P2P 服务正忙，请稍后再试"
            else -> "未知错误码：$reason"
        }
        return resultStr
    }

    private fun initWifiP2p() {
        val rvPeers = findViewById<RecyclerView>(R.id.rvPeers)
        rvPeers.layoutManager = LinearLayoutManager(this)
        val dividerItemDeprecation = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        rvPeers.addItemDecoration(dividerItemDeprecation) // 设置 分割线
        rvPeers.adapter = peerAdapter // 设置数据源
        val sflPeers = findViewById<SwipeRefreshLayout>(R.id.sflPeers)
        sflPeers.setOnRefreshListener {
            discover()
        }
        val btnCreateGroup = findViewById<MaterialButton>(R.id.btnCreateGroup)
        btnCreateGroup.setOnClickListener {
            createGroup()
        }
        // 初始化 WifiP2p
        // 检查设备是否支持 Wi-Fi P2P 功能，并且获取服务实例
        val mWifiP2pManager = getSystemService(WIFI_P2P_SERVICE) as? WifiP2pManager
        if (mWifiP2pManager == null) { // 设备不支持 Wi-Fi P2P，则结束 Activity
            showToast("您的设备不支持 Wi-Fi Direct P2P，退出")
            finish()
        } else { // 服务可用
            wifiP2pManager = mWifiP2pManager // 赋值给成员变量
            wifiP2PChannel = wifiP2pManager.initialize(this, mainLooper, directActionListener)
            wifiP2pBroadcastReceiver =
                WifiP2PBroadcastReceiver(wifiP2pManager, wifiP2PChannel, directActionListener)
            ContextCompat.registerReceiver(
                this,
                wifiP2pBroadcastReceiver,
                WifiP2PBroadcastReceiver.getIntentFilter(),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
    }

    // 权限申请
    private val requestedPermissionOfWifiP2p = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.ACCESS_NETWORK_STATE)
        // 常用权限，不用申请 add(Manifest.permission.CHANGE_NETWORK_STATE)
        add(Manifest.permission.ACCESS_WIFI_STATE)
        add(Manifest.permission.CHANGE_WIFI_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        add(Manifest.permission.RECORD_AUDIO)
    }.toTypedArray()

    private fun allPermissionGranted(): Boolean {
        requestedPermissionOfWifiP2p.forEach {
            if (ActivityCompat.checkSelfPermission(this, it) !=
                PackageManager.PERMISSION_GRANTED)
            {
                return false
            }
        }
        return true
    }

    private val requestPermissionLaunch = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { it ->
        if (it.all { it.value })
            showToast("已获得权限，请再次点击按钮")
        else
            showToast("请授予权限，才能开始")
    }

    private fun checkPermission(): Boolean {
        if (allPermissionGranted()) { // 检查和索取权限
            return true
        } else {
            requestPermissionLaunch.launch(requestedPermissionOfWifiP2p)
            return false
        }
    }

    // 辅助函数
    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}