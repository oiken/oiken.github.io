use crate::warn;
use anyhow::{bail, Result};
use chrono::TimeZone as _;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

pub struct Timestamp;

impl Timestamp {
    pub fn nanos_to_local_string(nanos: i64, with_subsec_nanos: bool) -> Result<String> {
        // 将纳秒转换为秒和纳秒部分
        let seconds = nanos / 1_000_000_000;
        let subsec_nanos = if with_subsec_nanos {
            (nanos % 1_000_000_000) as u32
        } else {
            0
        };
        Self::timestamp_to_local_string(seconds, subsec_nanos, with_subsec_nanos)
    }

    pub fn seconds_to_local_string(seconds: i64) -> Result<String> {
        Self::timestamp_to_local_string(seconds, 0, false)
    }

    pub fn timestamp_to_local_string(
        seconds: i64,
        subsec_nanos: u32,
        with_nano_seconds: bool,
    ) -> Result<String> {
        // 使用 NaiveDateTime 创建日期时间对象
        let local_datetime = match chrono::Local.timestamp_opt(seconds, subsec_nanos) {
            chrono::offset::LocalResult::Single(local) => local,
            chrono::offset::LocalResult::Ambiguous(_earliest, latest) => latest,
            chrono::offset::LocalResult::None => {
                let msg = format!(
                    "警告：转换时间戳失败，参数 seconds= {}, subsec_nanos= {}",
                    seconds, subsec_nanos
                );
                warn!("{}", msg);
                bail!(msg);
            }
        };
        // 转换为 UTC 时间
        //let datetime = local_datetime.format("%Y-%m-%d %H:%M:%S%.f").to_string();
        // 手动构建包含毫秒、微秒和纳秒的时间字符串
        let local_datetime_str = if with_nano_seconds {
            format!(
                "{} {:03}.{:03}.{:03}",
                local_datetime.format("%Y-%m-%d %H:%M:%S"),
                subsec_nanos / 1_000_000,
                (subsec_nanos % 1_000_000) / 1_000,
                subsec_nanos % 1_000
            )
        } else {
            local_datetime.format("%Y-%m-%d %H:%M:%S").to_string()
        };
        Ok(local_datetime_str)
    }

    pub fn i64_to_system_time(secs: i64) -> SystemTime {
        if secs >= 0 {
            UNIX_EPOCH + Duration::from_secs(secs as u64)
        } else {
            UNIX_EPOCH - Duration::from_secs((-secs) as u64)
        }
    }

    pub fn system_time_to_i64(time: SystemTime) -> i64 {
        match time.duration_since(UNIX_EPOCH) {
            Ok(duration) => duration.as_secs() as i64,
            Err(e) => {
                // 处理时间在 UNIX纪元之前的情况
                let duration = e.duration();
                -(duration.as_secs() as i64)
            }
        }
    }
}
