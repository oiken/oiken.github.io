use crate::yyw::user_agent_cookie::UserAgentCookie;
use anyhow::{bail, Result};
use chrono::Local;
use serde::{Deserialize, Serialize};
use std::{net::SocketAddr, path::PathBuf};
use thiserror::Error;
use tokio::{net::TcpListener, sync::RwLock};

lazy_static::lazy_static! {
    // 测试时用旧 cookie 测试失败情况，更新 cookie 测试成功的情况
    pub static ref SETTING: RwLock<Setting> = RwLock::new(Setting::default());
}

pub const PUBLIC_DIR_PATH: &str = "public";
pub const DATA_DIR_PATH: &str = "data";
const SETTING_FILE_NAME: &str = "setting.json";
const UI_HOST_PORT: u16 = 8000;
const PROXY_HOST_PORT: u16 = 8080;
pub const MAX_NAME_LENGTH: usize = 255;
pub const LATEST_USER_ID: i64 = 1719763200; // 1722441600; // 即 2024 年 8 月 1 日的时间戳

// 参照 newtype 做法，在开头就把错误拦住
// 看 https://www.howtocodeit.com/articles/ultimate-guide-rust-newtypes
#[derive(Error, Debug)]
pub enum SetError {
    #[error("错误 ID：{0}，不可能小于 {LATEST_USER_ID} 即 2024 年 8 月 1 日")]
    InvalidId(i64),
    #[error("无效的文件夹路径：{0}")]
    InvalidDirPath(String),
    #[error("端口 {0} 已经被占用")]
    PortInUsed(u16),
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Setting {
    // 登录时候的本地时间的秒数，一旦设置不再改变，会保存在本地 json 文件，每次读取，不再改变
    user_id: i64,
    user_agent_cookie: UserAgentCookie,
    #[serde(skip)] // ui 服务器端口和网关服务器端口都用新鲜设定的，否则用默认的
    ui_service_port: u16,
    #[serde(skip)]
    proxy_service_port: u16,
    #[serde(skip)] // 工作目录不用记住，调用时没给，就在当前目录寻找
    working_dir_path: String,
}

impl Default for Setting {
    fn default() -> Self {
        Self {
            user_id: 0,
            user_agent_cookie: UserAgentCookie::default(),
            ui_service_port: UI_HOST_PORT,
            proxy_service_port: PROXY_HOST_PORT,
            working_dir_path: "".to_string(),
        }
    }
}

impl Setting {
    pub async fn from(&mut self, another_setting: Setting) -> Result<()> {
        self.set_user_id(another_setting.user_id())?;
        self.user_agent_cookie
            .from(&another_setting.user_agent_cookie)?;
        self.set_ui_service_port(another_setting.ui_service_port())
            .await?;
        self.set_proxy_service_port(another_setting.proxy_service_port())
            .await?;
        self.set_working_dir_path(&another_setting.working_dir_path())
            .await?;
        Ok(())
    }

    pub async fn load(&mut self, working_dir_path: Option<String>) -> Result<()> {
        let working_dir_path = match working_dir_path {
            Some(path) => path,
            None => "".to_string(),
        };
        let data_dir_path = if working_dir_path.len() > 0 {
            PathBuf::from(working_dir_path).join(DATA_DIR_PATH)
        } else {
            PathBuf::from(DATA_DIR_PATH)
        };
        let path = data_dir_path.join(SETTING_FILE_NAME);
        let contents = tokio::fs::read_to_string(path).await?;
        let setting_from_file = serde_json::from_str::<Setting>(&contents)?;
        self.set_user_id(setting_from_file.user_id())?;
        self.user_agent_cookie
            .from(&setting_from_file.user_agent_cookie)?;
        Ok(()) // 顺利读入数据，返回即可
    }

    pub async fn init_with(
        &mut self,
        ui_port: Option<u16>,
        proxy_port: Option<u16>,
        working_dir_path: Option<String>,
    ) -> Result<()> {
        // 获取网络时间戳初始化默认值
        // 第一次启动时，或读入数据失败，重新获取 NTP 时间戳，是正确的网络时间，64位，用来做 id 基本上不会有重复
        let user_id = Local::now().timestamp_micros() * 1000;
        // 需要检查可用性
        self.set_user_id(user_id)?;
        let ui_port = match ui_port {
            Some(port) => port,
            None => UI_HOST_PORT,
        };
        self.set_ui_service_port(ui_port).await?;
        let proxy_port = match proxy_port {
            Some(port) => port,
            None => PROXY_HOST_PORT,
        };
        self.set_proxy_service_port(proxy_port).await?;
        let working_dir_path = if let Some(working_dir_path) = working_dir_path {
            &working_dir_path.to_owned()
        } else {
            ""
        };
        self.set_working_dir_path(working_dir_path).await?;
        Ok(())
    }

    pub fn save(&self) -> Result<()> {
        let contents = serde_json::to_string(self)?;
        let data_dir_path = if self.working_dir_path.len() > 0 {
            PathBuf::from(&self.working_dir_path).join(DATA_DIR_PATH)
        } else {
            PathBuf::from(DATA_DIR_PATH)
        };
        let path = PathBuf::from(data_dir_path).join(SETTING_FILE_NAME);
        Ok(std::fs::write(path, contents)?)
    }

    pub fn user_id(&self) -> i64 {
        self.user_id
    }

    fn set_user_id(&mut self, id: i64) -> Result<()> {
        if id / 1_000_000_000 < LATEST_USER_ID {
            return Err(SetError::InvalidId(id).into());
        } else {
            self.user_id = id;
        }
        Ok(())
    }

    pub fn ui_service_port(&self) -> u16 {
        if self.ui_service_port == 0 {
            UI_HOST_PORT
        } else {
            self.ui_service_port
        }
    }

    async fn set_ui_service_port(&mut self, port: u16) -> Result<()> {
        let addr = SocketAddr::from(([0, 0, 0, 0], port));
        match TcpListener::bind(addr).await {
            Ok(_) => {
                self.ui_service_port = port;
                Ok(())
            }
            Err(_) => bail!(SetError::PortInUsed(port)),
        }
    }

    pub fn proxy_service_port(&self) -> u16 {
        if self.proxy_service_port == 0 {
            PROXY_HOST_PORT
        } else {
            self.proxy_service_port
        }
    }

    async fn set_proxy_service_port(&mut self, port: u16) -> Result<()> {
        let addr = SocketAddr::from(([0, 0, 0, 0], port));
        match TcpListener::bind(addr).await {
            Ok(_) => {
                self.proxy_service_port = port;
                Ok(())
            }
            Err(_) => Err(SetError::PortInUsed(port).into()),
        }
    }

    pub fn user_agent_cookie(&self) -> UserAgentCookie {
        self.user_agent_cookie.clone()
    }

    pub async fn set_user_agent_cookie(&mut self, user_agent: &str, cookie: &str) -> Result<()> {
        self.user_agent_cookie.update(user_agent, cookie)?;
        self.save()
    }

    pub fn working_dir_path(&self) -> String {
        self.working_dir_path.clone()
    }

    async fn set_working_dir_path(&mut self, data_dir_path: &str) -> Result<()> {
        if tokio::fs::try_exists(data_dir_path).await? {
            self.working_dir_path = data_dir_path.to_string();
            Ok(())
        } else {
            bail!(SetError::InvalidDirPath(data_dir_path.to_string()))
        }
    }
}
