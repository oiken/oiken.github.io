use crate::util::Timestamp;
use anyhow::Result;
use chrono::Local;
use serde::{Deserialize, Serialize};
use thiserror::Error;

const LATEST_ID: i64 = 1719763200; // 即 2024 年 7 月 1 日的时间戳

#[derive(Error, Debug)]
pub enum SetError {
    #[error("错误 ID：{0}，不可能小于 {LATEST_ID} 即 2024 年 7 月 1 日")]
    InvalidId(i64),
    #[error("无效 Cookie：{reason}")]
    InvalidCookie { reason: String },
    #[error("空字符串不能作为 {0}")]
    EmptyString(String),
}

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct UserAgentCookie {
    user_agent: String,
    cookie: String,
    update_at: String,
    update_at_timestamp: i64,
}

impl UserAgentCookie {
    pub fn from(&mut self, user_agent_cookie: &UserAgentCookie) -> Result<()> {
        self.set_user_agent(&user_agent_cookie.get_user_agent())?;
        self.set_cookie(&user_agent_cookie.get_cookie())?;
        self.set_update_at(user_agent_cookie.get_update_at_timestamp())?;
        Ok(())
    }

    pub fn get_cookie(&self) -> String {
        self.cookie.clone()
    }

    fn set_cookie(&mut self, cookie: &str) -> Result<()> {
        let reason = if !cookie.contains("CID=") {
            Some("缺少 CID 值")
        } else if !cookie.contains("SEID=") {
            Some("缺少 SEID 值")
        } else if !cookie.contains("UID=") {
            Some("缺少 UID 值")
        } else if cookie.len() < 19 {
            // "CID=x;SEID=y;UID=z;"
            Some("长度不够")
        } else {
            None
        };
        if let Some(reason) = reason {
            Err(SetError::InvalidCookie {
                reason: format!("{cookie} {reason}"),
            }
            .into())
        } else {
            self.cookie = cookie.to_string();
            Ok(())
        }
    }

    pub fn get_user_agent(&self) -> String {
        self.user_agent.clone()
    }

    fn set_user_agent(&mut self, user_agent: &str) -> Result<()> {
        if user_agent.len() > 0 {
            self.user_agent = user_agent.to_string();
            Ok(())
        } else {
            Err(SetError::EmptyString("user_agent".to_string()).into())
        }
    }

    pub fn get_update_at_timestamp(&self) -> i64 {
        self.update_at_timestamp
    }

    pub fn get_update_at(&self) -> String {
        self.update_at.clone()
    }

    fn set_update_at(&mut self, update_at_timestam: i64) -> Result<()> {
        if update_at_timestam <= LATEST_ID {
            Err(SetError::InvalidId(update_at_timestam).into())
        } else {
            self.update_at_timestamp = update_at_timestam;
            self.update_at = Timestamp::nanos_to_local_string(update_at_timestam, false)?;
            Ok(())
        }
    }

    pub fn update(&mut self, user_agent: &str, cookie: &str) -> Result<()> {
        self.set_user_agent(user_agent)?;
        self.set_cookie(cookie)?;
        // 要纳秒数 = 微秒数 * 1000
        self.set_update_at(Local::now().timestamp_micros() * 1000)?;
        Ok(())
    }
}
