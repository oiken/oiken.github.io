use super::{down_url_cipher, error};
use crate::{error_bail, warn_bail};
use anyhow::bail;
use chrono::{DateTime, Local, Utc};
use serde_derive::Deserialize;
use serde_json::Value;
use url::Url;

// get_file_url 接口：let url = format!("http://proapi.115.com/app/chrome/down?method=get_file_url&pickcode={}", PICK_CODE); 返回的数据结构
#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
    pub headers: hyper::HeaderMap,
    pub post_data: String,
    pub decode_key: Vec<u8>,
}

impl Request {
    pub fn new(pickcode: &str) -> Self {
        let now: DateTime<Utc> = Utc::now(); // 获取当前时间
        let local: DateTime<Local> = now.with_timezone(&Local); // 转换为本地时间
        let timestamp = local.timestamp() as u64; // 获取时间戳（秒）
        let data = format!("{{\"pickcode\":\"{}\"}}", pickcode);
        let (encoded_data, decode_key) = down_url_cipher::encode(data.as_str(), timestamp);
        // println!("用时间戳 {} 加密数据 \"{}\" 的结果： {}, \n\t密钥是：{:?}", timestamp, data, encoded_data, decode_key);
        let base_url = "http://proapi.115.com/app/chrome/downurl".to_string();
        let url = format!("{}?t={}", base_url, timestamp);
        let mut headers = hyper::HeaderMap::new();
        if let Ok(accetp) = "*/*".parse() {
            headers.insert(hyper::header::ACCEPT, accetp);
        }
        // x-www-form-urlencoded 表示数据已经经过 url 编码 必须设置这个，否则返回错误
        if let Ok(content_type) = "application/x-www-form-urlencoded".parse() {
            headers.insert(hyper::header::CONTENT_TYPE, content_type);
        }
        let url_encoded_data = urlencoding::encode(&encoded_data);
        let post_data = format!("data={}", url_encoded_data.to_string());
        Request {
            base_url,
            url,
            headers,
            post_data,
            decode_key,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub msg: String,
    pub errno: i64,
    #[serde(rename = "data")]
    pub url: String, // 这个和 error_response::ErrorResponse 很相似，就差 data，这个为 String， ErrorResponse.data 是一个 Vec<Value>
    pub valid_timestamp: Option<i64>, // 下载时限 20 个小时内有效，这个不是 json string 里有的，而是从 data 数据里提取出来的，所以是 Option 类型，
}
// 从 api_down_url 返回的错误信息： "{"state":false,"error":"请重新登录","errno":99,"request":"\/app\/chrome\/downurl?t=1717577231","data":[]}"
// 信息 errno 不等于 0 说明出错了 {\"state\":false,\"msg\":\"很抱歉，提取码不能为空",\"errno\":50001,\"data\":\"\"}"
// "msg":"很抱歉，提取码不能为空" 是 post 没有发送 data 数据或 data 数据无效
// 信息 errno 等于 0， 说明正确返回， { state: true, msg: "", errno: 0, data: "gGuoEoxTtm/zkORe2/j+ekWt4xko5FyoPoI4vHYIEw7BKyP/WSfkGjMc0/NBJjgCQ5Z50oY4Qs14l17Xk3/1QT2d24DRrVocN6+CkxBBo2nqyHNGWXHlkdTlvveZiOhIIZlDwurmujnEzvodW2vYBUDSZbiVLlNLdXrDDYs9gIBitj41mt7/NRFhLTRz/eMMHS2jYC85mtwP1g4ebjxb+PNi7aZjvDohZfqbvpMJCLsAacIICbsMXPvhjulxTXKUIQX+aJmN7AEF+wUfhC01dY7tqvkyEpd9JwNo8fwihxGGXz1kOB1aitURzXb0BETBXIdW67oxyrr7Bgv0hdFdOm5hCL7CY6vVGOmfLSr4yG5g72A8BrHyrFWJOc+65/HGygJDI1oRtKi1zZmqbdMAjuDmSaD/C1QvNg+lJx3ITasO+02phTX6ApfISkmktwqLFFuOyztmg+qW0VhKRwnUj31+r4wIexk6rej+Gzec0UQTVEBjpTRxJ5g3uGc2MSW5ce3u/4Jv1mETMeo9NzDNbY55Svf3Zeaw8WUBFS390ZOs9jATh5E8hvfWBxr0mP1McG7gk6cERjP1NaBaOH8NfqObGkfLfFtSmgsOoyWl/q0+jHpSp6YP7TH4uw+U68JgB4rxjxLh/ALs/0BRKpAMvnPn+zV+RN0VhRWMM3k/BbUMS5m6LkA4PzqllgQtNjt6prc8/6594iiwlBM7EGZeneVGYrQpv/PakGnOYs8VMtSnQHgfNzPf5i1n1tIsewfPegnq5bhdbnhGz+GfOP5YSYNr4b4lBqbqKnQGV4yyPlcJMZHBIcamD+Kr8wF95WsIRcRY4SUqZaZBPYyWTZGVPhNpnfx0qpbaYARbKaNwhXWd5I9MVyuaDNbpqNs5FH6k/qwdOqheG8ODjzumC/QNVtxwlz49XHoOLwLUb+vo/xpITD3CsNQuza1htocvSf+eMUUZ5LbYX3L59niElUMc+Fbp9UjCM1wQAV06i6BlZyyJG2KRq2KqkNYn4FPlscIx" }
// 注意 state 为 false 时，data 可能为 [] , 可能为 String，所以收到 response 信息后，先尝试转为正确答案，不行再提取错误信息

impl Response {
    pub fn new(data: &[u8], decode_key: &[u8]) -> anyhow::Result<Response> {
        match serde_json::from_slice::<Response>(&data) {
            // 先尝试转为正确答案，不行就查找 msg， 或 error 进行返回
            Ok(mut response) => {
                if response.state && response.url.len() > 0 {
                    let decoded_str = down_url_cipher::decode(&response.url, decode_key);
                    // println!("解密的数据为：{:#?}", decoded_str);
                    if let Some((url, valid_timestamp)) = Response::from(&decoded_str) {
                        response.url = url;
                        response.valid_timestamp = Some(valid_timestamp);
                    }
                    // if let Some(timestamp) = &response.valid_timestamp {
                    //     println!("解密结果：{:#?}\n时间戳为 {:?}", &response.url, seconds_to_local_string(timestamp as i64));
                    // };
                    Ok(response)
                } else if response.msg.len() > 0 {
                    warn_bail!(response.msg);
                } else {
                    bail!("没有错误信息 msg")
                }
            }
            Err(_) => {
                let (is_error, desc) = error::Response::exact_desc(&data, "获取大文件的下载链接");
                if is_error {
                    error_bail!(desc);
                } else {
                    warn_bail!(desc);
                }
            }
        }
    }

    // downurl 接口：format!("http://proapi.115.com/app/chrome/downurl?t={}", timestamp) 返回的数据，解密成功后，分析 json 获取 url
    pub fn from(json_str: &str) -> Option<(String, i64)> {
        // 不规则的 json
        // 将 JSON 字符串解析为 serde_json::Value
        let parsed_data: Value = serde_json::from_str(json_str).unwrap();
        if let Some(url_info) = parsed_data.as_object() {
            // 遍历 HashMap
            for (_, value) in url_info {
                // 检查 value 是否包含 "url" 字段
                if let Some(url_value) = value.get("url") {
                    if let Some(url_value) = url_value.get("url") {
                        // 提取 "url" 字段
                        if let serde_json::Value::String(url_value_str) = url_value {
                            if let Ok(Some(valid_timestamp)) =
                                Response::valid_timestamp_from(url_value_str)
                            {
                                // 如果 url 是空字符串，已经不能提取出 t 参数了，所以这个结果说明 url 长度不为零
                                return Some((url_value_str.to_owned(), valid_timestamp));
                                // 如果只需要第一个找到的 URL，可以在这里中断循环
                            }
                        }
                    }
                }
            }
        }
        None
    }

    // 解析 URL 里的 t 参数为有效时间戳
    fn valid_timestamp_from(url: &str) -> anyhow::Result<Option<i64>> {
        let parsed_url = Url::parse(url)?;
        // 获取查询参数
        let query_pairs = parsed_url.query_pairs();
        // 查找参数 't' 的值
        for (key, value) in query_pairs {
            if key == "t" {
                // 将值从Cow<'_, str>转换为String并解释为 u64
                let valid_timestamp = value.to_string().parse::<i64>()?;
                return Ok(Some(valid_timestamp));
            }
        }
        // 如果没有找到 't' 参数，返回 None
        Ok(None)
    }
}
