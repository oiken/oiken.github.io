use super::error;
use crate::{error_bail, warn_bail};
use serde_derive::Deserialize;

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
}

impl Request {
    pub fn new(cid: &str) -> Self {
        let base_url = "https://webapi.115.com/category/get";
        Request {
            base_url: base_url.to_string(),
            url: format!("{}?cid={}", base_url, cid),
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    #[serde(rename = "pick_code")]
    pub pickcode: String,
}
/*{"count": 0,
  "size": "122.1MB",
  "folder_count": 0,
  "play_long": 425,
  "show_play_long": 0,
  "ptime": "1715389965",
  "utime": "1715389965",
  "is_share": "0",
  "file_name": "Hey_Duggee_-_01._The_Drawing_Badge_b04y9d7y_default.mkv",
  "pick_code": "dsxv2lczezry9x5dr",
  "sha1": "51BCB0202C43BF76674E59D91F0FF9F5A64ADDA8",
  "is_mark": "0",
  "fvs": 0,
  "open_time": 0,
  "score": 0,
  "desc": "",
  "file_category": "1",
  "paths": [
    {
      "file_id": 0,
      "file_name": "\u6839\u76ee\u5f55"
    },
    {
      "file_id": "2897206256512416243",
      "file_name": "\u52a8\u753b\u7247"
    },
    {
      "file_id": "2897206599363214033",
      "file_name": "Hey Duggee Season 01"
    }
  ]
}*/

impl Response {
    pub fn new(data: &[u8]) -> anyhow::Result<Response> {
        match serde_json::from_slice::<Response>(&data) {
            Ok(response) => {
                if response.pickcode.len() == 0 {
                    error_bail!("得到的 pickcode 为空");
                } else {
                    Ok(response)
                }
            } // 解码出来把服务器返回原因当错误信息往上传递
            Err(_) => {
                let (is_error, desc) = error::Response::exact_desc(&data, "获取文件的 pickcode ");
                if is_error {
                    error_bail!(desc);
                } else {
                    warn_bail!(desc);
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    // use super::*;

    #[tokio::test]
    async fn test_category() {}
}
