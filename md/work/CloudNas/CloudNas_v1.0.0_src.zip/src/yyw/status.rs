use super::error;
use crate::{error_bail, warn_bail};
use serde_derive::Deserialize;

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
}

impl Request {
    pub fn new() -> Self {
        let base_url = "https://my.115.com/?ct=guide&ac=status";
        Request {
            base_url: base_url.to_string(),
            url: base_url.to_string(),
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
}
/**/

impl Response {
    pub fn new(data: &[u8]) -> anyhow::Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response), // 解码出来把服务器返回原因当错误信息往上传递
                Err(_) => {
                    let (parse_error, desc) = error::Response::exact_desc(&data, "获取登录状态");
                    if parse_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response { state: false })
        }
    }
}
