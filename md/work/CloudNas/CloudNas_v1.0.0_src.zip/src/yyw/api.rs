use super::{
    category, down_url, error, files, files_batch_rename, files_delete, files_mkdir, files_move,
    files_move_progress, get_file_url, read_file, sample_init_upload, status,
};
use crate::{error, error_bail, setting::SETTING, warn, warn_bail};
use anyhow::{bail, Result};
use bytes::Bytes;
use flate2::read::GzDecoder;
use http_body_util::{BodyExt, Empty, Full};
use hyper::Request;
use hyper::{client::conn::http1::SendRequest, Uri};
use hyper_util::rt::TokioIo;
use lazy_static::lazy_static;
use std::collections::HashMap;
use std::io::Read as _;
use tokio::net::TcpStream;
use tokio::sync::{Mutex, RwLock};

pub const API_TIMEOUT_SECONDS: u64 = 3; // 调用 api 超时时间 3 秒

lazy_static! {
    pub static ref API: Api = Api::default();
}

#[derive(Debug, Default)]
pub struct Api {
    files_move_counter: RwLock<u8>,
    base_url_sender_map: RwLock<HashMap<String, Mutex<SendRequest<Full<Bytes>>>>>,
}

impl Api {
    pub async fn next_files_move_counter(&self) -> u8 {
        let mut files_move_counter = self.files_move_counter.write().await;
        if *files_move_counter > u8::MAX - 1 {
            *files_move_counter = 0;
        } else {
            *files_move_counter += 1;
        }
        *files_move_counter
    }

    async fn update_senter(&self, base_url: &str) -> Result<()> {
        {
            // 试试有没有，没有的话，是否还连接中，大括号让 read 锁不要影响下面的 写锁
            let base_url_sender_map = self.base_url_sender_map.read().await;
            if let Some(mutex_sender) = base_url_sender_map.get(base_url) {
                let sender = mutex_sender.lock().await;
                if !&sender.is_closed() {
                    return Ok(());
                }
            }
        }
        let uri: Uri = base_url.parse()?;
        match uri.host() {
            None => {
                warn_bail!("未能从 url= {} 中获得主机域名", base_url);
            }
            Some(host) => {
                let port = uri.port_u16().unwrap_or(80);
                let addr = format!("{}:{}", host, port);
                let stream = TcpStream::connect(&addr).await?;
                let io = TokioIo::new(stream);
                let (sender, conn) = hyper::client::conn::http1::handshake(io).await?;
                // sender 类型是  SendRequest，是 hyper 库中用于发送请求并接收响应的类型。
                // 它内部维护了一个连接池，可以配合 Request 的 keep-alive 保持连接，复用底层的 TCP 连接。
                let url_cloned = base_url.to_string();
                tokio::spawn(async move {
                    // 运行一个任务，这个任务会轮询 connection 并处理 HTTP 状态。如果连接出现错误，它会打印错误信息。
                    if let Err(_) = conn.await {
                        let mut base_url_sender_map = API.base_url_sender_map.write().await;
                        base_url_sender_map.remove(&url_cloned);
                    }
                });
                let mut base_url_sender_map = API.base_url_sender_map.write().await;
                base_url_sender_map.insert(base_url.to_string(), Mutex::new(sender));
                Ok(())
            }
        }
    }

    async fn request(
        &self,
        base_url: &str,
        url: &str,
        headers: Option<hyper::header::HeaderMap>,
        method: &str, // "GET" 或 "POST"
        data: String, // "GET" 的话是空字符串，"POST" 的话有数据
    ) -> Result<Vec<u8>> {
        let uri: Uri = url.parse()?;
        let authority = uri.authority().unwrap().clone();
        let user_agent_cookie = {
            let setting = SETTING.read().await;
            setting.user_agent_cookie()
        };
        let mut req = Request::builder()
            .method(method)
            .uri(url)
            .header(hyper::header::HOST, authority.as_str()) // 这个必须有， 否则返回 400
            .header(hyper::header::CONNECTION, "keep-alive")
            .header(hyper::header::ACCEPT_ENCODING, "gzip, deflate, br")
            .header(hyper::header::CONTENT_TYPE, "application/json")
            .header(hyper::header::COOKIE, user_agent_cookie.get_cookie())
            .header(
                hyper::header::USER_AGENT,
                user_agent_cookie.get_user_agent(),
            )
            .body(Full::new(Bytes::from(data)))?;
        if let Some(header_map) = headers {
            if !header_map.is_empty() {
                req.headers_mut().extend(header_map);
            }
        }
        self.update_senter(base_url).await?;
        let base_url_sender_map = self.base_url_sender_map.read().await;
        match base_url_sender_map.get(base_url) {
            // 前面的 update_senter 保证了这里能获取成功，如果真的没有找到，就返回告知错误
            None => {
                error_bail!("没有为 {} 找到 http 请求发送体:", url);
            }
            Some(mutex_sender) => {
                let mut sender = mutex_sender.lock().await;
                let mut res = sender.send_request(req).await?;
                if !res.status().is_success() {
                    if res.status().is_server_error() {
                        warn!(
                            "请求 {:?}\n\t回应 {} 服务器错误 {:?}",
                            url,
                            res.status(),
                            res
                        );
                    } else if res.status().is_client_error() {
                        error!(
                            "请求 {:?}\n\t回应 {} 请求错误：{:?}",
                            url,
                            res.status(),
                            res
                        );
                    } else if res.status().is_redirection() {
                        warn!("请求 {:?}\n\t回应 {} 重定向：{:?}", url, res.status(), res);
                    }
                }
                let mut data = Vec::new();
                while let Some(next) = res.frame().await {
                    let frame = next?;
                    if let Some(chunk) = frame.data_ref() {
                        data.extend_from_slice(&chunk);
                    }
                }
                // 检查响应是否使用 gzip 压缩
                if let Some(content_encoding) = res.headers().get("content-encoding") {
                    if let Ok(encoding) = content_encoding.to_str() {
                        if encoding.to_lowercase().contains("gzip") {
                            // 解压缩响应数据
                            let mut d = GzDecoder::new(&data[..]);
                            let mut vec_u8: Vec<u8> = vec![];
                            d.read_to_end(&mut vec_u8).unwrap();
                            data = vec_u8;
                        }
                    }
                }
                Ok(data)
            }
        }
    }

    pub async fn status(&self) -> Result<status::Response> {
        let request = status::Request::new();
        match self
            .request(&request.base_url, &request.url, None, "GET", String::new())
            .await
        {
            Ok(data) => {
                status::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"查看登录状态时出错：{:?}", err};
                Err(err)
            }
        }
    }

    pub async fn files(&self, payload: &files::Payload) -> Result<files::Response> {
        let request = files::Request::new(payload);
        match self
            .request(&request.base_url, &request.url, None, "GET", String::new())
            .await
        {
            Ok(data) => {
                files::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"获取目录时出错：{:?}", err};
                Err(err)
            }
        }
    }

    pub async fn category(&self, cid: &str) -> Result<category::Response> {
        let request = category::Request::new(cid);
        match self
            .request(&request.base_url, &request.url, None, "GET", String::new())
            .await
        {
            Ok(data) => category::Response::new(&data),
            Err(err) => Err(err),
        }
    }

    // 这个获取大文件的连接时不会提示
    pub async fn down_url(&self, pickcode: &str) -> Result<down_url::Response> {
        let request = down_url::Request::new(pickcode);
        match self
            .request(
                &request.base_url,
                &request.url,
                Some(request.headers),
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => down_url::Response::new(&data, &request.decode_key),
            Err(err) => Err(err),
        }
    }

    // "文件大小超出限制，请使用115电脑端下载"
    pub async fn get_file_url(&self, pickcode: &str) -> Result<get_file_url::Response> {
        let request = get_file_url::Request::new(pickcode);
        match self
            .request(&request.base_url, &request.url, None, "GET", String::new())
            .await
        {
            Ok(data) => get_file_url::Response::new(&data),
            Err(err) => Err(err),
        }
    }

    // read_file() 出错了："115 pmt user 11-10" 估计是最多10个并发读取，而我这里达到了 16 个
    pub async fn read_file(
        &self,
        url: &str,
        offset: u64,
        count: usize,
        // _sender: &mut SendRequest<Empty<Bytes>>,
    ) -> Result<Vec<u8>> {
        let request = read_file::Request::new(url, offset, count);
        match self
            .request(
                &request.url,
                &request.url,
                Some(request.headers),
                "GET",
                String::new(),
            )
            .await
        {
            // 先尝试解析为错误，如果不是错误，则是字节数组，单纯返回即可
            Ok(data) => match read_file::Response::new(&data) {
                Ok(response) => {
                    warn_bail!(response.message);
                }
                Err(_) => {
                    let (parse_error, desc) =
                        error::Response::exact_desc(&data, "读取文件字节数组");
                    if parse_error {
                        Ok(data) // 没有说明是单纯的字节码，而不是 json 字符串
                    } else {
                        error_bail!(desc);
                    }
                }
            },
            Err(err) => Err(err),
        }
    }

    // 获取回来的 Vec<u8>，如果是 gzip ，会先解压缩，调用者可以转化成 utf8 字符串的 json，或其它方式
    // 调用者提供参数 headers ，可以覆盖掉预设的参数
    async fn request_get_2(
        url: &str,
        headers: Option<hyper::header::HeaderMap>,
        sender: &mut SendRequest<Empty<Bytes>>,
    ) -> Result<Vec<u8>> {
        let uri: Uri = url.parse()?;
        let authority = uri.authority().unwrap().clone();
        let user_agent_cookie = {
            let setting = SETTING.read().await;
            setting.user_agent_cookie()
        };
        let mut req = Request::builder()
            .uri(url)
            .header(hyper::header::HOST, authority.as_str()) // 这个必须有， 否则返回 400
            .header(hyper::header::CONNECTION, "keep-alive")
            .header(hyper::header::ACCEPT_ENCODING, "gzip, deflate, br")
            .header(hyper::header::CONTENT_TYPE, "application/json")
            .header(hyper::header::COOKIE, user_agent_cookie.get_cookie())
            .header(
                hyper::header::USER_AGENT,
                user_agent_cookie.get_user_agent(),
            )
            .body(Empty::<Bytes>::new())?;
        if let Some(header_map) = headers {
            if !header_map.is_empty() {
                req.headers_mut().extend(header_map);
            }
        }
        let mut res = sender.send_request(req).await?; //sender.lock().await.send_request(req).await?;
                                                       // if !res.status().is_success() {
                                                       //     if res.status().is_server_error() {
                                                       //         warn!("请求 {:?}\n\t回应服务器错误 {:?}", url, res); // 500
                                                       //     } else if res.status().is_client_error() {
                                                       //         warn!("请求 {:?}\n\t回应请求错误：{:?}", url, res); // 400
                                                       //     } else if res.status().is_redirection() {
                                                       //         warn!("请求 {:?}\n\t回应重定向：{:?}", url, res); // 300
                                                       //     }
                                                       // }
                                                       // debug!("请求 {:?}\n\t回应的 headers 是: {:#?}", url, res.headers());
        let mut data = Vec::new();
        while let Some(next) = res.frame().await {
            let frame = next?;
            if let Some(chunk) = frame.data_ref() {
                data.extend_from_slice(&chunk);
            }
        }
        // 检查响应是否使用 gzip 压缩
        if let Some(content_encoding) = res.headers().get("content-encoding") {
            if let Ok(encoding) = content_encoding.to_str() {
                if encoding.to_lowercase().contains("gzip") {
                    // 解压缩响应数据
                    let mut d = GzDecoder::new(&data[..]);
                    let mut vec_u8: Vec<u8> = vec![];
                    d.read_to_end(&mut vec_u8).unwrap();
                    data = vec_u8;
                }
            }
        }
        return Ok(data);
    }

    // read_file() 出错了："115 pmt user 11-10" 估计是最多10个并发读取，而我这里达到了 16 个
    pub async fn read_file_2(
        url: &str,
        offset: u64,
        count: usize,
        sender: &mut SendRequest<Empty<Bytes>>,
    ) -> Result<Vec<u8>> {
        let request = read_file::Request::new(url, offset, count);
        match Self::request_get_2(&request.url, Some(request.headers), sender).await {
            Ok(data) => match read_file::Response::new(&data) {
                Ok(response) => {
                    bail!(response.message);
                }
                Err(_) => {
                    let (parse_error, desc) =
                        error::Response::exact_desc(&data, "读取文件字节数组 2");
                    if parse_error {
                        Ok(data) // 没有说明是单纯的字节码，而不是 json 字符串
                    } else {
                        error_bail!(desc);
                    }
                }
            },
            Err(err) => Err(err),
        }
    }

    pub async fn files_batch_rename(
        &self,
        payload: &files_batch_rename::Payload,
    ) -> Result<files_batch_rename::Response> {
        let request = files_batch_rename::Request::new(payload);
        match self
            .request(
                &request.base_url,
                &request.url,
                Some(request.headers),
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => {
                files_batch_rename::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"修改文件或文件夹名字时出错：{:?}", err};
                Err(err)
            }
        }
    }

    // 移动文件
    pub async fn files_move(&self, payload: &files_move::Payload) -> Result<files_move::Response> {
        let request = files_move::Request::new(payload).await;
        match self
            .request(
                &request.base_url,
                &request.url,
                Some(request.headers),
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => {
                files_move::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"移动文件或文件夹时出错：{:?}", err};
                Err(err)
            }
        }
    }

    // 移动文件
    pub async fn files_move_progress(
        &self,
        move_progress_id: &str,
    ) -> Result<files_move_progress::Response> {
        let request = files_move_progress::Request::new(move_progress_id);
        match self
            .request(&request.base_url, &request.url, None, "GET", String::new())
            .await
        {
            Ok(data) => {
                files_move_progress::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"获取移动文件或文件夹的进度出错：{:?}", err};
                Err(err)
            }
        }
    }

    // 删除文件
    pub async fn files_delete(
        &self,
        payload: &files_delete::Payload,
    ) -> Result<files_delete::Response> {
        let request = files_delete::Request::new(payload);
        match self
            .request(
                &request.base_url,
                &request.url,
                Some(request.headers),
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => {
                files_delete::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"删除文件或文件夹时出错：{:?}", err};
                Err(err)
            }
        }
    }

    // 新建文件
    pub async fn sample_init_upload(
        &self,
        payload: &sample_init_upload::Payload,
    ) -> Result<sample_init_upload::Response> {
        let request = sample_init_upload::Request::new(payload)?;
        match self
            .request(
                &request.base_url,
                &request.url,
                None,
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => {
                sample_init_upload::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"创建文件时出错：{:?}", err};
                Err(err)
            }
        }
    }

    // 新建文件夹
    pub async fn files_mkdir(
        &self,
        payload: &files_mkdir::Payload,
    ) -> Result<files_mkdir::Response> {
        let request = files_mkdir::Request::new(payload);
        match self
            .request(
                &request.base_url,
                &request.url,
                Some(request.headers),
                "POST",
                request.post_data,
            )
            .await
        {
            Ok(data) => {
                files_mkdir::Response::new(&data) // 处理请求回来的数据
            }
            Err(err) => {
                warn! {"创建文件夹时出错：{:?}", err};
                Err(err)
            }
        }
    }
}
