use super::error;
use crate::{error_bail, warn_bail};
use anyhow::Result;
use hyper::HeaderMap;
use serde_derive::Deserialize;

// 此接口来自：https://github.com/ChenyangGao/web-mount-packs/blob/main/python-115-client/p115/component/client.py#L1839
/* python 例子
 def fs_batch_delete(
        self,
        payload: dict | Iterable[int | str],
        /,
        async_: Literal[False, True] = False,
        **request_kwargs,
    ) -> dict | Coroutine[Any, Any, dict]:
        """删除文件或文件夹
        POST https://webapi.115.com/rb/delete
        payload:
            - fid[0]: int | str
            - fid[1]: int | str
            - ...
        """
        api = "https://webapi.115.com/rb/delete"
        if not isinstance(payload, dict):
            payload = {f"fid[{i}]": fid for i, fid in enumerate(payload)}
        if not payload:
            return {"state": False, "message": "no op"}
        return self.request(url=api, method="POST", data=payload, async_=async_, **request_kwargs)



    从浏览器得到：
    Request URL: URL: https://webapi.115.com/files/move
    headers: Accept: *//*
             Content-Type: application/x-www-form-urlencoded
    Request Method: POST
    Status Code: 200 OK
    Remote Address: 47.113.23.100:443
    Referrer Policy: strict-origin-when-cross-origin

    Form Data: pid=863442248979926752&fid%5B0%5D=2917052633232849036&fid%5B1%5D=2917052603713337428&ignore_warn=1
    解码：
        pid: 863442248979926752
        fid[0]: 2917052633232849036
        fid[1]: 2917052603713337428
        ignore_warn: 1
    返回： {"state":true,"error":"","errno":""}

    move_proid 可以调用另一个 api： move_progress
*/

#[derive(Debug, Clone)]
pub struct Payload {
    parent: u64,
    pub file_ids: Vec<u64>, // 一次删除多个
}

impl Payload {
    pub fn new(parent: u64, file_id_list: &[u64]) -> Payload {
        let mut file_ids = Vec::new();
        file_ids.extend_from_slice(file_id_list);
        Payload { parent, file_ids }
    }

    // 举例： pid=863442248979926752&fid%5B0%5D=2917052633232849036&fid%5B1%5D=2917052603713337428&ignore_warn=1
    pub fn to_string(&self) -> String {
        let mut fid_list_str = String::new();
        let mut index = 0_usize;
        for fid in self.file_ids.iter() {
            let fid_index_str = format!("fid[{}]", index);
            let fid_index_str = urlencoding::encode(&fid_index_str);
            fid_list_str.push_str(&format!("&{}={}", fid_index_str, fid));
            index += 1;
        }
        format!("pid={}{}&ignore_warn=1", self.parent, fid_list_str)
    }
}

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
    pub headers: HeaderMap,
    pub post_data: String,
}

impl Request {
    pub fn new(payload: &Payload) -> Self {
        let base_url = "https://webapi.115.com/rb/delete".to_string();
        let mut headers = hyper::HeaderMap::new();
        if let Ok(accetp) = "*/*".parse() {
            headers.insert(hyper::header::ACCEPT, accetp);
        }
        // x-www-form-urlencoded 表示数据已经经过 url 编码 必须设置这个，否则返回错误
        if let Ok(content_type) = "application/x-www-form-urlencoded".parse() {
            headers.insert(hyper::header::CONTENT_TYPE, content_type);
        }
        let post_data = payload.to_string();
        Request {
            base_url: base_url.clone(),
            url: base_url,
            headers,
            post_data,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub error: String,
    // pub errno: String,  不要，在 files_batch_move 接口里返回空字符串，不要反正没什么用
}
/* Response 范例
{"state":true, "error":"","errno":""}
*/

impl Response {
    pub fn new(data: &[u8]) -> Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response),
                Err(_) => {
                    let (is_error, desc) = error::Response::exact_desc(&data, "删除若干个文件");
                    if is_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response {
                state: false,
                error: "返回数据为空字符串".to_string(),
            })
        }
    }
}
