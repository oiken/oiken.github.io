use serde_derive::{Deserialize, Serialize};

// 错误信息
#[derive(Default, Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub msg: Option<String>,
    pub error: Option<String>,
    // pub errno: Option<i64>,
    // pub request: Option<String>,
}

impl Response {
    /// 尝试获取错误信息，如果没有或者数据不是 api::error::Response 格式的，就返回（是否解析出错，信息描述）
    pub fn exact_desc(json_data: &[u8], func_desc: &str) -> (bool, String) {
        match serde_json::from_slice::<Response>(json_data) {
            Ok(response) => {
                let no_desc = format!("空信息，完整的回应是：{:#?}", &response);
                let desc = if let Some(error) = response.error {
                    error
                } else if let Some(msg) = response.msg {
                    msg
                } else {
                    String::new()
                };
                let desc = if desc.len() > 0 {
                    Some(desc.to_string())
                } else {
                    Some(no_desc)
                };
                (false, format!("{}时，收到回应：{:?}", func_desc, desc))
            }
            Err(_err) => {
                let json_data_str = String::from_utf8_lossy(json_data);
                (
                    true,
                    format!("{}时，收到回应但转换失败：{:?}", func_desc, json_data_str),
                )
            }
        }
    }
}

// 先把数据转化成期望的正确结构，如果不对，那就查找 msg， 或 error 进行返回

// 从 api_get_file_url 返回的错误信息： "{"state":false,"msg":"登陆超时，请重新登陆。","errno":990001}"
// 从 api_get_file_url 返回的正确信息："{"state":true,"msg":"","errno":0,"data":{"2911673849008765519":{"file_name":"\u5f7b\u5e95\u73a9\u8f6c115\u76d8cookie\u6302\u8f7d\u6559\u7a0b.doc","file_size":1230173,"pick_code":"abjerdpwj1sv8hfio","url":{"url":"https:\/\/cdnfhnfile.115.com\/66569ab35a5375670a3b61b24f3e725110c076b1\/%E5%BD%BB%E5%BA%95%E7%8E%A9%E8%BD%AC115%E7%9B%98cookie%E6%8C%82%E8%BD%BD%E6%95%99%E7%A8%8B.doc?t=1717581571&u=80001717&s=524288000&d=vip-2028456996-abjerdpwj1sv8hfio-1&c=0&f=1&k=abeb88a2e86bddbdfdc22f8580eaee49&us=5242880000&uc=10&v=1","client":3,"desc":null,"isp":null,"oss_id":"fhnfile\/66569ab35a5375670a3b61b24f3e725110c076b1","ooid":""}}}}"

// 从 api_down_url 返回的错误信息： "{"state":false,"error":"请重新登录","errno":99,"request":"\/app\/chrome\/downurl?t=1717577231","data":[]}"
// 从 api_down_url 返回的错误信息   "{\"state\":false,\"msg\":\"很抱歉，提取码不能为空",\"errno\":50001,\"data\":\"\"}"
// 从 api_down_url 返回的正确信息， { state: true, msg: "", errno: 0, data: "gGuoEoxTtm/zkORe2/j+ekWt4xko5FyoPoI4vHYIEw7BKyP/WSfkGjMc0/NBJjgCQ5Z50oY4Qs14l17Xk3/1QT2d24DRrVocN6+CkxBBo2nqyHNGWXHlkdTlvveZiOhIIZlDwurmujnEzvodW2vYBUDSZbiVLlNLdXrDDYs9gIBitj41mt7/NRFhLTRz/eMMHS2jYC85mtwP1g4ebjxb+PNi7aZjvDohZfqbvpMJCLsAacIICbsMXPvhjulxTXKUIQX+aJmN7AEF+wUfhC01dY7tqvkyEpd9JwNo8fwihxGGXz1kOB1aitURzXb0BETBXIdW67oxyrr7Bgv0hdFdOm5hCL7CY6vVGOmfLSr4yG5g72A8BrHyrFWJOc+65/HGygJDI1oRtKi1zZmqbdMAjuDmSaD/C1QvNg+lJx3ITasO+02phTX6ApfISkmktwqLFFuOyztmg+qW0VhKRwnUj31+r4wIexk6rej+Gzec0UQTVEBjpTRxJ5g3uGc2MSW5ce3u/4Jv1mETMeo9NzDNbY55Svf3Zeaw8WUBFS390ZOs9jATh5E8hvfWBxr0mP1McG7gk6cERjP1NaBaOH8NfqObGkfLfFtSmgsOoyWl/q0+jHpSp6YP7TH4uw+U68JgB4rxjxLh/ALs/0BRKpAMvnPn+zV+RN0VhRWMM3k/BbUMS5m6LkA4PzqllgQtNjt6prc8/6594iiwlBM7EGZeneVGYrQpv/PakGnOYs8VMtSnQHgfNzPf5i1n1tIsewfPegnq5bhdbnhGz+GfOP5YSYNr4b4lBqbqKnQGV4yyPlcJMZHBIcamD+Kr8wF95WsIRcRY4SUqZaZBPYyWTZGVPhNpnfx0qpbaYARbKaNwhXWd5I9MVyuaDNbpqNs5FH6k/qwdOqheG8ODjzumC/QNVtxwlz49XHoOLwLUb+vo/xpITD3CsNQuza1htocvSf+eMUUZ5LbYX3L59niElUMc+Fbp9UjCM1wQAV06i6BlZyyJG2KRq2KqkNYn4FPlscIx" }

// 从 api_category 返回的错误信息： {"state":false,"error":"登录超时，请重新登录","errNo":990001,"request":"\/category\/get?cid=2911673849008765519"}
// 从 api_files 返回的错误信息： {"state":false,"error":"请先登录","request":"\/natsort\/files.php?aid=1&cid=0&o=file_name&asc=0&offset=0&show_dir=1&limit=30&code=&scid=&snap=0&natsort=1&record_open_time=1&count_folders=1&type=&source=&format=json&fc_mix=0"}
