// 翻译 cipher.js （来自 https://github.com/kkHAIKE/fake115/blob/master/fake115d.user.js ）
use base64::{engine::general_purpose, Engine as _};
use num_bigint::BigUint;
use num_traits::{One, Zero};
use std::str;

const G_KTS: [u8; 144] = [
    240, 229, 105, 174, 191, 220, 191, 138, 26, 69, 232, 190, 125, 166, 115, 184, 222, 143, 231,
    196, 69, 218, 134, 196, 155, 100, 139, 20, 106, 180, 241, 170, 56, 1, 53, 158, 38, 105, 44,
    134, 0, 107, 79, 165, 54, 52, 98, 166, 42, 150, 104, 24, 242, 74, 253, 189, 107, 151, 143, 77,
    143, 137, 19, 183, 108, 142, 147, 237, 14, 13, 72, 62, 215, 47, 136, 216, 254, 254, 126, 134,
    80, 149, 79, 209, 235, 131, 38, 52, 219, 102, 123, 156, 126, 157, 122, 129, 50, 234, 182, 51,
    222, 58, 169, 89, 52, 102, 59, 170, 186, 129, 96, 72, 185, 213, 129, 156, 248, 108, 132, 119,
    255, 84, 120, 38, 95, 190, 232, 30, 54, 159, 52, 128, 92, 69, 44, 155, 118, 213, 27, 143, 204,
    195, 184, 245,
];
const G_KEY_S: [u8; 4] = [0x29, 0x23, 0x21, 0x5E];
const G_KEY_L: [u8; 12] = [120, 6, 173, 76, 51, 134, 93, 24, 76, 1, 63, 70];

struct MyRsa {
    n: BigUint,
    e: BigUint,
}

impl MyRsa {
    fn new() -> Self {
        let n = BigUint::parse_bytes(b"8686980c0f5a24c4b9d43020cd2c22703ff3f450756529058b1cf88f09b8602136477198a6e2683149659bd122c33592fdb5ad47944ad1ea4d36c6b172aad6338c3bb6ac6227502d010993ac967d1aef00f0c8e038de2e4d3bc2ec368af2e9f10a6f1eda4f7262f136420c07c331b871bf139f74f3010e3c4fe57df3afb71683", 16).unwrap();
        let e = BigUint::parse_bytes(b"10001", 16).unwrap();
        MyRsa { n, e }
    }

    fn modpow(&self, base: &BigUint, exponent: &BigUint, modulus: &BigUint) -> BigUint {
        let mut result = BigUint::one();
        let mut base = base.clone();
        let mut exponent = exponent.clone();
        while !exponent.is_zero() {
            if exponent.bit(0) {
                result = (&result * &base) % modulus;
            }
            base = (&base * &base) % modulus;
            exponent = exponent >> 1;
        }
        result
    }

    fn pkcs1pad2(&self, s: &[u8], n: usize) -> BigUint {
        if n < s.len() + 11 {
            return BigUint::zero();
        }
        let mut ba = vec![0; n];
        let mut i = s.len();
        let mut m = n;
        while i > 0 && m > 0 {
            i -= 1;
            m -= 1;
            ba[m] = s[i];
        }
        m -= 1;
        ba[m] = 0;
        while m > 2 {
            m -= 1;
            ba[m] = 0xff;
        }
        m -= 1;
        ba[m] = 2;
        m -= 1;
        ba[m] = 0;
        let c = hex::encode(ba);
        BigUint::from_bytes_be(&hex::decode(c).unwrap())
    }

    fn pkcs1unpad2(&self, a: &BigUint) -> Vec<u8> {
        let mut b = a.to_str_radix(16);
        if b.len() % 2 != 0 {
            b = format!("0{}", b);
        }
        let c = hex::decode(&b).unwrap();
        let mut i = 1;
        while c[i] != 0 {
            i += 1;
        }
        let ret = &c[i + 1..];
        ret.to_vec()
    }

    fn encrypt(&self, chunk: &[u8]) -> String {
        let m = self.pkcs1pad2(chunk, 0x80);
        let c = self.modpow(&m, &self.e, &self.n);
        let mut h = c.to_str_radix(16);
        while h.len() < 0x80 * 2 {
            h.insert(0, '0');
        }
        h.to_uppercase()
    }

    fn decrypt(&self, chunk: &[u8]) -> Vec<u8> {
        let chunk_2 = hex::encode(chunk);
        let a = BigUint::parse_bytes(chunk_2.as_bytes(), 16).unwrap();
        let c = self.modpow(&a, &self.e, &self.n);
        self.pkcs1unpad2(&c)
    }
}

fn m115_getkey(length: usize, key: Option<&[u8]>) -> Vec<u8> {
    let ret = if let Some(key) = key {
        (0..length)
            .map(|i| {
                let (result, _) = key[i % length].overflowing_add(G_KTS[length * i]);
                (result & 0xff) ^ G_KTS[length * (length - 1 - i)]
            })
            .collect()
    } else {
        if length == 12 {
            G_KEY_L.to_vec()
        } else {
            G_KEY_S.to_vec()
        }
    };
    ret
}

fn xor115_enc(src: &[u8], key: &[u8]) -> Vec<u8> {
    let mut ret = Vec::with_capacity(src.len());
    let keylen = key.len();
    let mod4 = src.len() % 4;
    for i in 0..mod4 {
        ret.push(src[i] ^ key[i % keylen]);
    }
    for i in mod4..src.len() {
        ret.push(src[i] ^ key[(i - mod4) % keylen]);
    }
    ret
}

fn m115_sym_encode(src: &[u8], key1: Option<&[u8]>, key2: Option<&[u8]>) -> Vec<u8> {
    let k1 = m115_getkey(4, key1);
    let k2 = m115_getkey(12, key2);
    let mut ret = xor115_enc(src, &k1);
    ret.reverse();
    xor115_enc(&ret, &k2)
}

fn m115_sym_decode(src: &[u8], key1: Option<&[u8]>, key2: Option<&[u8]>) -> Vec<u8> {
    let k1 = m115_getkey(4, key1);
    let k2 = m115_getkey(12, key2);
    let mut ret = xor115_enc(src, &k2);
    ret.reverse();
    xor115_enc(&ret, &k1)
}

fn bytes_to_string(b: &[u8]) -> String {
    String::from_utf16(&b.iter().map(|x| *x as u16).collect::<Vec<_>>()).unwrap_or_default()
}

fn m115_asym_encode(rsa: &MyRsa, src: &[u8], srclen: usize) -> String {
    let mut i = 0_i32;
    let mut j = 0_i32;
    let m = 128 - 11;
    let mut ret = String::new();
    let ref_val = ((srclen as f64) + m as f64 - 1.0) / m as f64;
    let ref_val = ref_val.floor() as i32;
    while if ref_val >= 0 {
        j < ref_val
    } else {
        j > ref_val
    } {
        let beging = (i * m) as usize;
        let end = std::cmp::min(((i + 1) * m) as usize, srclen);
        let chunk = &src[beging..end];
        let encrypted_str = rsa.encrypt(chunk);
        ret.push_str(&encrypted_str);
        i = if ref_val >= 0 {
            j += 1;
            j
        } else {
            j -= 1;
            j
        };
    }
    let hex_vec_u8 = hex::decode(ret).unwrap();
    general_purpose::STANDARD.encode(hex_vec_u8)
}

fn m115_asym_decode(rsa: &MyRsa, src: &[u8], srclen: usize) -> Vec<u8> {
    let mut i = 0_i32;
    let mut j = 0_i32;
    let m = 128;
    let mut ret: Vec<u8> = vec![];
    let ref_val = ((srclen as f64) + m as f64 - 1.0) / m as f64;
    let ref_val = ref_val.floor() as i32;
    while if ref_val >= 0 {
        j < ref_val
    } else {
        j > ref_val
    } {
        let beging = (i * m) as usize;
        let end = std::cmp::min(((i + 1) * m) as usize, srclen);
        let chunk = &src[beging..end];
        let encrypted_vec_u8 = rsa.decrypt(chunk);
        ret.extend(encrypted_vec_u8);
        i = if ref_val >= 0 {
            j += 1;
            j
        } else {
            j -= 1;
            j
        };
    }
    ret
}

fn m115_encode(rsa: &MyRsa, src: &str, tm: u64) -> (String, Vec<u8>) {
    let format_key = format!("!@###@#{}DFDR@#@#", tm);
    let md5_value = md5::compute(format_key.as_bytes());
    let md5_str = format!("{:?}", md5_value);
    let tmp = src.as_bytes().to_vec();
    let key = md5_str.as_bytes().to_vec();
    let encrypted_tmp = m115_sym_encode(&tmp, Some(&key), None);
    let mut encrypted_data = Vec::new();
    encrypted_data.extend_from_slice(&key[0..16]);
    encrypted_data.extend_from_slice(&encrypted_tmp);
    (
        m115_asym_encode(rsa, &encrypted_data, encrypted_data.len()),
        key.to_vec(),
    )
}

fn m115_decode(rsa: &MyRsa, src: &str, key: &[u8]) -> String {
    let decoded_data = general_purpose::STANDARD.decode(src).unwrap();
    let decoded_data = m115_asym_decode(rsa, &decoded_data, decoded_data.len());
    let data = &decoded_data[16..];
    let key2 = &decoded_data[0..16];
    let data = m115_sym_decode(data, Some(key), Some(key2));
    let ret = bytes_to_string(&data);
    ret.to_string()
}

pub fn encode(data: &str, timestamp: u64) -> (String, Vec<u8>) {
    let rsa = MyRsa::new();
    m115_encode(&rsa, data, timestamp)
}

pub fn decode(data: &str, key: &[u8]) -> String {
    let rsa = MyRsa::new();
    m115_decode(&rsa, data, &key)
}

#[cfg(test)]
mod tests {
    use super::super::down_url::Response;
    use super::*;

    #[test]
    fn test_m115_decode() {
        // let tm = 1717219382;
        let key: [u8; 32] = [
            101, 97, 49, 57, 48, 48, 97, 53, 101, 54, 98, 99, 54, 53, 49, 54, 97, 98, 56, 50, 54,
            49, 48, 55, 52, 102, 97, 98, 49, 55, 49, 51,
        ];
        let data = "S08rrPkXjeXev6s3JSsb5Fk5cfSHfdn46YGrjlw+MCQYMk0/YLXZcylxUcQQOhv3w3RAFqVaCdPFDGZl9tHelbyVoH4LzcTcUQdwikjPkfk3osdwK1JZ+1GOCaqo07PvaFEDXZk3/nmGL7ETaSlhI1fCtpMcaNjxqbDEMylpDfsG8IzpgUG5uzEPaE3rXliF4hUuumOgDFidCue5FL5c7G3PzkN6cPtWZayP9aqtAWWEcqV0rK8i7gV7vAP8ZbmmcNTBFk9G5adc5GSLY7YrwV+AaQhbPcy+fKDtSWJi7vJcjJgctOaJCz7zzUXuoa+fJv3iFUP9R8TLWFE1w/czwX5pH9hcGw9XL5uFI/9lLk8mAFAcYrWnfdebmBO/ncCSnDfgtWss+egcaUsZFySjMbvPYz/SzASElFrc3F9njrw+aFVnrvNkABuUoRKNn3xm/U4oovzw6bmlQbLAwIoaDbAjt39U9iwJsa88DjxFlg3WYEEtHLHRPTUfO4oSxKRQKDzwSckuYkTPc2bAjPh0gwpF2sBPlsWcoVcZ9l6IfAu7e4TE2jovpiT0uG9McBf4shbewwQqNCI/b3D9WDPN73clyILDMlu9lXIafXsKL+5xIoYBN4twb5Zd2aOfiqtuS3DAHOKzcXjDxzKog2qhpVJveu0f0VMIee5bbkT3eYoFI2p4lpKI8/i/chPhoQER9U9K/hg4g0HuZYEH1mMCMClyWpi4prFUDdvoD+BozNweU3A5kwX4DDN1bC350DZ83jDNmf8FVqmnABtGQoR3vfvmXWgf3MYzsRtUBF76T3wuW7++o2rmRQqiM8q9EZgpnAuOOLCNPZI2Fcj638G7ngLIHEjxOgpp1XZW29ZheyQ05bGVPb+M0KKZGQruQRWCX/ktZsf+tsdLBh9oN2DxeYMUDhGkEsZEMXtQJ2d3jKoEvZHNec8vzXRC55sAGVTgSNbotR5ltBjlD0VCz7sC8+Ftzi/0HcjyIM27M1+a3iliPGSHLlmyn5aKz13cFEo5";
        let rsa = MyRsa::new();
        let decoded_str = m115_decode(&rsa, data, &key);
        println!("解码结果为：{:#?}", decoded_str);
        if let Some((down_url, valid_timestamp)) = Response::from(decoded_str.as_str()) {
            let url = "https://cdnfhnfile.115.com/66569ab35a5375670a3b61b24f3e725110c076b1/%E5%BD%BB%E5%BA%95%E7%8E%A9%E8%BD%AC115%E7%9B%98cookie%E6%8C%82%E8%BD%BD%E6%95%99%E7%A8%8B.doc?t=1717221402&u=80001717&s=524288000&d=vip-3746103476-abjerdpwj1sv8hfio-1&c=0&f=3&k=d19e4f4df33457441aeafc90c6674ab6&us=5242880000&uc=10&v=1";
            assert_eq!(
                url, down_url,
                "解密出来获取到的 url 字符串不如预期，解密出错了"
            );
            assert_eq!(
                1717221402_i64, valid_timestamp,
                "解密出来获取到的 url 字符串不如预期，解密出错了"
            );
        } else {
            panic!("解释失败：{}", decoded_str);
        }
    }

    #[test]
    fn test_m115_encode() {
        let rsa = MyRsa::new();
        let pickcode = "abjerdpwj1sv8hfio";
        let data = format!("{{\"pickcode\":\"{}\"}}", pickcode);
        let tm = 1717219382;
        let (encoded_data, _key) = m115_encode(&rsa, data.as_str(), tm);
        assert_eq!("TWb3qXoGj0sRV4mDHiwpxOD9rSGeexU5rqh+4dgH7hCLbO9xOg2G178OaJsS/R7nV6Xu4qrhoOSpoDKbAOa2GuYy+EbnV/lkwq4PyBeYk4DPwFb/RjWDJ96l3Kf7Axv1HHkZArh01VQpgY3PkviAX7RX+SmFj88FXEJzNpKo2CU=",
		encoded_data.as_str(), "加密后的字符串不如预期，加密出错了");
    }
}
