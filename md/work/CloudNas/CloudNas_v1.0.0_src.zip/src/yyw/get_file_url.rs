use crate::{error_bail, warn_bail};
use anyhow::Result;
use serde_json::Value;
use url::Url;

use super::error;

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
}

impl Request {
    pub fn new(pickcode: &str) -> Self {
        let base_url = "http://proapi.115.com/app/chrome/down?method=get_file_url";
        Request {
            base_url: base_url.to_string(),
            url: format!("{}&pickcode={}", base_url, pickcode),
        }
    }
}

#[derive(Debug)]
pub struct Response {
    pub url: String,
    pub valid_timestamp: i64, // 小文件下载时限，15分钟
}

impl Response {
    pub fn new(data: &[u8]) -> Result<Self> {
        let mut parse_json_result = None;
        // 将 JSON 字符串解析为 serde_json::Value
        let parsed_data: Value = serde_json::from_slice(data).unwrap();
        // 访问 "data" 字段，它是一个对象
        if let Some(data_obj) = parsed_data.get("data") {
            // "data" 是一个 HashMap，我们需要遍历它
            if let Some(url_info) = data_obj.as_object() {
                // 遍历 HashMap
                for (_, value) in url_info {
                    // 检查 value 是否包含 "url" 字段
                    if let Some(url_value) = value.get("url") {
                        if let Some(url_value) = url_value.get("url") {
                            // 提取 "url" 字段
                            if let serde_json::Value::String(url) = url_value {
                                if let Ok(Some(valid_timestamp)) =
                                    Response::valid_timestamp_from(url)
                                {
                                    parse_json_result = Some(Response {
                                        url: url.to_string(),
                                        valid_timestamp,
                                    });
                                    break; // 如果只需要第一个找到的 URL，可以在这里中断循环
                                }
                            }
                        }
                    }
                }
            }
        }
        match parse_json_result {
            Some(response) => Ok(response),
            None => {
                let (is_error, desc) = error::Response::exact_desc(&data, "获取小文件的下载链接");
                if is_error {
                    error_bail!(desc);
                } else {
                    warn_bail!(desc);
                }
            }
        }
    }

    // 解析 URL 里的 t 参数为有效时间戳
    fn valid_timestamp_from(url: &str) -> anyhow::Result<Option<i64>> {
        let parsed_url = Url::parse(url)?;
        // 获取查询参数
        let query_pairs = parsed_url.query_pairs();
        // 查找参数 't' 的值
        for (key, value) in query_pairs {
            if key == "t" {
                // 将值从Cow<'_, str>转换为String并解释为 u64
                let valid_timestamp = value.to_string().parse::<i64>()?;
                return Ok(Some(valid_timestamp));
            }
        }
        // 如果没有找到 't' 参数，返回 None
        Ok(None)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_read_file() {
        let json_str = r#"{
  "state": true,
  "msg": "",
  "errno": 0,
  "data": {
    "2910650348655228983": {
      "file_name": "tauri_event.txt",
      "file_size": 160,
      "pick_code": "e2sf885dc7b7uzl3g",
      "url": {
        "url": "https://cdnfhnfile.115.com/66573a2caea064e2c2c9a5902a63c94eb0e67fbe/tauri_event.txt?t=1716998703&u=80001717&s=524288000&d=vip-3746103476-e2sf885dc7b7uzl3g-1&c=0&f=3&k=1a9e41a37c724a874865e6708dbebc75&us=5242880000&uc=10&v=1",
        "client": 3,
        "desc": null,
        "isp": null,
        "oss_id": "fhnfile/66573a2caea064e2c2c9a5902a63c94eb0e67fbe",
        "ooid": ""
      }
    }
  }
}"#;
        if let Ok(response) = Response::new(&json_str.to_string().into_bytes()) {
            assert_eq!(response.url, "https://cdnfhnfile.115.com/66573a2caea064e2c2c9a5902a63c94eb0e67fbe/tauri_event.txt?t=1716998703&u=80001717&s=524288000&d=vip-3746103476-e2sf885dc7b7uzl3g-1&c=0&f=3&k=1a9e41a37c724a874865e6708dbebc75&us=5242880000&uc=10&v=1", "提取出来的 url 不一致");
        } else {
            println!("没有提取出来 url");
        }
    }
}
