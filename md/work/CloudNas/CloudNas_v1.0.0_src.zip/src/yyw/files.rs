use super::error;
use crate::warn_bail;
use anyhow::{bail, Result};
use serde_derive::Deserialize;
use serde_json::Value;

pub const LIMIT_DEFAULT: u64 = 36; // 不能小于 3 ，否则 offset=3， limite=x 时会返回前 3+x 个， offset=2 时只返回1个

// 用这个工具网站把 json 转为 rust 代码： https://transform.tools/json-to-rust-serde
// Payload（有效载荷）：在编程中，"payload" 通常指传输中携带的数据部分，即有效载荷。
// 在网络通信、消息传递或数据传输中，"payload" 是指除去协议头部等元数据之外的实际数据内容。
// 在某些情况下，"payload" 可以表示传输中需要处理或解析的主要数据。
#[derive(Debug, Clone)]
pub struct Payload {
    pub cid: String, // 文件夹 id，不公开，需要调用 set_cid 方法，把 ROOT_CID 换成 0
    pub offset: u64, // 默认 LIMIT_DEFAULT， 索引偏移，索引从 0 开始计算 ，自己保证 ofsset 不要超出文件夹返回的 count 数字范围，否则会返回 offset 为 0 时的数据
    pub asc: i32,    // 0 | 1 默认 1 是否升序排列
    pub o: String,   /* 用某字段排序： -
                         # 文件名："file_name"
                         # - 文件大小："file_size"
                         # - 文件种类："file_type"
                         # - 修改时间："user_utime"
                         # - 创建时间："user_ptime"
                         # - 上次打开时间："user_otime"
                     */
    pub r#type: i32,   /*  int | str = <default>
                          # 文件类型：
                          # - 所有: 0
                          # - 文档: 1
                          # - 图片: 2
                          # - 音频: 3
                          # - 视频: 4
                          # - 压缩包: 5
                          # - 应用: 6
                          # - 书籍: 7
                       */
    pub show_dir: i32, // 0 | 1 默认 1
}

impl Default for Payload {
    fn default() -> Self {
        Payload {
            cid: "0".to_string(),
            offset: 0,
            o: "file_name".to_string(),
            asc: 0,
            r#type: 1,
            show_dir: 1,
        }
    }
}

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
}

impl Request {
    pub fn new(payload: &Payload) -> Self {
        let base_url = "https://aps.115.com/natsort/files.php";
        Request {
			base_url: base_url.to_string(),
			// 这个网址返回错误：https://webapi.115.com/files?aid=1&cid=0&o=user_ptime&asc=0&offset=0&show_dir=1&limit=30&code=&scid=&snap=0&natsort=1&star=&source=&format=json&record_open_time=1&count_folders=1&type=&is_share=&suffix=&custom_order=&fc_mix="
        	// 错误是： {"count":6,"order":"file_name","is_asc":1,"fc_mix":0,"state":false,"error":"","errNo":20130827} ，估计是 20130827 弃用这个接口
			url:  format!("{}?aid=1&cid={}&o={}&asc={}&offset={}&show_dir={}&limit={}&code=&scid=&snap=0&natsort=1&record_open_time=1&count_folders=1&type=&source=&format=json&fc_mix=0&star=&is_q=&is_share=&suffix=&custom_order=",							
				base_url, payload.cid, payload.o, payload.asc, payload.offset, payload.show_dir, LIMIT_DEFAULT,
			),
		}
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Data {
    pub cid: String,
    pub n: String,
    pub fid: Option<String>,
    pub pid: Option<String>,
    #[serde(rename = "s")] // 文件或文件夹大小
    pub size: Option<usize>,
    #[serde(rename = "te")]
    // 文件夹 "t": "1715390112"，而文件 "t": "2024-05-29 22:22", "te" :"1715390112" 文件和文件夹都有 te
    pub create_time: String, // 创建的时间戳
}
/*pub struct Data {
    pub cid: String,
    pub aid: Value,
    pub pid: Option<String>,
    pub n: String,
    pub m: i64,
    pub cc: Option<String>,
    pub sh: Value,
    pub pc: String,
    pub t: String,
    pub te: String,
    pub tu: String,
    pub tp: String,
    pub to: Value,
    pub e: String,
    pub p: i64,
    pub ns: Option<String>,
    pub u: Option<String>,
    pub fc: Option<i64>,
    pub fdes: i64,
    pub hdf: i64,
    pub ispl: Option<i64>,
    pub fvs: i64,
    #[serde(rename = "check_code")]
    pub check_code: i64,
    #[serde(rename = "check_msg")]
    pub check_msg: String,
    pub fuuid: i64,
    pub fl: Vec<Value>,
    pub issct: i64,
    pub score: i64,
    pub fid: Option<String>,
    pub uid: Option<i64>,
    pub s: Option<i64>,
    pub sta: Option<i64>,
    pub pt: Option<String>,
    pub d: Option<i64>,
    pub c: Option<i64>,
    pub ico: Option<String>,
    pub class: Option<String>,
    pub fatr: Option<String>,
    pub sha: Option<String>,
    pub q: Option<i64>,
    pub et: Option<i64>,
    pub epos: Option<String>,
    pub iv: Option<i64>,
    pub vdi: Option<i64>,
    #[serde(rename = "play_long")]
    pub play_long: Option<i64>,
}*/

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Path {
    pub cid: Value,
    pub pid: Value,
    pub name: String,
}
/*pub struct Path {
    pub name: String,
    pub aid: Value,
    pub cid: Value,
    pub pid: Value,
    pub isp: Value,
    #[serde(rename = "p_cid")]
    pub p_cid: Option<String>,
    pub iss: Option<String>,
    pub fv: Option<String>,
    pub fvs: Option<String>,
}*/

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub data: Vec<Data>,
    pub cid: Value,
    pub count: u64,
    pub offset: i64,
    pub limit: i64,
    #[serde(rename = "sys_count")]
    pub sys_count: i64,
    #[serde(rename = "file_count")]
    pub file_count: Option<u64>,
    #[serde(rename = "folder_count")]
    pub folder_count: Option<u64>,
    #[serde(rename = "page_size")]
    pub page_size: i64,
}
/*pub struct Response {
    pub data: Vec<Data>,
    pub cid: Value,
    pub count: i64,
    #[serde(rename = "sys_count")]
    pub sys_count: i64,
    #[serde(rename = "file_count")]
    pub file_count: Option<i64>,
    #[serde(rename = "folder_count")]
    pub folder_count: Option<i64>,
    #[serde(rename = "page_size")]
    pub page_size: i64,
    pub aid: String,
    #[serde(rename = "is_asc")]
    pub is_asc: i64,
    pub star: i64,
    #[serde(rename = "is_share")]
    pub is_share: i64,
    #[serde(rename = "type")]
    pub type_field: i64,
    #[serde(rename = "is_q")]
    pub is_q: i64,
    #[serde(rename = "r_all")]
    pub r_all: i64,
    pub stdir: i64,
    pub cur: i64,
    #[serde(rename = "min_size")]
    pub min_size: i64,
    #[serde(rename = "max_size")]
    pub max_size: i64,
    #[serde(rename = "record_open_time")]
    pub record_open_time: String,
    pub path: Vec<Path>,
    pub fields: String,
    pub order: String,
    #[serde(rename = "fc_mix")]
    pub fc_mix: i64,
    #[serde(rename = "cost_time_1")]
    pub cost_time_1: f64,
    pub natsort: i64,
    pub uid: i64,
    pub offset: i64,
    pub limit: i64,
    pub suffix: String,
    #[serde(rename = "cost_time_2")]
    pub cost_time_2: f64,
    #[serde(rename = "cost_time_3")]
    pub cost_time_3: f64,
    #[serde(rename = "cost_time_4")]
    pub cost_time_4: f64,
    #[serde(rename = "cost_time_5")]
    pub cost_time_5: f64,
    #[serde(rename = "cost_time_6")]
    pub cost_time_6: f64,
    pub state: bool,
    pub error: String,
    pub err_no: i64,
}*/

impl Response {
    pub fn new(data: &[u8]) -> Result<Response> {
        match serde_json::from_slice::<Response>(&data) {
            Ok(response) => Ok(response),
            Err(_err) => {
                let (parse_error, desc) = error::Response::exact_desc(&data, "获取文件列表");
                if parse_error {
                    warn_bail!(desc);
                } else {
                    bail!(desc)
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_deserialze() {
        let files_json_list = vec![
            r#"{"data":[{"cid":"2897207187060701480","aid":"1","pid":"2897206606225095416","n":"\u66f4\u591a\u4f18\u8d281-12\u5c81\u82f1\u8bed\u8bed\u6587\u6570\u5b66\u542f\u8499\u63d0\u5347\u6559\u7a0b\u5173\u6ce8\u6dd8\u5b9d\u5e97\uff1a\u5b66\u4e60\u6b65\u6b65\u9ad8\u6559\u80b2\u5c0f\u5e97","m":0,"cc":"","sh":"0","pc":"fbbwc4xca33iikws6t","t":"1715390010","te":"1715390010","tu":"1715414154","tp":"1715390010","to":0,"e":"","p":0,"ns":"\u66f4\u591a\u4f18\u8d281-12\u5c81\u82f1\u8bed\u8bed\u6587\u6570\u5b66\u542f\u8499\u63d0\u5347\u6559\u7a0b\u5173\u6ce8\u6dd8\u5b9d\u5e97\uff1a\u5b66\u4e60\u6b65\u6b65\u9ad8\u6559\u80b2\u5c0f\u5e97","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206701544848220","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E06.The.Day.Off.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":7673,"sta":1,"pt":"0","pc":"e2z8wwo01xzvjzl3g","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389952","tp":"1715389952","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"EE9BD43237887441FB40F0B94E09C235A86A83E9","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206727683750767","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E01.The.Being.Quiet.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8150,"sta":1,"pt":"0","pc":"e2z8wwc0dg8hvzl3g","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389955","tp":"1715389955","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"F0CF98C0A4CBC6D025A64F684ACCA9762B28B621","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206711292410725","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E03.The.Tooth.Brushing.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8708,"sta":1,"pt":"0","pc":"e2z8wwiw5pss0zl3g","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389953","tp":"1715389953","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"F18E8A6EFF7A6DDE4ED4E0A6054A48D421A1B32A","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206708104739682","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E08.The.Big.Day.Out.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8817,"sta":1,"pt":"0","pc":"abh0ttqb49iwkhfio","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389953","tp":"1715389953","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"0273C5094885A7C01CE638A747F24469E5C9B145","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206718808603496","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E07.The.Pen.Pal.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8828,"sta":1,"pt":"0","pc":"ba8c33mn4k2bw8s6t","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389954","tp":"1715389954","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"0B838A4A91166A64F7962F5B86017624926FB02F","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206606459976443","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E10.The.Cheese.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8901,"sta":1,"pt":"0","pc":"cvdambdydarxpdxuy","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389941","tp":"1715389941","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"16BB136576B110D9D59534A48CED7BB73FCB4CC8","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206722231155563","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E05.The.Get.Indoors.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":8925,"sta":1,"pt":"0","pc":"abh0ttr932e3vhfio","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389955","tp":"1715389955","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"3DC2DAD34556723D42989C62285B9419493DF901","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206724722572140","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E09.The.Tree.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":9038,"sta":1,"pt":"0","pc":"ba8c33nxut3gk8s6t","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389955","tp":"1715389955","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"9BA0FAD2E20FBD2D1A70FF7A419FF327A0454E73","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206730200333169","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E02.The.Duck.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":9090,"sta":1,"pt":"0","pc":"dsxv2240kfuktx5dr","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389955","tp":"1715389955","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"8AD7790E6090B60FDDC1952B9F4A6DEAE2FDAAD8","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897206714673019750","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E04.The.Camouflage.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.eng.srt","s":9420,"sta":1,"pt":"0","pc":"ba8c339a5z7iu8s6t","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389954","tp":"1715389954","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"srt","class":"JG_DOC","fatr":"0","fdes":0,"sha":"56A32DFF68ED43620EC446DFEBCC07A0570DE1FC","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"2897207176180676900","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E07.The.Pen.Pal.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":111403123,"sta":1,"pt":"0","pc":"dsxv2fzc5v2y8x5dr","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715390009","tp":"1715390009","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"7B69955C298D6FB12525F71E45A18DACC0E66094","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897207097260652774","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E04.The.Camouflage.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":117914241,"sta":1,"pt":"0","pc":"abh0tmge5l47rhfio","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715389999","tp":"1715389999","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"8C89D8D4285043B3FD38A0977CF38A1366F4AB9D","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897207113115121911","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E06.The.Day.Off.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":122830421,"sta":1,"pt":"0","pc":"abh0tmlzf6neuhfio","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715390001","tp":"1715390001","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"A3140767416082D80D35C609D10B5C2785938456","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897207065316833461","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E03.The.Tooth.Brushing.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":130479398,"sta":1,"pt":"0","pc":"ba8c3pyd5rwg68s6t","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715389995","tp":"1715389995","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"A1BD8BC8E5E804482EB7BA3AE6E96C26681CC397","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897206902292625437","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E10.The.Cheese.Badge.\u66f4\u591a\u4f18\u8d281-12\u5c81\u82f1\u8bed\u8bed\u6587\u6570\u5b66\u542f\u8499\u63d0\u5347\u6559\u7a0b\u5173\u6ce8\u6dd8\u5b9d\u5e97\uff1a\u5b66\u4e60\u6b65\u6b65\u9ad8\u6559\u80b2\u5c0f\u5e97.mkv","s":133339550,"sta":1,"pt":"0","pc":"e2z8wsrd110zizl3g","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389976","tp":"1715389976","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"9ACA60CD3E0709D2A3189F3D7724D7A498D721AE","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897206985977378905","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E05.The.Get.Indoors.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":144296194,"sta":1,"pt":"0","pc":"ba8c3sy6n774b8s6t","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715389986","tp":"1715389986","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"6273656F6F19E3A74210116B5BC6A8C5DD63BCD8","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897206821392890836","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E01.The.Being.Quiet.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":144844883,"sta":1,"pt":"0","pc":"abh0t9y32orgnhfio","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389966","tp":"1715389966","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"36BFDE791AECE4C5DB84F45376B9384198FF57DC","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897206736290462587","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E02.The.Duck.Badge.720p.iP.WEB-DL.AAC2.0.H.264-BTN.mkv","s":155501862,"sta":1,"pt":"0","pc":"ba8c33z1psw9l8s6t","p":0,"m":0,"t":"2024-05-11 09:12","te":"1715389956","tp":"1715389956","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"0A9BBAF08C961A7934EFFE3952259459CBB62DA9","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897207134699010311","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E08.The.Big.Day.Out.Badge.\u66f4\u591a\u4f18\u8d281-12\u5c81\u82f1\u8bed\u8bed\u6587\u6570\u5b66\u542f\u8499\u63d0\u5347\u6559\u7a0b\u5173\u6ce8\u6dd8\u5b9d\u5e97\uff1a\u5b66\u4e60\u6b65\u6b65\u9ad8\u6559\u80b2\u5c0f\u5e97.mkv","s":170104726,"sta":1,"pt":"0","pc":"cvdamptwzh3ucdxuy","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715390004","tp":"1715390004","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"90A466B0127D64852EF521B2F21C844E610DFC6D","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420},{"fid":"2897207081439738053","uid":80001717,"aid":1,"cid":"2897206606225095416","n":"Hey.Duggee.S03E09.The.Tree.Badge.\u66f4\u591a\u4f18\u8d281-12\u5c81\u82f1\u8bed\u8bed\u6587\u6570\u5b66\u542f\u8499\u63d0\u5347\u6559\u7a0b\u5173\u6ce8\u6dd8\u5b9d\u5e97\uff1a\u5b66\u4e60\u6b65\u6b65\u9ad8\u6559\u80b2\u5c0f\u5e97.mkv","s":191817753,"sta":1,"pt":"0","pc":"e2z8wbfs6fgrlzl3g","p":0,"m":0,"t":"2024-05-11 09:13","te":"1715389997","tp":"1715389997","tu":"1715414154","to":0,"d":1,"c":0,"sh":0,"e":"","ico":"mkv","class":"AVI","fatr":"0","fdes":0,"sha":"1215009DB6B8BC9277E9BAE90A513C747ACFE8AA","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":3,"play_long":420}],"count":21,"sys_count":0,"file_count":20,"folder_count":1,"page_size":30,"aid":"1","cid":"2897206606225095416","is_asc":1,"star":0,"is_share":0,"type":0,"is_q":0,"r_all":0,"stdir":0,"cur":0,"min_size":0,"max_size":0,"record_open_time":"1","path":[{"name":"\u6839\u76ee\u5f55","aid":1,"cid":0,"pid":0,"isp":0},{"cid":"2897206256512416243","name":"\u52a8\u753b\u7247","aid":"1","pid":"0","p_cid":"84365","isp":"0","iss":"0","fv":"","fvs":"0"},{"cid":"2897206606225095416","name":"Hey Duggee Season 03","aid":"1","pid":"2897206256512416243","p_cid":"84368","isp":"0","iss":"0","fv":"","fvs":"0"}],"fields":"","order":"file_size","fc_mix":0,"cost_time_1":0.011512041091918945,"natsort":1,"uid":80001717,"offset":0,"limit":30,"suffix":"","cost_time_2":0.011918067932128906,"cost_time_3":0.014026880264282227,"cost_time_4":0.014032840728759766,"cost_time_5":0.0175628662109375,"cost_time_6":0.03505396842956543,"state":true,"error":"","errNo":0}"#,
            r#"{"data":[{"cid":"1916193073742740623","aid":"1","pid":"1916192629398174910","n":"PPS\u7cfb\u5217","m":1,"cc":"","sh":"0","pc":"fc8idqtmit8xldrm9y","t":"1598429324","te":"1598429324","tu":"1715389607","tp":"1598429324","to":0,"e":"","p":0,"ns":"PPS\u7cfb\u5217","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"1989350118414875986","aid":"1","pid":"2897194533113969219","n":"123","m":1,"cc":"","sh":"0","pc":"fcabdytays9i20rm9y","t":"1623248828","te":"1623248828","tu":"1716018883","tp":"1607165013","to":"1716018883","e":"","p":0,"ns":"123","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2099399255201414490","aid":"1","pid":"2220670451130428093","n":"1\u3010\u4e07\u5bb6\u3011\u56fd\u4ea7\u79c1\u5bb6\u539f\u521b    270G","m":1,"cc":"","sh":"0","pc":"fca0z6ylerei74rm9y","t":"1620283868","te":"1620283868","tu":"1716289941","tp":"1620283868","to":"1716289941","e":"","p":0,"ns":"1\u3010\u4e07\u5bb6\u3011\u56fd\u4ea7\u79c1\u5bb6\u539f\u521b    270G","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2099399928546589731","aid":"1","pid":"2099399928353651738","n":"0.001(1)","m":1,"cc":"","sh":"0","pc":"fdvoljy868hj265ydr","t":"1623248777","te":"1623248777","tu":"1716340778","tp":"1620283971","to":"1716340778","e":"","p":0,"ns":"0.001(1)","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2171276699685481314","aid":"1","pid":"2215670810638936286","n":"7\u6708","m":1,"cc":"","sh":"0","pc":"faclvin7peblxr4fio","t":"1631459259","te":"1631459259","tu":"1715388799","tp":"1628852352","to":"1664433114","e":"","p":0,"ns":"7\u6708","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"fid":"1869128023333142089","uid":80001717,"aid":1,"cid":"1869132845247626685","n":"032416-267-C.mp4","s":2392457288,"sta":1,"pt":"0","pc":"awmds29x2jht4hfio","p":0,"m":1,"t":"2020-06-22 21:43","te":"1592833423","tp":"1592833423","tu":"1716175456","to":"1716175456","d":1,"c":0,"sh":0,"e":"","ico":"mp4","class":"AVI","fatr":"","fdes":0,"sha":"15F5DE7F1A838FBA90C7E8A350DA566BA4424B9A","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"current_time":358,"played_end":0,"last_time":"1716175461","vdi":4,"play_long":3551},{"fid":"2215636206792075826","uid":80001717,"aid":1,"cid":"2215295388101241343","n":"jul-423-C.mp4","s":4999520468,"sta":1,"pt":"0","pc":"ejmzh99daiacpzl3g","p":0,"m":1,"t":"2021-10-13 23:53","te":"1634140418","tp":"1634140418","tu":"1715578115","to":"1715578115","d":1,"c":0,"sh":0,"e":"","ico":"mp4","class":"AVI","fatr":"","fdes":0,"sha":"128182E4CB5819C91C525422A771B0BAACF5CDB7","q":0,"hdf":0,"et":0,"epos":"","fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"u":"","iv":1,"issct":0,"score":0,"vdi":4,"play_long":7111}],"count":7,"sys_count":0,"page_size":30,"aid":"1","cid":0,"is_asc":1,"star":1,"is_share":0,"type":0,"is_q":0,"r_all":0,"stdir":0,"cur":0,"min_size":0,"max_size":0,"record_open_time":"","path":[{"name":"\u6839\u76ee\u5f55","aid":1,"cid":0,"pid":0,"isp":0}],"fields":"","order":"file_size","fc_mix":0,"cost_time_1":0.0010039806365966797,"natsort":1,"uid":80001717,"offset":0,"limit":30,"suffix":"","cost_time_2":0.0010080337524414062,"cost_time_3":0.0012259483337402344,"cost_time_4":0.0012309551239013672,"cost_time_5":0.006417036056518555,"cost_time_6":0.014457941055297852,"state":true,"error":"","errNo":0}"#,
            r#"{"data":[{"cid":"2897206599363214033","aid":"1","pid":"2897206256512416243","n":"Hey Duggee Season 01","m":0,"cc":"","sh":"0","pc":"fbbwc4wtaapgx8ws6t","t":"1715390112","te":"1715390112","tu":"1716340606","tp":"1715389940","to":"1716340606","e":"","p":0,"ns":"Hey Duggee Season 01","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2897206603616238312","aid":"1","pid":"2897206256512416243","n":"Hey Duggee Season 02","m":0,"cc":"","sh":"0","pc":"fe23863t0t7nm73wqg","t":"1715390105","te":"1715390105","tu":"1716340851","tp":"1715389940","to":"1716340851","e":"","p":0,"ns":"Hey Duggee Season 02","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2897206606225095416","aid":"1","pid":"2897206256512416243","n":"Hey Duggee Season 03","m":0,"cc":"","sh":"0","pc":"fe2386n3vhca5l3wqg","t":"1715390009","te":"1715390009","tu":"1716340856","tp":"1715389941","to":"1716340856","e":"","p":0,"ns":"Hey Duggee Season 03","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0},{"cid":"2897207215481305661","aid":"1","pid":"2897206256512416243","n":"Yakka Dee!\u5168\u4e09\u5b63\u82f1\u6587\u539f\u7248\u52a8\u753b\u7247+\u540c\u6b65\u97f3\u9891","m":0,"cc":"","sh":"0","pc":"fbbwc4x0d3gt7sws6t","t":"1715390167","te":"1715390167","tu":"1715414154","tp":"1715390013","to":0,"e":"","p":0,"ns":"Yakka Dee!\u5168\u4e09\u5b63\u82f1\u6587\u539f\u7248\u52a8\u753b\u7247+\u540c\u6b65\u97f3\u9891","u":"","fc":0,"fdes":0,"hdf":0,"ispl":0,"fvs":0,"check_code":0,"check_msg":"","fuuid":80001717,"fl":[],"issct":0,"score":0}],"count":4,"sys_count":0,"file_count":0,"folder_count":4,"page_size":30,"aid":"1","cid":"2897206256512416243","is_asc":1,"star":0,"is_share":0,"type":0,"is_q":0,"r_all":0,"stdir":0,"cur":0,"min_size":0,"max_size":0,"record_open_time":"1","path":[{"name":"\u6839\u76ee\u5f55","aid":1,"cid":0,"pid":0,"isp":0},{"cid":"2897206256512416243","name":"\u52a8\u753b\u7247","aid":"1","pid":"0","p_cid":"84365","isp":"0","iss":"0","fv":"","fvs":"0"}],"fields":"","order":"file_size","fc_mix":0,"cost_time_1":0.011965036392211914,"natsort":1,"uid":80001717,"offset":0,"limit":30,"suffix":"","cost_time_2":0.012479066848754883,"cost_time_3":0.028439044952392578,"cost_time_4":0.028448104858398438,"cost_time_5":0.0344240665435791,"cost_time_6":0.03645896911621094,"state":true,"error":"","errNo":0}"#,
        ];
        for files_json in files_json_list {
            let files = serde_json::from_str::<Response>(files_json);
            match files {
                Ok(files) => {
                    let files_str = format!("{:?}", files);
                    println!("{}", files_str);
                }
                Err(err) => println!("{:?}", err),
            }
        }
    }
}
