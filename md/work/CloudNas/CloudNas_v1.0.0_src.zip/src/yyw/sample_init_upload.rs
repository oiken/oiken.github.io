use super::error;
use crate::{error_bail, warn_bail};
use anyhow::Result;
use serde::Serialize;
use serde_derive::Deserialize;

// 此接口来自：https://github.com/ChenyangGao/web-mount-packs/blob/main/python-115-client/p115/component/client.py#L5930
/* python 例子
 def upload_file_sample_init(
        self,
        /,
        filename: str,
        pid: int = 0,
        *,
        async_: Literal[False, True] = False,
        **request_kwargs,
    ) -> dict | Coroutine[Any, Any, dict]:
        """网页端的上传接口的初始化，注意：不支持秒传
        POST https://uplb.115.com/3.0/sampleinitupload.php
        """
        api = "https://uplb.115.com/3.0/sampleinitupload.php"
        payload = {"filename": filename, "target": f"U_1_{pid}"}
        return self.request(url=api, method="POST", data=payload, async_=async_, **request_kwargs)

    没能从浏览器得到信息，自己运行后得到：
    {
    "object": "66a3b7dd0ba1c99f8ce71f11c0e4598e635474d3",
    "accessid": "LTAI5tMvF188zm8v4bVG2BQC",
    "host": "http://fhnfile.oss-cn-shenzhen.aliyuncs.com",
    "policy": "eyJleHBpcmF0aW9uIjoiMjAyNC0wNy0yNlQyMjo1MTozOVoiLCJjb25kaXRpb25zIjpbWyJjb250ZW50LWxlbmd0aC1yYW5nZSIsMCw1MzY4NzA5MTIwXV19",
    "signature": "amZMvrgfWjLVhP0JXSYsCHW3H6I=",
    "expire": 1722005499,
    "callback": "eyJjYWxsYmFja1VybCI6Imh0dHA6XC9cL3VwbGIuMTE1LmNvbVwvMy4wXC9zYW1wbGVjb21wbGV0ZXVwbG9hZC5waHAiLCJjYWxsYmFja0JvZHkiOiJzaGExPSR7c2hhMX0mZmlsZW5hbWU9JHtvYmplY3R9JmZpbGVzaXplPSR7c2l6ZX0mbWltZVR5cGU9JHttaW1lVHlwZX0maGVpZ2h0PSR7aW1hZ2VJbmZvLmhlaWdodH0md2lkdGg9JHtpbWFnZUluZm8ud2lkdGh9JnVzZXJpZD05OTEyOCZ0YXJnZXQ9JnVzZXJmbj0mYnVja2V0PWZobmZpbGUmdXNlcmlwPTEyMC4yMzEuMjA0LjIyNSZ1c2VycG9ydD0xODAwNiZzb3VyY2U9NSIsImNhbGxiYWNrQm9keVR5cGUiOiJhcHBsaWNhdGlvblwveC13d3ctZm9ybS11cmxlbmNvZGVkIn0="
}

    这个只是初始化一个上传，如果没有后续，就是创建新文件，如果上传，需要调用另一个 api： move_progress
*/

#[derive(Debug, Clone, Serialize)]
pub struct Payload {
    target: String,
    filename: String,
}

impl Payload {
    pub fn new(parent_cid: u64, filename: &str) -> Payload {
        Payload {
            target: format!("U_1_{}", parent_cid),
            filename: filename.to_string(),
        }
    }
}

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
    pub post_data: String,
}

impl Request {
    pub fn new(payload: &Payload) -> Result<Self> {
        let base_url = "https://uplb.115.com/3.0/sampleinitupload.php".to_string();
        match serde_json::to_string(payload) {
            Err(err) => {
                warn_bail!("把 {:?} 序列话成 json 时出错：{:?}", payload, err);
            }
            Ok(post_data) => Ok(Request {
                base_url: base_url.clone(),
                url: base_url,
                post_data,
            }),
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub error: String,
    // pub errno: String,  不要，在 files_batch_move 接口里返回空字符串，不要反正没什么用
    // aid: u64,
    pub cid: String,
    pub cname: String,
    // file_id: String,
    // file_name: String,
}
/* Response 范例
{
    "object": "66a3b7dd0ba1c99f8ce71f11c0e4598e635474d3",
    "accessid": "LTAI5tMvF188zm8v4bVG2BQC",
    "host": "http://fhnfile.oss-cn-shenzhen.aliyuncs.com",
    "policy": "eyJleHBpcmF0aW9uIjoiMjAyNC0wNy0yNlQyMjo1MTozOVoiLCJjb25kaXRpb25zIjpbWyJjb250ZW50LWxlbmd0aC1yYW5nZSIsMCw1MzY4NzA5MTIwXV19",
    "signature": "amZMvrgfWjLVhP0JXSYsCHW3H6I=",
    "expire": 1722005499,
    "callback": "eyJjYWxsYmFja1VybCI6Imh0dHA6XC9cL3VwbGIuMTE1LmNvbVwvMy4wXC9zYW1wbGVjb21wbGV0ZXVwbG9hZC5waHAiLCJjYWxsYmFja0JvZHkiOiJzaGExPSR7c2hhMX0mZmlsZW5hbWU9JHtvYmplY3R9JmZpbGVzaXplPSR7c2l6ZX0mbWltZVR5cGU9JHttaW1lVHlwZX0maGVpZ2h0PSR7aW1hZ2VJbmZvLmhlaWdodH0md2lkdGg9JHtpbWFnZUluZm8ud2lkdGh9JnVzZXJpZD05OTEyOCZ0YXJnZXQ9JnVzZXJmbj0mYnVja2V0PWZobmZpbGUmdXNlcmlwPTEyMC4yMzEuMjA0LjIyNSZ1c2VycG9ydD0xODAwNiZzb3VyY2U9NSIsImNhbGxiYWNrQm9keVR5cGUiOiJhcHBsaWNhdGlvblwveC13d3ctZm9ybS11cmxlbmNvZGVkIn0="
}
*/

impl Response {
    pub fn new(data: &[u8]) -> Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response),
                Err(_) => {
                    let (is_error, desc) = error::Response::exact_desc(&data, "新建文件夹");
                    if is_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response {
                state: false,
                error: "返回数据为空字符串".to_string(),
                cid: "".to_string(),
                cname: "".to_string(),
            })
        }
    }
}
