use super::error;
use crate::{error_bail, warn_bail};
use serde_derive::Deserialize;

// 此接口来自：https://github.com/ChenyangGao/web-mount-packs/blob/main/python-115-client/p115/component/client.py#L394
/*
    从浏览器得到：
    Request URL: URL: https://webapi.115.com/files/move_progress?move_proid=1721863032834_-88_4
    headers: Accept: application/json, text/javascript, *//*; q=0.01    # 因此需要限制，不能得到 js
    Request Method: GET

    返回：  {"state":true,"error":"","errno":"","progress":100}
*/

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
}

impl Request {
    pub fn new(move_proid: &str) -> Self {
        let base_url = "https://webapi.115.com/files/move_progress".to_string();
        let url = format!("{}?move_proid={}", base_url, move_proid);
        Request { base_url, url }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub error: String,
    pub progress: usize,
}
/* Response 范例
{"state":true, "error":"","errno":"","progress":100}
*/

impl Response {
    pub fn new(data: &[u8]) -> anyhow::Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response),
                Err(_) => {
                    let (parse_error, desc) =
                        error::Response::exact_desc(&data, "获取移动文件或文件夹的进度");
                    if parse_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response {
                state: false,
                error: "返回数据为空字符串".to_string(),
                progress: 0,
            })
        }
    }
}

#[cfg(test)]
mod tests {
    // use super::*;

    #[tokio::test]
    async fn test_batch_name() {}
}
