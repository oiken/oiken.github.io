use serde_derive::Deserialize;

#[derive(Debug)]
pub struct Request {
    pub url: String,
    pub headers: hyper::HeaderMap,
}

impl Request {
    pub fn new(url: &str, offset: u64, length: usize) -> Self {
        let mut headers = hyper::HeaderMap::new();
        if let Ok(accept) = "*/*".parse() {
            headers.insert(hyper::header::ACCEPT, accept);
        }
        // ACCEPT_ENCODING, "identity" 代表是原始数据，没有经过压缩
        if let Ok(encoding) = "identity".parse() {
            headers.insert(hyper::header::ACCEPT_ENCODING, encoding);
        }
        if length > 0 {
            // 请求第一个文件的前 500 个字节： Range: bytes=0-499  所以要减去 1   ： offset + length - 1 as u64
            if let Ok(range) = format!("bytes={}-{}", offset, offset + length as u64 - 1).parse() {
                headers.insert(hyper::header::RANGE, range);
            }
        }
        Request {
            url: url.to_string(),
            headers,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub status: i64,
    pub message: String,
    // #[serde(rename = "request_id")]
    // pub request_id: String,
}
/*
{"status":403,"message":"request expired","request_id":"6661AD5739C1133936435174"}
*/

impl Response {
    pub fn new(data: &[u8]) -> anyhow::Result<Self> {
        match serde_json::from_slice(data) {
            Ok(response) => Ok(response),
            Err(err) => Err(err.into()),
        }
    }
}
