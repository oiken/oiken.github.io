use super::error;
use crate::{error_bail, warn_bail};
use anyhow::Result;
use hyper::HeaderMap;
use serde_derive::Deserialize;

// 此接口来自：https://github.com/ChenyangGao/web-mount-packs/blob/main/python-115-client/p115/component/client.py#L1839
/* python 例子
 def fs_mkdir(
        self,
        payload: str | dict,
        /,
        async_: Literal[True],
        **request_kwargs,
    ) -> Coroutine[Any, Any, dict]:
        ...
    def fs_mkdir(
        self,
        payload: str | dict,
        /,
        async_: Literal[False, True] = False,
        **request_kwargs,
    ) -> dict | Coroutine[Any, Any, dict]:
        """新建文件夹
        POST https://webapi.115.com/files/add
        payload:
            - cname: str
            - pid: int | str = 0
        """
        api = "https://webapi.115.com/files/add"
        if isinstance(payload, str):
            payload = {"pid": 0, "cname": payload}
        else:
            payload = {"pid": 0, **payload}
        return self.request(url=api, method="POST", data=payload, async_=async_, **request_kwargs)

    从浏览器得到：
    Request URL: URL: https://webapi.115.com/files/add
    headers: Accept: *//*
             Content-Type: application/x-www-form-urlencoded
    Request Method: POST
    Status Code: 200 OK
    Remote Address: 47.113.23.100:443
    Referrer Policy: strict-origin-when-cross-origin

    Form Data: pid=562212489316642031&cname=%E7%9A%84%E5%95%8A
    解码：
        pid: 863442248979926752
        cname: 的啊
    返回：{"state":true,"error":"","errno":"","aid":1,"cid":"2951963397299633630","cname":"\u7684\u554a","file_id":"2951963397299633630","file_name":"\u7684\u554a"}

    move_proid 可以调用另一个 api： move_progress
*/

#[derive(Debug, Clone)]
pub struct Payload {
    parent: u64,
    cname: String,
}

impl Payload {
    pub fn new(parent: u64, cname: &str) -> Payload {
        Payload {
            parent,
            cname: cname.to_string(),
        }
    }

    // 举例： pid=562212489316642031&cname=%E7%9A%84%E5%95%8A
    pub fn to_string(&self) -> String {
        let decoded_name = urlencoding::encode(&self.cname);
        format!("pid={}&cname={}", self.parent, decoded_name)
    }
}

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
    pub headers: HeaderMap,
    pub post_data: String,
}

impl Request {
    pub fn new(payload: &Payload) -> Self {
        let base_url = "https://webapi.115.com/files/add".to_string();
        let mut headers = hyper::HeaderMap::new();
        if let Ok(accetp) = "*/*".parse() {
            headers.insert(hyper::header::ACCEPT, accetp);
        }
        // x-www-form-urlencoded 表示数据已经经过 url 编码 必须设置这个，否则返回错误
        if let Ok(content_type) = "application/x-www-form-urlencoded".parse() {
            headers.insert(hyper::header::CONTENT_TYPE, content_type);
        }
        let post_data = payload.to_string();
        Request {
            base_url: base_url.clone(),
            url: base_url,
            headers,
            post_data,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub error: String,
    // pub errno: String,  不要，在 files_batch_move 接口里返回空字符串，不要反正没什么用
    // aid: u64,
    pub cid: String,
    pub cname: String,
    // file_id: String,
    // file_name: String,
}
/* Response 范例
{"state":true,"error":"","errno":"","aid":1,"cid":"2951963397299633630","cname":"\u7684\u554a","file_id":"2951963397299633630","file_name":"\u7684\u554a"}
*/

impl Response {
    pub fn new(data: &[u8]) -> Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response),
                Err(_) => {
                    let (is_error, desc) = error::Response::exact_desc(&data, "新建文件夹");
                    if is_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response {
                state: false,
                error: "返回数据为空字符串".to_string(),
                cid: "".to_string(),
                cname: "".to_string(),
            })
        }
    }
}
