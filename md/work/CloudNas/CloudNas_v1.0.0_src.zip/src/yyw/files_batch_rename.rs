use super::error;
use crate::{error_bail, warn_bail};
use hyper::HeaderMap;
use serde_derive::Deserialize;
use std::collections::HashMap;

// 此接口来自：https://github.com/ChenyangGao/web-mount-packs/blob/main/python-115-client/p115/component/client.py#L394
/* python 例子
 def fs_batch_rename(
        self,
        payload: dict | Iterable[tuple[int | str, str]],
        /,
        async_: Literal[False, True] = False,
        **request_kwargs,
    ) -> dict | Coroutine[Any, Any, dict]:
        """重命名文件或文件夹
        POST https://webapi.115.com/files/batch_rename
        payload:
            - files_new_name[{file_id}]: str # 值为新的文件名（basename）
        """
        api = "https://webapi.115.com/files/batch_rename"
        if not isinstance(payload, dict):
            payload = {f"files_new_name[{fid}]": name for fid, name in payload}
        if not payload:
            return {"state": False, "message": "no op"}
        return self.request(url=api, method="POST", data=payload, async_=async_, **request_kwargs)

    从浏览器得到：
    Request URL: https://webapi.115.com/files/batch_rename
    Request Method: POST
    Status Code: 200 OK
    Remote Address: 47.113.23.100:443
    Referrer Policy: strict-origin-when-cross-origin
    Form Data: files_new_name%5B2901082468473895994%5D=20241.log

    所以要改上面的 payload = {f"files_new_name[{fid}]": name for fid, name in payload} 的冒号为等号 =
    代码如下：
    ```
    let url_encoded_data_key = urlencoding::encode(&data_key);
    let data_value = payload.name.clone();
    let url_encoded_data_value = urlencoding::encode(&data_value);
    let post_data = format!("{}={}", url_encoded_data_key, url_encoded_data_value);
    ```
    否则改名等于把名字删光了，你也找不着，因为文件的话只有后缀，macos 下是默认隐藏的比如  .cargo
*/

#[derive(Debug, Default, Clone)]
pub struct Payload {
    pub fid: u64,
    pub name: String,
}

#[derive(Debug)]
pub struct Request {
    pub base_url: String,
    pub url: String,
    pub headers: HeaderMap,
    pub post_data: String,
}
/*范例
post_data为： files_new_name%5B2901082468473895994%5D=20241.log
*/

impl Request {
    pub fn new(payload: &Payload) -> Self {
        let base_url = "https://webapi.115.com/files/batch_rename".to_string();
        let mut headers = hyper::HeaderMap::new();
        if let Ok(accetp) = "*/*".parse() {
            headers.insert(hyper::header::ACCEPT, accetp);
        }
        // x-www-form-urlencoded 表示数据已经经过 url 编码 必须设置这个，否则返回错误
        if let Ok(content_type) = "application/x-www-form-urlencoded".parse() {
            headers.insert(hyper::header::CONTENT_TYPE, content_type);
        }
        let data_key = format!("files_new_name[{}]", payload.fid);
        let url_encoded_data_key = urlencoding::encode(&data_key);
        let data_value = payload.name.clone();
        let url_encoded_data_value = urlencoding::encode(&data_value);
        let post_data = format!("{}={}", url_encoded_data_key, url_encoded_data_value);
        Request {
            base_url: base_url.clone(),
            url: base_url,
            headers,
            post_data,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Response {
    pub state: bool,
    pub error: String,
    pub data: HashMap<u64, String>,
    // pub errno: i32, 不要，在 files_move 接口里返回空字符串，不要反正没什么用
}
/* Response 范例
{"state":true,"error":"","errno":0,"data":{"2901082468473895994":"20241.log"}}
*/

impl Response {
    pub fn new(data: &[u8]) -> anyhow::Result<Response> {
        if data.len() > 0 {
            match serde_json::from_slice::<Response>(&data) {
                Ok(response) => Ok(response), // 解码出来把服务器返回原因当错误信息往上传递
                Err(_) => {
                    let (parse_error, desc) =
                        error::Response::exact_desc(&data, "批量重命名文件或文件夹");
                    if parse_error {
                        error_bail!(desc);
                    } else {
                        warn_bail!(desc);
                    }
                }
            }
        } else {
            Ok(Response {
                data: HashMap::new(),
                state: false,
                error: "返回数据为空字符串".to_string(),
            })
        }
    }
}

#[cfg(test)]
mod tests {
    // use super::*;

    #[tokio::test]
    async fn test_batch_name() {}
}
