use crate::{
    error,
    fuse::file_sys::mount,
    setting::{self, SETTING},
    util::Timestamp,
    warn,
    yyw::api::{API, API_TIMEOUT_SECONDS},
};
use anyhow::Result;
use futures_util::TryStreamExt;
use http_body_util::{combinators::BoxBody, BodyExt, Full, StreamBody};
use hyper::{
    body::{Bytes, Frame, Incoming},
    header, HeaderMap, Method, Request, Response, StatusCode,
};
use hyper::{server::conn::http1, service::service_fn};
use hyper_util::rt::TokioIo;
use std::{
    net::SocketAddr,
    path::PathBuf,
    time::{Duration, SystemTime},
};
use tokio::net::TcpListener;
use tokio::{fs::File, sync::mpsc::Sender, time::timeout};
use tokio_util::io::ReaderStream;

type BoxedResponse = Response<BoxBody<Bytes, std::io::Error>>;
pub const FUSE_DIR_115_NAME: &str = "115";
const FUSE_115_DIR_API_PATH: &str = "fuse_115_dir";
const FUSE_115_DIR_API_FOR_JS: &str = "fetch115Dir";
const FILE_SIZE_GB: f64 = 1024.0 * 1024.0 * 1024.0;
const FILE_SIZE_MB: f64 = 1024.0 * 1024.0;

// shutdown_sender: Sender<bool> 发送关机信息，参数 bool = true 表明因 error 退出，false 表明是关机请求
pub async fn run(shutdown_sender: Sender<bool>) -> Result<()> {
    let port = get_service_port().await;
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    let listener = TcpListener::bind(addr).await?;
    println!(
        "界面服务器已开启：请访问：http://127.0.0.1:{0} 或：http://您的ip地址:{0}",
        port
    );
    loop {
        let (tcp_stream, _) = listener.accept().await?;
        let tokio_io = TokioIo::new(tcp_stream);
        // 进入一个新连接，复制一个 shutdown_sender 给新连接专用
        let shutdown_sender_clone = shutdown_sender.clone();
        tokio::task::spawn(async move {
            if let Err(err) = http1::Builder::new()
                .serve_connection(
                    tokio_io,
                    service_fn(move |req| {
                        Service::service_handler(req, shutdown_sender_clone.clone())
                    }),
                )
                .await
            {
                error!("出错: 界面服务器 http_1, 原因：{:?}", err);
            }
        });
    }
}

pub async fn get_service_port() -> u16 {
    let setting = SETTING.read().await;
    setting.ui_service_port()
}

#[derive(Debug)]
pub struct Service;

impl Service {
    pub async fn service_handler(
        req: Request<Incoming>,
        shutdown_sender: Sender<bool>,
    ) -> Result<BoxedResponse> {
        let fuse_115_dir_api_name = format!("/{}", FUSE_115_DIR_API_PATH);
        let path = req.uri().path();
        match (req.method(), path) {
            (&Method::GET, "/")
            | (&Method::GET, "/index.html")
            | (&Method::GET, "/public/index.html") => {
                Self::sent_public_file("public/index.html").await
            }
            (&Method::GET, path) if path.starts_with("/public/") => {
                let path = &path[1..];
                Self::sent_public_file(path).await
            }
            (&Method::GET, path) if path.starts_with(&fuse_115_dir_api_name) => {
                let path = &path[1..];
                Self::send_fuse_115_dir(path).await
            }
            (&Method::GET, "/reboot") => Self::sent_reboot(shutdown_sender.clone()).await,
            (&Method::GET, "/remount") => Self::sent_remount(shutdown_sender.clone()).await,
            (&Method::GET, "/login_status") => Self::sent_login_status().await,
            (&Method::GET, "/cookie") => Self::sent_user_agent_cookie().await,
            (&Method::GET, "/proxy_port") => Self::sent_proxy_port().await,
            (&Method::GET, "/uid") => Self::sent_user_id().await,
            (&Method::GET, "/fuse_115") => Self::sent_fuse_115_disk_path().await,
            _ => Service::make_response(StatusCode::NOT_FOUND, "抱歉，未能处理此请求".to_string()),
        }
    }

    fn make_response(status_code: StatusCode, content: String) -> Result<BoxedResponse> {
        let body = Full::new(Bytes::from(content))
            .map_err(|e| match e {})
            .boxed();
        let mut response = Response::builder().status(status_code).body(body)?;
        let mut header = HeaderMap::new();
        header.append(header::CONTENT_TYPE, "text/plain; charset=UTF-8".parse()?);
        response.headers_mut().extend(header);
        Ok(response)
    }

    async fn sent_public_file(file_path: &str) -> Result<BoxedResponse> {
        let path = {
            let setting = SETTING.read().await;
            setting.working_dir_path()
        };
        let path = if path.len() > 0 {
            path
        } else {
            Command::pwd().await
        };
        let path = PathBuf::from(path).join(&file_path);
        match File::open(&path).await {
            Err(err) => {
                warn!("警告：读取文件 {:?} 时，错误为：{:?}", path, err);
                Service::make_response(
                    StatusCode::NOT_FOUND,
                    "很抱歉，没有找到您请求的文件".to_string(),
                )
            }
            Ok(file) => {
                let reader_stream = ReaderStream::new(file);
                let stream_body = StreamBody::new(reader_stream.map_ok(Frame::data));
                let boxed_body = stream_body.boxed();
                Ok(Response::builder()
                    .status(StatusCode::OK)
                    .body(boxed_body)?)
            }
        }
    }

    async fn sent_reboot(shutdown_sender: Sender<bool>) -> Result<BoxedResponse> {
        // false 表明纯粹想关机，true 表明因错误而关机
        match shutdown_sender.send(false).await {
            Ok(_) => Service::make_response(StatusCode::OK, "正在重启".to_string()),
            Err(err) => Service::make_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                format!("关闭失败，因：{}", err),
            ),
        }
    }

    async fn sent_remount(shutdown_sender: Sender<bool>) -> Result<BoxedResponse> {
        Command::mount_fuse(shutdown_sender).await;
        Service::make_response(
            StatusCode::OK,
            "已发出重新挂载 115 云盘的命令，请试试在网页上浏览文件夹".to_string(),
        )
    }

    async fn sent_login_status() -> Result<BoxedResponse> {
        let user_agent_cookie = {
            let setting = SETTING.read().await;
            setting.user_agent_cookie()
        };
        if user_agent_cookie.get_cookie().len() <= 16 {
            // CID=;SEID=;UID=; 长度已经 16
            Service::make_response(
                StatusCode::OK,
                "还没有获取到Cookie，请用代理获取 Cookie".to_string(),
            )
        } else {
            // 获取当前 cookie 的登录状态
            match timeout(Duration::from_secs(API_TIMEOUT_SECONDS), API.status()).await {
                Err(err) => {
                    warn!(
                        "请求 api status 超时 {} 秒，错误：{:?}",
                        API_TIMEOUT_SECONDS, err
                    );
                    Service::make_response(
                        StatusCode::OK,
                        "检查登录状态超时了，请稍后再试".to_string(),
                    )
                }
                Ok(api_result) => {
                    let msg = match api_result {
                        Ok(response) => {
                            if response.state {
                                "您已登录，尽情享用".to_string()
                            } else {
                                "还未登录或登录过期，请用代理获取 Cookie".to_string()
                            }
                        }
                        Err(err) => format!("出错了：{:?}", err),
                    };
                    Service::make_response(StatusCode::OK, msg)
                }
            }
        }
    }

    async fn sent_user_agent_cookie() -> Result<BoxedResponse> {
        let user_agent_cookie = {
            let setting = SETTING.read().await;
            setting.user_agent_cookie()
        };
        let cookie = user_agent_cookie.get_cookie();
        let content = if cookie.len() < 16 {
            // cookie = "CID=;SEID=;UID=;" 这样就 16 个字符了，等于没有
            "还没有获取到 Cookie".to_string()
        } else {
            let update_at = user_agent_cookie.get_update_at();
            format!(
                "更新时间 {}\n\nCookie 是 {}\n\nuser_agent 是 {}",
                update_at,
                cookie,
                user_agent_cookie.get_user_agent(),
            )
        };
        Service::make_response(StatusCode::OK, content)
    }

    async fn sent_proxy_port() -> Result<BoxedResponse> {
        // 从数据看获取 proxy 端口号
        let port = {
            let setting = SETTING.read().await;
            setting.proxy_service_port()
        };
        Service::make_response(StatusCode::OK, format!("{}", port))
    }

    async fn sent_user_id() -> Result<BoxedResponse> {
        let uid = {
            let setting = SETTING.read().await;
            setting.user_id()
        };
        let seconds = uid / 1_000_000_000;
        let content = seconds.to_string(); // 这个在 OpenObserve 上不能用全数字，要用字母开头
        Service::make_response(StatusCode::OK, content)
    }

    async fn get_fuse_115_dis_path() -> String {
        let path = {
            let setting = SETTING.read().await;
            setting.working_dir_path()
        };
        let path = if path.len() > 0 {
            path
        } else {
            Command::pwd().await
        };
        format!("{}/{}/{}", path, setting::DATA_DIR_PATH, FUSE_DIR_115_NAME)
    }

    async fn sent_fuse_115_disk_path() -> Result<BoxedResponse> {
        let path = Service::get_fuse_115_dis_path().await;
        Service::make_response(StatusCode::OK, path)
    }

    pub async fn send_fuse_115_dir(path: &str) -> Result<BoxedResponse> {
        if path.len() < FUSE_115_DIR_API_PATH.len() {
            return Service::make_response(
                StatusCode::BAD_REQUEST,
                format!("您打开的链接无效：{}。", path),
            );
        }
        let real_path = if path.len() > FUSE_115_DIR_API_PATH.len() + 1 {
            &path[FUSE_115_DIR_API_PATH.len()..]
        } else {
            ""
        };
        let path_decoded = urlencoding::decode(&real_path)?.into_owned();
        let fuse_115_dis_path = Service::get_fuse_115_dis_path().await;
        let path = format!("{}{}", fuse_115_dis_path, path_decoded);
        let path_buf = PathBuf::from(path);
        if !path_buf.is_dir() {
            if path_buf.is_file() {
                Self::sent_public_file(&path_buf.to_string_lossy()).await
            } else {
                Service::make_response(
                    StatusCode::BAD_REQUEST,
                    "您打开的不是文件夹，也不是文件。".to_string(),
                )
            }
        } else {
            let (parent_path, current_dir_name) =
                if let Some(last_slash_idx) = path_decoded.rfind('/') {
                    // 查找最后一个 '/' 的索引
                    (
                        &path_decoded[..last_slash_idx],
                        &path_decoded[last_slash_idx + 1..],
                    ) // 截取字符串到最后一个 '/' 的位置
                } else {
                    (path_decoded.as_str(), "您的 115 网盘根目录")
                };
            let mut result = if path_decoded.len() == 0 {
                "".to_string()
            } else {
                format!("<tr><td><a href=\"#\" onclick=\"{}('{}', '{}')\">上一层目录</a></td><td name=-1></td><td name=-1>文件夹</td></tr>", 
				FUSE_115_DIR_API_FOR_JS, parent_path, current_dir_name)
            };
            let mut file_list = tokio::fs::read_dir(path_buf).await?;
            while let Some(entry) = file_list.next_entry().await? {
                let metadata = entry.metadata().await?;
                let file_type = entry.file_type().await?;
                let mut file_size = metadata.len() as f64;
                let file_size_str = if file_size > FILE_SIZE_GB {
                    file_size = file_size / FILE_SIZE_GB;
                    format!("{:.2} GB", file_size)
                } else if file_size > FILE_SIZE_MB {
                    file_size = file_size / FILE_SIZE_MB;
                    format!("{:.2} MB", file_size)
                } else {
                    format!("{} KB", metadata.len())
                };
                let file_name = entry
                    .file_name()
                    .into_string()
                    .unwrap_or_else(|_| "无效的 UTF-8 字符串".to_string());
                let created_time = metadata.created().unwrap_or(SystemTime::UNIX_EPOCH);
                let created_time_chrono: chrono::DateTime<chrono::Local> = created_time.into();
                let create_time_i64 = Timestamp::system_time_to_i64(created_time);

                let file_type_str = if file_type.is_dir() {
                    "文件夹"
                } else if file_type.is_file() {
                    &file_size_str.to_string()
                } else if file_type.is_symlink() {
                    "超链接"
                } else {
                    // "未知"
                    continue;
                };
                let entry_str = if file_type.is_file() {
                    let str = format!(
						"<tr><td><a href='../../{}{}/{}'>{}</a></td><td name={}>{}</td><td name={}>{}</td></tr>",
						FUSE_115_DIR_API_PATH, real_path, urlencoding::encode(&file_name), file_name, create_time_i64, created_time_chrono.format("%Y-%m-%d %H:%M:%S"),metadata.len(), file_type_str
					);
                    str
                } else {
                    format!(
						"<tr><td><a href=\"#\" onclick=\"{}('{}/{}', '{}')\">{}</a></td><td name={}>{}</td><td name={}>{}</td></tr>",
						FUSE_115_DIR_API_FOR_JS, real_path, urlencoding::encode(&file_name), file_name, file_name, create_time_i64, created_time_chrono.format("%Y-%m-%d %H:%M:%S"),metadata.len(), file_type_str
					)
                };
                result.push_str(&entry_str);
            }
            Service::make_response(StatusCode::OK, result)
        }
    }
}

#[derive(Debug)]
pub struct Command;

impl Command {
    async fn pwd() -> String {
        match std::env::current_dir() {
            Ok(dir) => dir.to_string_lossy().to_string(),
            Err(err) => {
                warn!("将使用 pwd 命令获取当前目录路径时，因使用 std::env::current_dir() 时出错：{:?}", err);
                match std::process::Command::new("pwd").output() {
                    Err(err) => format!("执行 pwd 命令失败：{:?}", err),
                    Ok(output) => {
                        warn!("成功使用 pwd 命令获取当前目录路径为：{:?}", output);
                        if output.status.success() {
                            let stdout = &output.stdout[..output.stdout.len() - 1];
                            String::from_utf8_lossy(stdout).to_string()
                        } else {
                            format!("执行 pwd 命令失败: {:?}", output)
                        }
                    }
                }
            }
        }
    }

    async fn fuse_mount_point() -> String {
        let working_dir_path = {
            let setting = SETTING.read().await;
            setting.working_dir_path()
        };
        let fuse_dir_path: PathBuf = if working_dir_path.len() > 0 {
            PathBuf::from(working_dir_path)
        } else {
            let current_path = Command::pwd().await;
            PathBuf::from(current_path)
        };
        fuse_dir_path
            .join(setting::DATA_DIR_PATH)
            .join(FUSE_DIR_115_NAME)
            .to_string_lossy()
            .to_string()
    }

    pub async fn mount_fuse(sender: Sender<bool>) {
        tokio::spawn(async move {
            let data_path = Command::fuse_mount_point().await;
            println!("挂载 115 云盘到：{}", data_path);
            if let Err(err) = mount(&data_path).await {
                error!("挂载 115 云盘到：{} 时报错：{:?}", data_path, err);
                let _ = sender.send(true).await;
            }
        });
    }
}
