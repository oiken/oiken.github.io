use anyhow::Result;
use cloud_nas::{
    error_bail, proxy,
    setting::{Setting, SETTING},
    ui::{self, Command},
};
use std::ffi::OsString;
use tokio::sync::mpsc::{self, Sender};

enum ArgOption {
    DataDir,
    UiPort,
    ProxyPort,
    Help,
}

async fn init_setting(
    ui_port: Option<u16>,
    proxy_port: Option<u16>,
    working_dir_path: Option<String>,
) -> Result<()> {
    let mut setting = SETTING.write().await;
    if let Err(err) = setting.load(working_dir_path.clone()).await {
        println!("读取当前配置文件时发现：{:?}", err);
        setting.from(Setting::default()).await?;
    }
    setting
        .init_with(ui_port, proxy_port, working_dir_path)
        .await?;
    Ok(())
}

async fn run_proxy(sender: Sender<bool>) {
    let sender_clone = sender.clone();
    tokio::spawn(async move {
        if let Err(err) = proxy::run(sender_clone).await {
            let port = proxy::get_service_port().await;
            print!("代理服务器未能开启，因");
            if err.to_string().contains("Address already in use") {
                println!("端口 {} 已经被占用", port);
            } else {
                println!("{:?}", err);
            }
            let _ = sender.send(true).await;
        }
    });
}

async fn run_ui(sender: Sender<bool>) {
    tokio::spawn(async move {
        if let Err(err) = ui::run(sender.clone()).await {
            let port = ui::get_service_port().await;
            print!("网页服务器未能开启，因");
            if err.to_string().contains("Address already in use") {
                println!("端口 {} 已经被占用", port);
            } else {
                println!("{:?}", err);
            }
            let _ = sender.send(true).await;
        }
    });
}

#[tokio::main]
async fn main() -> Result<()> {
    if let (_, Some(_)) = ParseCommand::arg_for(ArgOption::Help) {
        // 如果用户的命令有 -h 会返回空字符串的值
        println!("Usage: {} [options...]", ParseCommand::command_name());
        println!("-w, <working_directory_path>	Including public files such as html files, daata files such as setting.json, directory as fuse mount point. Default is current path");
        println!("-u <port>				Port for UI service. Default is 8000");
        println!("-p <port>				Port for proxy service. Default is 8080");
        println!("-h					Get help for commands");
        let args: Vec<OsString> = std::env::args_os().collect();
        if args.len() == 2 {
            // 命令就是 ./cloud_nas -h  那这里就执行完毕了
            return Ok(());
        }
    }
    let ui_port = ParseCommand::ui_port()?;
    let proxy_port = ParseCommand::proxy_port()?;
    let working_dir_path = ParseCommand::data_dir_path();
    // 初始化 SETTING
    let _ = init_setting(ui_port, proxy_port, working_dir_path).await;

    // 启动下面这些服务，如果成功都不会返回，只有失败会通知主线程退出软件，所以用 oneshoot
    // 注意如果 mpsc::channel() 参数为 0，会崩溃。另外参数 bool = true 表明因 error 退出，false 表明是关机请求
    let (shutdown_sender, mut shutdown_receiver) = mpsc::channel(1);
    // 第 1 步，开网关服务
    run_proxy(shutdown_sender.clone()).await;
    // 第 2 步，挂载 FUSE 文件夹，必须新开异步，否则不会返回，就无法执行下一步
    Command::mount_fuse(shutdown_sender.clone()).await;
    // 第 3 步，开启 ui 服务，里面会有一个挂载 FUSE 的操作
    run_ui(shutdown_sender.clone()).await;
    while let Some(is_init_error) = shutdown_receiver.recv().await {
        shutdown_receiver.close(); // "干净" 关闭 mpsc::channel ，再有发送过来会被组织
        print!("软件退出，");
        if is_init_error {
            println!("因初始化出错");
        } else {
            println!("因收到关闭的信号");
        }
        std::process::exit(0);
    }
    Ok(())
}

struct ParseCommand {}

impl ParseCommand {
    fn arg_for(option_type: ArgOption) -> (String, Option<String>) {
        let option = match option_type {
            ArgOption::DataDir => "-w",
            ArgOption::UiPort => "-u",
            ArgOption::ProxyPort => "-p",
            ArgOption::Help => "-h",
        };
        let args: Vec<OsString> = std::env::args_os().collect();
        for i in 1..args.len() {
            // 第一个是程序的名称
            if let Some(arg) = args.get(i) {
                if arg.eq(&OsString::from(option)) {
                    if let Some(next_arg) = args.get(i + 1) {
                        let next_arg_string = <OsString as Clone>::clone(&next_arg)
                            .into_string()
                            .unwrap_or_else(|os_str| os_str.to_string_lossy().into_owned());
                        return (option.to_string(), Some(next_arg_string)); // 有选项，有值
                    } else {
                        return (option.to_string(), Some("".to_string())); // 有选项，没值
                    }
                }
            }
        }
        (option.to_string(), None) // 没选项，返回 None
    }

    fn command_name() -> String {
        let args: Vec<OsString> = std::env::args_os().collect();
        match args.get(0) {
            Some(name) => <OsString as Clone>::clone(&name)
                .into_string()
                .unwrap_or_else(|os_str| os_str.to_string_lossy().into_owned()),
            None => env!("CARGO_PKG_NAME").to_string(),
        }
    }

    fn data_dir_path() -> Option<String> {
        if let (_, Some(option_value)) = ParseCommand::arg_for(ArgOption::DataDir) {
            if option_value.len() > 0 {
                return Some(option_value);
            }
        }
        None
    }

    fn proxy_port() -> Result<Option<u16>> {
        if let (_, Some(option_value)) = ParseCommand::arg_for(ArgOption::ProxyPort) {
            if option_value.len() > 0 {
                match option_value.parse::<u16>() {
                    Ok(port) => return Ok(Some(port)),
                    Err(err) => {
                        error_bail!("从启动命令中获取网关服务器端口的参数时出错：{:?}", err);
                    }
                }
            }
        }
        Ok(None)
    }

    fn ui_port() -> Result<Option<u16>> {
        if let (_, Some(option_value)) = ParseCommand::arg_for(ArgOption::UiPort) {
            if option_value.len() > 0 {
                match option_value.parse::<u16>() {
                    Ok(port) => return Ok(Some(port)),
                    Err(err) => {
                        error_bail!("从启动命令中获取 UI 服务器端口的参数时出错：{:?}", err);
                    }
                }
            }
        }
        Ok(None)
    }
}
