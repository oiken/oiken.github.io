use crate::{
    error,
    fuse::{dir::Dir, file::File},
    warn,
    yyw::{
        api::{API, API_TIMEOUT_SECONDS},
        files::{Response, LIMIT_DEFAULT},
        files_batch_rename, files_delete, files_move,
    },
};
use anyhow::Result;
use chrono::Local;
use fuser::FileAttr;
use std::{
    ffi::{OsStr, OsString},
    time::Duration,
};
use tokio::{runtime::Handle, task::block_in_place, time::timeout};

#[derive(Debug, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub(crate) enum Entry {
    File(File),
    Dir(Dir),
}

impl Entry {
    pub(crate) fn new_dir(
        parent: u64,
        name: OsString,
        cid: u64,
        offset: u64,
        create_time: i64,
    ) -> Self {
        let dir = Dir::new(parent, name, cid, offset, create_time, 0); // 最后一个参数是 0 ，代表未更新过
        Entry::Dir(dir)
    }

    pub(crate) fn new_file(
        parent: u64,
        name: OsString,
        cid: u64,
        size: u64,
        create_time: i64,
    ) -> Self {
        let file = File::new(parent, name, cid, size, create_time);
        Entry::File(file)
    }

    pub(crate) fn has_parent_and_name(&self, parent: u64, name: &OsStr) -> bool {
        match self {
            Entry::File(file) => file.parent() == parent && file.name().eq(name),
            Entry::Dir(dir) => dir.parent() == parent && dir.name().eq(name),
        }
    }

    pub(crate) fn attr(&self, ino: u64) -> FileAttr {
        match self {
            Entry::File(file) => file.attr(ino),
            Entry::Dir(dir) => dir.attr(ino),
        }
    }

    pub(crate) fn cid_and_offset(&self) -> (u64, u64) {
        match self {
            Entry::File(file) => (file.cid(), 0),
            Entry::Dir(dir) => (dir.cid(), dir.offset()),
        }
    }

    pub(crate) fn parent(&self) -> u64 {
        match self {
            Entry::File(file) => file.parent(),
            Entry::Dir(dir) => dir.parent(),
        }
    }

    pub(crate) fn set_parent(&mut self, new_parent: u64) {
        match self {
            Entry::File(file) => file.set_parent(new_parent),
            Entry::Dir(dir) => dir.set_parent(new_parent),
        }
    }

    pub fn name(&self) -> &OsStr {
        match self {
            Entry::File(file) => file.name(),
            Entry::Dir(dir) => dir.name(),
        }
    }

    pub fn set_name(&mut self, name: OsString) -> Result<(), i32> {
        match self {
            Entry::File(file) => file.set_name(name),
            Entry::Dir(dir) => dir.set_name(name),
        }
    }

    pub(crate) fn dir_update_recently(&self) -> Result<bool, i32> {
        match self {
            Entry::File(_) => Err(libc::ENOTDIR),
            Entry::Dir(dir) => Ok(dir.did_update_recently()),
        }
    }

    pub(crate) fn can_dir_update_child(&self) -> Result<bool, i32> {
        match self {
            Entry::File(_) => Err(libc::ENOTDIR),
            Entry::Dir(dir) => Ok(dir.can_update_child()),
        }
    }

    // 去除重名
    fn rename_repeat_name(entries: &[(String, bool)], is_file: bool, name: &str) -> String {
        fn split_name_extension(file_name: &str) -> (String, String) {
            // 尝试在最后一个点处分割文件名和扩展名
            if let Some((name, extension)) = file_name.rsplit_once('.') {
                (name.to_string(), extension.to_string())
            } else {
                // 如果没有找到点，或者点是文件名的最后一个字符，返回整个字符串作为文件名，扩展名为空
                (file_name.to_string(), "".to_string())
            }
        }

        fn has_the_same_name(entries: &[(String, bool)], is_file: bool, name: &str) -> bool {
            for entry in entries {
                let entry_name = match entry {
                    (file_name, true) => {
                        if !is_file {
                            continue;
                        }
                        file_name
                    }
                    (dir_name, false) => {
                        if is_file {
                            continue;
                        }
                        dir_name
                    }
                };
                if name.eq(entry_name) {
                    return true;
                }
            }
            false
        }

        let mut index: usize = 0;
        loop {
            let new_name = if index == 0 {
                name.to_string()
            } else {
                if is_file {
                    let (entry_name, suffix) = split_name_extension(name);
                    format!("{}({}).{}", entry_name, index, suffix)
                } else {
                    format!("{}({})", name, index)
                }
            };
            if has_the_same_name(entries, is_file, &new_name) {
                if index >= 1000 {
                    return new_name;
                } else {
                    index += 1;
                }
            } else {
                return new_name;
            }
        }
    }

    fn from(files: Response, parent_ino: u64, parent_cid: u64, offset: u64) -> Vec<Entry> {
        let mut name_is_file_vec = vec![];
        let mut entries = Vec::new();
        for file_data in &files.data {
            match file_data.cid.parse::<u64>() {
                Err(err) => {
                    warn!(
                        "file_data.cid= {} 转换成 u64 出错：{:?}\n继续处理下一个",
                        file_data.cid, err
                    );
                    continue;
                }
                Ok(cid) => {
                    let size = match &file_data.size {
                        Some(s) => *s as u64,
                        None => 0_u64,
                    };
                    let create_at = match file_data.create_time.parse::<i64>() {
                        Ok(create_at) => create_at,
                        Err(_) => 0,
                    };
                    let entry = if let Some(fid) = &file_data.fid {
                        // 有 fid 说明是文件，此时 cid 是父文件夹的 cid
                        if cid != parent_cid {
                            continue;
                        } else {
                            match fid.parse::<u64>() {
                                Err(err) => {
                                    warn!(
                                        "file_data.fid= {} 转换成 u64 出错：{:?}\n继续处理下一个",
                                        fid, err
                                    );
                                    continue;
                                }
                                Ok(fid) => {
                                    let no_repeat_name = Entry::rename_repeat_name(
                                        &name_is_file_vec,
                                        true,
                                        &file_data.n,
                                    );
                                    name_is_file_vec.push((no_repeat_name.clone(), true));
                                    Entry::new_file(
                                        parent_ino,
                                        OsString::from(no_repeat_name),
                                        fid,
                                        size,
                                        create_at,
                                    )
                                }
                            }
                        }
                    } else if let Some(pid) = &file_data.pid {
                        match pid.parse::<u64>() {
                            Err(err) => {
                                warn!(
                                    "file_data.fid= {} 转换成 u64 出错：{:?}\n继续处理下一个",
                                    pid, err
                                );
                                continue;
                            }
                            Ok(pid) => {
                                if pid != parent_cid {
                                    continue;
                                } else {
                                    let no_repeat_name = Entry::rename_repeat_name(
                                        &name_is_file_vec,
                                        false,
                                        &file_data.n,
                                    );
                                    name_is_file_vec.push((no_repeat_name.clone(), false));
                                    Entry::new_dir(
                                        parent_ino,
                                        OsString::from(no_repeat_name),
                                        cid,
                                        0,
                                        create_at,
                                    )
                                }
                            }
                        }
                    } else {
                        continue;
                    };
                    entries.push(entry);
                }
            }
        }

        if entries.len() as u64 > LIMIT_DEFAULT {
            warn!(
                "子文件夹数量超过了 LIMIT_DEFAULT= {} 个，请留意是否出错了",
                LIMIT_DEFAULT
            );
        }
        // 分页创建文件夹，不可能目录的全部都获取完毕，也没有必要，以短时间内更新为好
        if entries.len() > 0 && offset == 0 && files.count > LIMIT_DEFAULT {
            let mut page_dir_count = files.count / LIMIT_DEFAULT;
            if page_dir_count * LIMIT_DEFAULT < files.count {
                page_dir_count += 1;
            }
            for i in 1..page_dir_count {
                let dir_offset = i * LIMIT_DEFAULT;
                let no_repeat_name =
                    Entry::rename_repeat_name(&name_is_file_vec, true, &format!("第 {} 页", i + 1));
                name_is_file_vec.push((no_repeat_name.clone(), true));
                let entry = Entry::new_dir(
                    parent_ino,
                    OsString::from(&no_repeat_name),
                    parent_cid,
                    dir_offset,
                    Local::now().timestamp(),
                );
                entries.push(entry);
            }
        }
        entries
    }

    pub(crate) fn update_dir(&self, ino: u64) -> Result<Option<Vec<Entry>>, i32> {
        match self {
            Entry::File(file) => {
                warn!("name= {:?} 是文件，不是文件夹", file.name());
                Err(libc::ENOTDIR)
            }
            Entry::Dir(dir) => match dir.update() {
                Err(_) => Ok(None), // 不关心出错，返回 None
                Ok(response) => {
                    let entries = Entry::from(response, ino, dir.cid(), dir.offset());
                    Ok(Some(entries))
                }
            },
        }
    }

    // 更新，返回被移除的旧的子文件（夹）
    pub(crate) fn update_dir_children(&mut self, children: &[u64]) -> Result<Vec<u64>, i32> {
        match self {
            Entry::File(file) => {
                warn!("name= {:?} 是文件，不是文件夹", file.name());
                Err(libc::ENOTDIR)
            }
            Entry::Dir(dir) => Ok(dir.update_children(children)),
        }
    }

    // 添加子文件（夹）
    pub(crate) fn add_child_to_dir(&mut self, child_ino: u64) -> Result<(), i32> {
        match self {
            Entry::File(file) => {
                warn!("name= {:?} 是文件，不是文件夹", file.name());
                Err(libc::ENOTDIR)
            }
            Entry::Dir(dir) => dir.add_child(child_ino),
        }
    }

    // 如果 offset 是负数，就是从后面往前数的，用法不习惯，换成正向的
    pub(crate) fn positive_offset(&self, offset: i64) -> u64 {
        let len = match self {
            Entry::File(file) => file.size(),
            Entry::Dir(dir) => dir.children().len() as u64,
        };
        let offset_abs = offset.abs() as u64;
        if offset_abs > len {
            if offset < 0 {
                0
            } else {
                len
            }
        } else {
            if offset < 0 {
                len - offset_abs
            } else {
                offset_abs
            }
        }
    }

    pub(crate) fn read_file(&self, offset: i64, size: u32) -> Result<Vec<u8>, i32> {
        match self {
            Entry::Dir(dir) => {
                warn!("name= {:?} 是文件夹，不是文件", dir.name());
                Err(libc::EISDIR)
            }
            Entry::File(file) => {
                let positive_offset = self.positive_offset(offset);
                match file.content(positive_offset, size) {
                    Err(_) => Err(libc::EREMOTE),
                    Ok((content, _eof)) => Ok(content),
                }
            }
        }
    }

    pub fn rename(&self, new_name: &OsStr) -> Result<String, i32> {
        let (cid, old_name) = match self {
            Entry::Dir(dir) => {
                let name = match dir.name().to_str() {
                    Some(name) => name.to_string(),
                    None => "该文件夹没有名字".to_string(),
                };
                (dir.cid(), name)
            }
            Entry::File(file) => {
                let name = match file.name().to_str() {
                    Some(name) => name.to_string(),
                    None => "该文件夹没有名字".to_string(),
                };
                (file.cid(), name)
            }
        };
        let name = new_name.to_string_lossy().to_string();
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
                let payload = files_batch_rename::Payload{ fid: cid, name: name.to_string()};
                match timeout(
                    Duration::from_secs(API_TIMEOUT_SECONDS),
                    API.files_batch_rename(&payload),
                )
                .await
                {
                    Err(err) => {
                        warn!(
                            "请求 api batch_rename 更改 cid= {} 的名字为：name={:?}, 超时 {} 秒，错误：{:?}",
                            cid,
                            new_name,
                            API_TIMEOUT_SECONDS,
                            err
                        );
						Err(libc::ETIMEDOUT)
                    }
                    Ok(batch_rename_api_result) => match batch_rename_api_result {
						Ok(response) => {
							if !response.state {
								warn!(
									"请求 api batch_rename 更改 cid= {} 的名字 \"{}\" 为：\"{:?}\", 返回错误为：{:?}",
									cid,
									old_name,
									new_name,
									response								);
								Err(libc::EREMOTE)
							}else {
								if response.data.len() > 0 {
									for (key, value) in response.data {
										if key != cid {
											error!("修改名字 {} 时接收到返回的 data 的 cid 为 {} 与修改前的 cid {} 不一致，不知如何处理", old_name, key, cid);											
										}
										return Ok(value);
									}
								}
								error!("修改名字 {0} 时接收到返回的 data 数据为空，先返回旧名字 {0}", old_name);
								return Ok(old_name);
							}
						},
						Err(_) =>	Err(libc::EREMOTE), // 在 API.batch_rename(&payload) 里已经打印过警告信息了
					},
                }
            })
        })
    }

    pub fn delete(&self, parent_cid: u64) -> Result<(), i32> {
        let cid = match self {
            Entry::File(file) => file.cid(),
            Entry::Dir(dir) => dir.cid(),
        };
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
                let payload = files_delete::Payload::new(parent_cid, &vec![cid]);
                match timeout(
                    Duration::from_secs(API_TIMEOUT_SECONDS),
                    API.files_delete(&payload),
                )
                .await
                {
                    Err(err) => {
                        warn!(
                            "请求 api file_delete 删除文件夹 ino= {}, 的文件或文件夹 cid= {} , 超时 {} 秒，错误：{:?}",
                            parent_cid, cid,
                            API_TIMEOUT_SECONDS,
                            err
                        );
						Err(libc::ETIMEDOUT)
                    }
                    Ok(file_delete_api_result) => match file_delete_api_result {
						Ok(response) => {
							if !response.state {
								warn!(
									"请求 api file_delete 删除文件夹 ino= {}, 的文件或文件夹 cid= {} , 返回错误为：{:?}",
									parent_cid, cid, response
								);
								return Err(libc::EREMOTE);
							}
							Ok(())
						},
						Err(_) =>	Err(libc::EREMOTE),
					}
				}
            })
        })
    }

    pub fn move_to(&self, parent_cid: u64, parent_name: &OsStr) -> Result<(), i32> {
        let (child_cid, _offset) = self.cid_and_offset();
        let child_name = self.name();
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
				let payload = files_move::Payload::new(parent_cid, &vec![child_cid]).await;
				let move_progress_id = payload.get_move_proid();
				match timeout(
					Duration::from_secs(API_TIMEOUT_SECONDS),
					API.files_move(&payload),
				)
				.await
				{
					Err(err) => {
						warn!(
							"请求 api files_move 移动文件（夹） name= {:?} 到目标文件夹 name= {:?}, 超时 {} 秒，错误：{:?}",
							child_name, parent_name,
							API_TIMEOUT_SECONDS,
							err
						);
						Err(libc::ETIMEDOUT)
					}
					Ok(files_move_api_result) => match files_move_api_result {
						Err(_) => Err(libc::EREMOTE),
						Ok(response) => {
							if !response.state {
								warn!(
									"请求 api file_move 移动文件（夹） name= {:?} 到目标文件夹 name= {:?}, 收到错误为：{}",
									child_name, parent_name,  response.error
								);
								Err(libc::EREMOTE)
							} else {
								let mut tried = false; // 如果失败，重试一次
								let wait_milli_seconds = 500; // 等 500 毫秒刷新一次进度
								let mut progress_count = 6; // 最多等 6 * wait_milli_seconds 毫秒 就不刷进度了
								while progress_count >= 0 {
									match API.files_move_progress(&move_progress_id).await {
										Ok(files_move_progress_result) => {
											// println!("移动的进度为：{} %", files_move_progress_result.progress);
											if files_move_progress_result.progress >= 100 {
												break;
											}
										}
										Err(err) => {
											warn!(
												"请求 api files_move_progress 获取移动文件（夹） name= {:?} 到目标文件夹 name= {:?} 的进度时, 收到错误：{}",
												child_name, parent_name,  err
											);
											if tried {
												warn!("重试一次获取移动进度，不行也算了");
												break;
											} else {
												tried = true;
											}
										}
									}
									std::thread::sleep(Duration::from_millis(wait_milli_seconds));
									progress_count -= 1;
								}
								Ok(())
							}
						},
					}
				}
			})
        })
    }
}
