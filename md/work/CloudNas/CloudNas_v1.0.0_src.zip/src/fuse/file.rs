use crate::{error, fuse::content::CACHE, setting, util::Timestamp, yyw::api::API_TIMEOUT_SECONDS};
use anyhow::Result;
use fuser::{FileAttr, FileType::RegularFile};
use std::{
    ffi::{OsStr, OsString},
    time::{Duration, UNIX_EPOCH},
};
use tokio::{runtime::Handle, task::block_in_place, time::timeout};

#[derive(Debug, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub(crate) struct File {
    parent: u64,
    name: OsString,
    cid: u64,
    size: u64,
    create_at: i64,
}

impl File {
    pub(crate) fn new(parent: u64, name: OsString, cid: u64, size: u64, create_at: i64) -> Self {
        Self {
            parent,
            name,
            cid,
            size,
            create_at,
        }
    }

    pub(crate) fn parent(&self) -> u64 {
        self.parent
    }

    pub(crate) fn set_parent(&mut self, new_parent: u64) {
        self.parent = new_parent;
    }

    pub(crate) fn name(&self) -> &OsStr {
        &self.name
    }

    pub(crate) fn set_name(&mut self, name: OsString) -> Result<(), i32> {
        if name.len() > setting::MAX_NAME_LENGTH {
            error!(
                "更改名字时出错，因超出最长限制：{}",
                setting::MAX_NAME_LENGTH
            );
            Err(libc::ENAMETOOLONG)
        } else {
            self.name = name;
            Ok(())
        }
    }

    pub(crate) fn cid(&self) -> u64 {
        self.cid
    }

    pub(crate) fn size(&self) -> u64 {
        self.size
    }

    pub(crate) fn attr(&self, ino: u64) -> FileAttr {
        FileAttr {
            ino,
            size: self.size,
            blocks: 0,
            atime: UNIX_EPOCH, // 1970-01-01 00:00:00
            mtime: UNIX_EPOCH,
            ctime: UNIX_EPOCH,
            crtime: Timestamp::i64_to_system_time(self.create_at),
            kind: RegularFile,
            perm: 0o777, // 全权限
            nlink: 1,
            uid: 501,
            gid: 20,
            rdev: 0,
            flags: 0,
            blksize: 512,
        }
    }

    pub(crate) fn content(&self, offset: u64, size: u32) -> Result<(Vec<u8>, bool), i32> {
        let file_id = self.cid;
        let file_size = self.size;
        let file_name = self.name.clone();
        // println!( "content 读取文件 {:?} 的内容 offset= {}, size= {}", file_name, offset, size);
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
                // FUSE 中不知道
                // NFS中 如果是第一次获取，还没有数据的话，返回空数据，因为这是文件夹在列出时拿第一个数据而已，没必要去网络上拿数据
                // if offset == 0 && CACHE.has_data(file_id).await == false {
                //     return Err(libc::EREMOTE);
                // }
                let time_out_seconds = API_TIMEOUT_SECONDS * 2; // 因为读取文件的长度为 8mb 的话，基本在 3 秒以上
                match timeout(
                    Duration::from_secs(time_out_seconds),
                    CACHE.get(file_id, offset, size as u64, file_size),
                )
                .await
                {
                    Err(err) => {
                        error!(
                            "请求 api read_file 读取文件 name={:?}, cid= {} 超时 {} 秒，错误：{:?}",
                            file_name, file_id, time_out_seconds, err
                        );
                        Err(libc::ETIMEDOUT)
                    }
                    Ok(result) => match result {
                        Ok(data) => {
                            let eof = data.len() as u64 + offset >= file_size;
                            Ok((data, eof))
                        }
                        Err(err) => {
                            error!(
                                "请求 api read_file 读取文件 name={:?}, cid= {} 出错：{:?}",
                                file_name, file_id, err
                            );
                            Err(libc::EREMOTE)
                        }
                    },
                }
            })
        })
    }
}
