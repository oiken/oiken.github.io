use super::{dir::Dir, entry::Entry};
use crate::{
    error, error_bail, setting, warn,
    yyw::{
        api::{API, API_TIMEOUT_SECONDS},
        files_mkdir,
    },
};
use anyhow::Result;
use chrono::Local;
use fuser::{
    FileAttr, FileType, Filesystem, MountOption, ReplyAttr, ReplyData, ReplyDirectory, ReplyEmpty,
    ReplyEntry, Request,
};
use std::{
    collections::BTreeMap,
    ffi::{OsStr, OsString},
    process::Command,
    sync::{Mutex, RwLock},
    time::Duration,
};
use tokio::{runtime::Handle, task::block_in_place, time::timeout};

pub const ROOT_INO: u64 = 1; // FUSE 系统的第一个 ino 从 1 开始，不从 0 开始
pub const ROOT_CID: u64 = 0; // 但 115 的根目录是 0
const TTL: Duration = Duration::from_secs(1); // 1 second
const SLEEP_MILLI_SECOND_AFTER_DELETE: u64 = 500;

// 调用这个函数，要在 tokio::spawn(async move { }) 里，因为不会返回的
pub async fn mount(mount_point: &str) -> Result<()> {
    // 要挂载的文件夹路径和挂载点，也要选用 MountOption::AllowOther， 因为这样才不需要 root 用户来 umount
    umount(mount_point);
    tokio::fs::create_dir_all(mount_point).await?;
    let mut options = vec![MountOption::RW, MountOption::FSName("hello".to_string())];
    options.push(MountOption::AllowOther);
    options.push(MountOption::AutoUnmount);
    // options.push(MountOption::AllowRoot);  AllowOther 和 AllowRoot 只能选一个，选 AllowRoot 不能自动推出，所以不要选择 AllowRoot
    Ok(fuser::mount2(FileSys::init()?, mount_point, &options)?)
}

pub fn umount(mount_point: &str) -> String {
    // 一定要先用命令行推出已经加载的 FUSE 磁盘，否则后面的挂载会失败
    match Command::new("umount").arg(mount_point).output() {
        Err(err) => format!("执行 umount 命令失败：{:?}", err),
        Ok(output) => {
            if output.status.success() {
                "成功推出原来已经挂载的 FUSE 文件夹".to_string()
            } else {
                format!("失败： unmount: {:?}", output)
            }
        }
    }
}

#[derive(Debug, Default)]
struct FileSys {
    cid_offset_ino_map: Mutex<BTreeMap<(u64, u64), u64>>,
    ino_entry_map: RwLock<BTreeMap<u64, Entry>>,
}

impl FileSys {
    fn next_ino(&mut self, cid: u64, offset: u64) -> Result<u64> {
        match self.cid_offset_ino_map.lock() {
            Err(err) => {
                error_bail!("写锁 cid_offset_ino_map 时出错：{:?}", err);
            }
            Ok(mut cid_offset_ino_map) => {
                let cid_offset: (u64, u64) = (cid, offset);
                match cid_offset_ino_map.get(&cid_offset) {
                    Some(ino) => Ok(*ino),
                    None => {
                        let next_ino =
                            match cid_offset_ino_map.iter().max_by_key(|(_key, &ino)| ino) {
                                None => ROOT_INO,
                                Some((_, max_ino)) => max_ino + 1,
                            };
                        cid_offset_ino_map.insert(cid_offset, next_ino);
                        Ok(next_ino)
                    }
                }
            }
        }
    }

    fn init() -> Result<Self> {
        let offset = 0;
        let mut file_sys = FileSys::default();
        let ino = file_sys.next_ino(ROOT_CID, offset)?;
        let entry = Entry::new_dir(
            ino,
            OsString::from("115网盘"),
            ROOT_CID,
            0,
            Local::now().timestamp(),
        ); // 最后一个参数是 0 ，代表未更新过
        match file_sys.ino_entry_map.write() {
            Ok(mut ino_entry_map) => {
                ino_entry_map.insert(ino, entry);
            }
            Err(err) => {
                error_bail!("写锁 ino_entry_map 时出错：{:?}", err);
            }
        }
        Ok(file_sys)
    }

    fn lookup_dir(&self, ino: u64, name: &OsStr) -> Result<FileAttr, i32> {
        if name.len() > setting::MAX_NAME_LENGTH {
            return Err(libc::ENAMETOOLONG);
        }
        if let Some(name_str) = name.to_str() {
            // 忽略系统文件
            let ignored_os_file_name = vec![
                ".DS_Store",
                "._.",
                "._*",
                ".hidden",
                "$RECYCLE.BIN",
                ".fseventsd",
                "lost+found",
                ".metadata_never_index",
                ".metadata_never_index_unless_rootfs",
                ".metadata_direct_scope_only",
                ".Spotlight-V100",
                "DCIM",
            ];
            if ignored_os_file_name.contains(&name_str) {
                return Err(libc::ENOENT);
            }
        }
        match self.ino_entry_map.read() {
            Err(err) => {
                warn!("失败读锁 ino_entry_map：{:?}", err);
                Err(libc::EBUSY)
            }
            Ok(ino_entry_map) => {
                let ino_entry_vec: Vec<(&u64, &Entry)> = ino_entry_map
                    .iter()
                    .filter(|(_key, entry)| entry.has_parent_and_name(ino, name))
                    .map(|(key, entry)| (key, entry))
                    .collect();
                match ino_entry_vec.first() {
                    None => {
                        // warn!(
                        //     "父目录 ino= {:?} 里有 {} 个子文件（夹），但没有 name= {:?} 的文件或目录 ",
                        //     ino,
                        //     ino_entry_map.len(),
                        //     name
                        // );
                        Err(libc::ENOENT)
                    }
                    Some((ino, entry)) => Ok(entry.attr(**ino)),
                }
            }
        }
    }

    fn get_entry(&self, ino: u64) -> Result<Entry, i32> {
        match self.ino_entry_map.read() {
            Err(err) => {
                warn!("读锁失败 ino_entry_map：{:?}", err);
                Err(libc::EBUSY)
            }
            Ok(ino_entry_map) => match ino_entry_map.get(&ino) {
                None => {
                    warn!("没有找到文件或目录 ino= {:?}", ino);
                    Err(libc::ENOENT)
                }
                Some(entry) => Ok(entry.clone()),
            },
        }
    }

    fn get_entry_dir(&self, ino: u64) -> Result<Dir, i32> {
        match self.get_entry(ino)? {
            Entry::Dir(dir) => Ok(dir),
            _ => Err(libc::ENOTDIR),
        }
    }

    // fn get_entry_file(&self, ino: u64) -> Result<File, i32> {
    //     match self.get_entry(ino)? {
    // 		Entry::File(file) => Ok(file),
    // 		_ => Err(libc::ENOTDIR)
    // 	}
    // }

    fn update_dir_entry(&mut self, ino: u64) -> Result<(), i32> {
        let entry = self.get_entry(ino)?;
        let parent_entry = self.get_entry(entry.parent())?;
        let parent_can_update_child = parent_entry.can_dir_update_child()?;
        let entry_did_update_recently = entry.dir_update_recently()?;
        if parent_can_update_child && !entry_did_update_recently {
            // 父目录最近没有更新过
            if let Ok(Some(entries)) = entry.update_dir(ino) {
                let mut children_ino = Vec::new();
                let mut new_ino_entry_map = BTreeMap::new();
                for child_entry in entries {
                    if child_entry.parent() == ino {
                        let (children_cid, children_offset) = child_entry.cid_and_offset();
                        if let Ok(next_ino) = self.next_ino(children_cid, children_offset) {
                            children_ino.push(next_ino);
                            new_ino_entry_map.insert(next_ino, child_entry);
                        }
                    }
                }
                match self.ino_entry_map.write() {
                    Err(err) => {
                        warn!("写锁失败 ino_entry_map：{:?}", err);
                        return Err(libc::EBUSY);
                    }
                    Ok(mut ino_entry_map) => {
                        ino_entry_map.extend(new_ino_entry_map);
                        if let Some(entry) = ino_entry_map.get_mut(&ino) {
                            let remove_children_ino = entry.update_dir_children(&children_ino)?;
                            for child_ino in remove_children_ino {
                                // 删除旧子文件（夹）
                                ino_entry_map.remove(&child_ino);
                            }
                        }
                    }
                }
            }
        }
        Ok(())
    }

    pub fn update_entry_name(&mut self, ino: u64, new_name: &str) -> Result<(), i32> {
        match self.ino_entry_map.write() {
            Err(err) => {
                warn!("写锁失败 ino_entry_map：{:?}", err);
                Err(libc::EBUSY)
            }
            Ok(mut ino_entry_map) => {
                if let Some(entry) = ino_entry_map.get_mut(&ino) {
                    entry.set_name(OsString::from(new_name))
                } else {
                    error!("更改名字时找不到 ino= {} 的 entry，修改失败。", ino);
                    Err(libc::ENOENT)
                }
            }
        }
    }

    fn all_children_of_dir(ino_entry_map: &BTreeMap<u64, Entry>, entry: &Entry) -> Vec<u64> {
        let mut all_children = Vec::new();
        if let Entry::Dir(dir) = entry {
            let children = dir.children();
            all_children.extend(children);
            for child_ino in children.iter() {
                if let Some(child_entry) = ino_entry_map.get(child_ino) {
                    let children_children =
                        FileSys::all_children_of_dir(ino_entry_map, child_entry);
                    all_children.extend(children_children);
                }
            }
        }
        all_children
    }

    pub fn delete_entry_and_his_children(&mut self, parent: u64, ino: u64) -> Result<(), i32> {
        let all_children_ino = match self.ino_entry_map.read() {
            Err(err) => {
                warn!("读锁失败 ino_entry_map：{:?}", err);
                return Err(libc::EBUSY);
            }
            Ok(ino_entry_map) => match ino_entry_map.get(&ino) {
                None => return Err(libc::ENOENT),
                Some(entry) => FileSys::all_children_of_dir(&ino_entry_map, entry),
            },
        };
        match self.ino_entry_map.write() {
            Err(err) => {
                warn!("写锁失败 ino_entry_map：{:?}", err);
                return Err(libc::EBUSY);
            }
            Ok(mut ino_entry_map) => {
                for child_ino in all_children_ino {
                    ino_entry_map.remove(&child_ino);
                }
                // 删掉父文件夹里的子文件列表中的 ino
                if let Some(parent_entry) = ino_entry_map.get_mut(&parent) {
                    if let Entry::Dir(dir) = parent_entry {
                        dir.delete_child(ino);
                    }
                }
                // 删掉这个 entry
                ino_entry_map.remove(&ino);
                Ok(())
            }
        }
    }

    /*	/// 注意：新建文件等于上传一个文件，上传文件关系到阿里云的 oss 接口，需要做预备功夫，比如计算认证信息，返回带认证信息的请求头，暂时未实现
        fn create_empty_file(&mut self, parent: u64, name: &OsStr) -> Result<(u64, FileAttr), i32> {
            let parent_entry = match self.get_entry(parent) {
                Ok(entry) => entry,
                Err(err) => {
                    error!("新建文件时无法找到父文件夹 ino= {}", parent);
                    return Err(err);
                }
            };
            let (parent_cid, _) = parent_entry.cid_and_offset();
            let parent_name = parent_entry.name().to_string_lossy().to_string();
            let name_str = name.to_string_lossy();
            let handle = Handle::current();
            block_in_place(|| {
                handle.block_on(async {
                    let payload = sample_init_upload::Payload::new(parent_cid, &name_str);
                    match timeout(
                        Duration::from_secs(API_TIMEOUT_SECONDS),
                        API.sample_init_upload(&payload),
                    )
                    .await
                    {
                        Err(err) => {
                            warn!(
                                "请求 api sample_init_upload 在文件夹 name= {} 里新建文件 name= {} , 超时 {} 秒，错误：{:?}",
                                parent_name, name_str,
                                API_TIMEOUT_SECONDS,
                                err
                            );
                            Err(libc::ETIMEDOUT)
                        }
                        Ok(sample_init_upload_api_result) => match sample_init_upload_api_result {
                            Err(_) => Err(libc::EREMOTE),
                            Ok(response) => {
                                if !response.state {
                                    warn!(
                                        "请求 api sample_init_uploadt 在文件夹 name= {} 里新建文件 name= {} , 收到错误为：{:?}",
                                        parent_name, name_str, response
                                    );
                                    Err(libc::EREMOTE)
                                } else {
                                    let new_cid = match response.cid.parse::<u64>() {
                                        Err(err) => {
                                            error!("请稍后刷新文件夹 name= {}，把 sample_init_upload 接口返回成功，但 cid={:?} 转换成 u64 时出错：{:?}" ,parent_name, response.cid, err);
                                            return Err(libc::EREMOTE);
                                        },
                                        Ok(cid) => cid,
                                    };
                                    match self.next_ino(new_cid, 0) {
                                        Err(_err) => Err(libc::EREMOTE),
                                        Ok(new_ino) => {
                                            let new_entry = Entry::new_file(
                                                parent,
                                                OsString::from(&response.cname),
                                                new_cid,
                                                0,
                                                Local::now().timestamp(),
                                            ); // 最后一个参数 create_at 是 0 ，代表未更新过
                                            match self.ino_entry_map.write() {
                                                Err(err) => {
                                                    error!("写锁 ino_entry_map 时出错：{:?}", err);
                                                    Err(libc::EBUSY)
                                                },
                                                Ok(mut ino_entry_map) => {
                                                    let attr = new_entry.attr(new_ino);
                                                    ino_entry_map.insert(new_ino, new_entry);
                                                    match ino_entry_map.get_mut(&parent) {
                                                        Some(parent_entry) => {
                                                            let _ = parent_entry.add_child_to_dir(new_ino);
                                                        },
                                                        None => {
                                                            error!("新建文件 name= {} 成功，但要加入到父文件夹时，无法找到父文件夹 name= {}", response.cname, parent_name);
                                                        },
                                                    }
                                                    Ok((new_ino, attr))
                                                }
                                            }
                                        },
                                    }
                                }
                            },
                        }
                    }
                })
            })
        }
    */

    fn create_dir(&mut self, parent: u64, name: &OsStr) -> Result<FileAttr, i32> {
        let parent_entry = match self.get_entry(parent) {
            Ok(entry) => entry,
            Err(err) => {
                error!("新建文件夹时无法找到父文件夹 ino= {}", parent);
                return Err(err);
            }
        };
        let (parent_cid, _) = parent_entry.cid_and_offset();
        let parent_name = parent_entry.name().to_string_lossy().to_string();
        let name_str = name.to_string_lossy();
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
                let payload = files_mkdir::Payload::new(parent_cid, &name_str);
                match timeout(
                    Duration::from_secs(API_TIMEOUT_SECONDS),
                    API.files_mkdir(&payload),
                )
                .await
                {
                    Err(err) => {
                        warn!(
                            "请求 api file_mkdir 在文件夹 name= {} 里新建文件夹 name= {} , 超时 {} 秒，错误：{:?}",
                            parent_name, name_str,
                            API_TIMEOUT_SECONDS,
                            err
                        );
						Err(libc::ETIMEDOUT)
                    }
                    Ok(files_mkdir_api_result) => match files_mkdir_api_result {
						Err(_) => Err(libc::EREMOTE),
						Ok(response) => {
							if !response.state {
								warn!(
									"请求 api file_mkdir 在文件夹 name= {} 里新建文件夹 name= {} , 收到错误为：{:?}",
									parent_name, name_str, response
								);
								Err(libc::EREMOTE)
							} else {
								let new_cid = match response.cid.parse::<u64>() {
									Err(err) => {
										error!("请稍后刷新文件夹 name= {}，把 files_mkdir 接口返回成功，但 cid={:?} 转换成 u64 时出错：{:?}" ,parent_name, response.cid, err);
										return Err(libc::EREMOTE);
									},
									Ok(cid) => cid,
								};
								match self.next_ino(new_cid, 0) {
									Err(_err) => Err(libc::EREMOTE),
									Ok(new_ino) => {
										let new_entry = Entry::new_dir(
											parent,
											OsString::from(&response.cname),
											new_cid,
											0,
											Local::now().timestamp(),
										); // 最后一个参数 create_at 是 0 ，代表未更新过
										match self.ino_entry_map.write() {
											Err(err) => {
												error!("写锁 ino_entry_map 时出错：{:?}", err);
												Err(libc::EBUSY)
											},
											Ok(mut ino_entry_map) => {
												let attr = new_entry.attr(new_ino);
												ino_entry_map.insert(new_ino, new_entry);
												match ino_entry_map.get_mut(&parent) {
													Some(parent_entry) => {
														let _ = parent_entry.add_child_to_dir(new_ino);
													},
													None => {
														error!("新建文件夹 name= {} 成功，但要加入到父文件夹时，无法找到父文件夹 name= {}", response.cname, parent_name);	
													},
												}
												Ok(attr)
											}
										}
									},
								}
							}
						},
					}
				}
            })
        })
    }
}

impl Filesystem for FileSys {
    // todo! 目前只有一个挂载，收到 destroy 调用时删除掉存储缓存
    fn destroy(&mut self) {}

    fn lookup(&mut self, _req: &Request, parent: u64, name: &OsStr, reply: ReplyEntry) {
        match self.lookup_dir(parent, name) {
            Err(err) => reply.error(err),
            Ok(attr) => reply.entry(&TTL, &attr, 0),
        }
    }

    fn getattr(&mut self, _req: &Request, ino: u64, reply: ReplyAttr) {
        match self.get_entry(ino) {
            Err(err) => reply.error(err),
            Ok(entry) => {
                let attr = entry.attr(ino);
                reply.attr(&TTL, &attr);
            }
        }
    }

    fn read(
        &mut self,
        _req: &Request,
        ino: u64,
        _fh: u64,
        offset: i64,
        size: u32,
        _flags: i32,
        _lock: Option<u64>,
        reply: ReplyData,
    ) {
        match self.get_entry(ino) {
            Err(err) => reply.error(err),
            Ok(entry) => match entry.read_file(offset, size) {
                Err(err) => reply.error(err),
                Ok(data) => reply.data(&data),
            },
        }
    }

    fn readdir(
        &mut self,
        _req: &Request,
        ino: u64,
        _fh: u64,
        offset: i64,
        mut reply: ReplyDirectory,
    ) {
        let _ = self.update_dir_entry(ino);
        // 不管有没有更新，下面都会读取数据
        match self.get_entry(ino) {
            Err(err) => reply.error(err),
            Ok(entry) => {
                let positive_offset = entry.positive_offset(offset) as usize;
                match entry {
                    Entry::File(_) => reply.error(libc::ENOTDIR),
                    Entry::Dir(dir) => {
                        for (index, child_ino) in
                            dir.children().iter().enumerate().skip(positive_offset)
                        {
                            if let Ok(child_entry) = self.get_entry(*child_ino) {
                                match &child_entry {
                                    Entry::File(file) => {
                                        if reply.add(
                                            *child_ino,
                                            (index + 1) as i64,
                                            FileType::RegularFile,
                                            file.name(),
                                        ) {
                                            break;
                                        }
                                    }
                                    Entry::Dir(dir) => {
                                        if reply.add(
                                            *child_ino,
                                            (index + 1) as i64, // i + 1 因为 fuse 系统根目录ino 是 1 开始
                                            FileType::Directory,
                                            dir.name(),
                                        ) {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        reply.ok()
                    }
                }
            }
        }
    }

    // 以下是写入功能
    /// 重命名一个文件，或移动一个文件
    fn rename(
        &mut self,
        _req: &Request<'_>,
        parent: u64,
        name: &OsStr,
        newparent: u64,
        newname: &OsStr,
        _flags: u32,
        reply: ReplyEmpty,
    ) {
        let child_ino = match self.lookup_dir(parent, name) {
            Err(err) => {
                reply.error(err);
                return;
            }
            Ok(attr) => attr.ino,
        };
        let child_entry = match self.get_entry(child_ino) {
            Err(err) => {
                error!("移动一个文件（夹）前，未能获取到该文件（夹）：{}", err);
                reply.error(err);
                return;
            }
            Ok(child) => child,
        };
        let child_name = child_entry.name();
        if name.eq(newname) && parent == newparent {
            // 名字相同，同一目录下，什么也不用做，返回 ok 即可
            reply.ok();
            return;
        }
        let parent_dir = match self.get_entry_dir(parent) {
            Err(err) => {
                error!("移动一个文件（夹）前，未能获取父文件夹：{}", err);
                reply.error(err);
                return;
            }
            Ok(dir) => dir,
        };
        let new_parent_dir = if newparent == parent {
            parent_dir.clone()
        } else {
            match self.get_entry_dir(newparent) {
                Err(err) => {
                    error!(
                        "移动一个文件（夹） name= {:?} 前，未能获取新的父文件夹：{}",
                        child_name, err
                    );
                    reply.error(err);
                    return;
                }
                Ok(dir) => dir,
            }
        };

        // 先移动，再改名字，如果改名字失败，再移动回来，失败则移动回来
        // 如果支持移动文件，还要定时获取移动的进度： file_move_progress.rs
        // todo! 以后可以支持移动，把文件层级导出全部并解释，就可以支持移动和更名都完美
        let parent_id = new_parent_dir.cid();
        if parent_dir.cid() != new_parent_dir.cid() {
            if let Err(err) = child_entry.move_to(parent_id, new_parent_dir.name()) {
                reply.error(err);
                return;
            }
        }
        if !name.eq(newname) {
            // 换名字
            match child_entry.rename(newname) {
                Err(err) => {
                    if parent_dir.cid() != new_parent_dir.cid() {
                        // 改名字出错，放回原来文件夹
                        if let Err(err) = child_entry.move_to(parent_id, parent_dir.name()) {
                            error!("放弃处理，因为更改名字失败后，把文件（夹） name= {:?} 放回原来目录也遇到错误：{}", child_name, err);
                            reply.error(err);
                            return;
                        }
                    }
                    reply.error(err);
                    return;
                }
                Ok(new_name) => {
                    // 更改成功会返回新名字，更新到本系统中
                    if let Err(err) = self.update_entry_name(child_ino, &new_name) {
                        warn!("请重新刷新，更改云盘上的名字成功，但更改本地的名字 {:?} 为 {:?} 时出错：{}", child_name, new_name, err);
                    }
                }
            }
        }
        if parent != newparent {
            match self.ino_entry_map.write() {
                Err(err) => {
                    error!("移动文件或文件夹时，写锁 ino_entry_map 失败：{:?}", err);
                    reply.error(libc::EBUSY);
                    return;
                }
                Ok(mut ino_entry_map) => {
                    // 添加到新父目录下
                    if let Some(Entry::Dir(new_parent_dir)) = ino_entry_map.get_mut(&newparent) {
                        let _ = new_parent_dir.add_child(child_ino);
                    }
                    // 更改子文件夹的父目录 ino
                    if let Some(child_entry) = ino_entry_map.get_mut(&child_ino) {
                        let _ = child_entry.set_parent(newparent);
                    }
                    // 从原父目录的子文件（夹）列表里删除
                    if let Some(Entry::Dir(parent_dir)) = ino_entry_map.get_mut(&parent) {
                        let _ = parent_dir.delete_child(child_ino);
                    } else {
                        reply.error(libc::ENOENT);
                        return;
                    }
                }
            }
        }
        reply.ok();
    }

    /// 删除一个文件
    fn unlink(&mut self, req: &Request<'_>, parent: u64, name: &OsStr, reply: ReplyEmpty) {
        self.rmdir(req, parent, name, reply)
    }

    /// 删除一个文件夹
    fn rmdir(&mut self, _req: &Request<'_>, parent: u64, name: &OsStr, reply: ReplyEmpty) {
        let parent_entry = match self.get_entry(parent) {
            Err(_) => {
                reply.error(libc::EREMOTE);
                return;
            }
            Ok(entry) => entry,
        };
        let (parent_cid, _) = parent_entry.cid_and_offset();
        let parent_name = parent_entry.name().to_string_lossy().to_string();
        let ino = match self.lookup_dir(parent, name) {
            Err(_err) => {
                warn!(
                    "用 parent= {} 和 name= {:?} 找不到 entry，可能已经被删除",
                    parent_name, name
                );
                reply.ok();
                return;
            }
            Ok(attr) => attr.ino,
        };
        match self.get_entry(ino) {
            Err(_) => {
                warn!(
                    "用 parent= {} 和 name= {:?} 找得到 ino= {} 但找不到 entry，可能已经被删除",
                    parent_name, name, ino
                );
                reply.ok();
            }
            Ok(entry) => {
                let parent_ino = entry.parent();
                if parent_ino != parent {
                    warn!(
						"用 parent= {} 和 name= {:?} 找得到 ino= {} 找到的 entry 的 parent-ino= {} 与前面的 parent 不一样，认为已经出错",
						parent_name, name, ino, parent_ino
					);
                    reply.error(libc::EREMOTE);
                } else {
                    match entry.delete(parent_cid) {
                        Ok(_) => {
                            // 系统自己会深度遍历从最后一个开始删除，但 115 服务器跟不上速度，比如还在删子文件，
                            // 父目录的删除请求已经发出，会报错，所以除了自己来删掉所有子文件，API 也要慢一点返回，让 115 服务器有空做完
                            // 当系统来删，只要找不到 entry，就返回 ok
                            match self.delete_entry_and_his_children(parent, ino) {
                                Ok(()) => {
                                    // 延时一秒，等待服务器完成任务
                                    std::thread::sleep(Duration::from_millis(
                                        SLEEP_MILLI_SECOND_AFTER_DELETE,
                                    ));
                                    reply.ok()
                                }
                                Err(err) => reply.error(err),
                            }
                        }
                        Err(err) => reply.error(err),
                    }
                }
            }
        }
    }

    /*
        /// 创建并打开文件。
        /// 如果文件不存在，首先使用指定的模式创建文件，然后打开它。打开标志（除了 O_NOCTTY）在 flags 中可用。
        /// 文件系统可以在 fh 中存储任意的文件句柄（指针、索引等），并在所有其他文件操作（读取、写入、刷新、释放、同步）中使用它。
        /// 文件系统还可以设置一些标志（direct_io, keep_cache），以改变文件的打开方式。有关详细信息，请参阅 <fuse_common.h> 中的 fuse_file_info 结构体。
        /// 如果此方法未实现或在 Linux 内核版本 2.6.15 之前，将调用 mknod() 和 open() 方法。
        fn create(
            &mut self,
            _req: &Request<'_>,
            parent: u64,
            name: &OsStr,
            _mode: u32,
            _umask: u32,
            flags: i32,
            reply: ReplyCreate,
        ) {
            match self.create_empty_file(parent,  name) {
                Ok((file_ino, file_attr)) => reply.created(&TTL, &file_attr, 0, file_ino, flags as u32),
                Err(err) => reply.error(err),
            }
        }

        /// Create file node.
        /// Create a regular file, character device, block device, fifo or socket node.
        fn mknod(
            &mut self,
            _req: &Request<'_>,
            parent: u64,
            name: &OsStr,
            mode: u32,
            umask: u32,
            rdev: u32,
            reply: ReplyEntry,
        ) {
            reply.error(ENOSYS);
        }
    */

    /// Create a directory.
    fn mkdir(
        &mut self,
        _req: &Request<'_>,
        parent: u64,
        name: &OsStr,
        _mode: u32,
        _umask: u32,
        reply: ReplyEntry,
    ) {
        match self.create_dir(parent, name) {
            Ok(file_attr) => reply.entry(&TTL, &file_attr, 0),
            Err(err) => reply.error(err),
        }
    }
}
