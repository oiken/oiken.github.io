use crate::{
    error, error_bail, warn, warn_bail,
    yyw::api::{Api, API, API_TIMEOUT_SECONDS},
};
use anyhow::bail;
use bytes::Bytes;
use chrono::Local;
use http_body_util::Empty;
use hyper::{client::conn::http1::SendRequest, Uri};
use hyper_util::rt::TokioIo;
use lazy_static::lazy_static;
use std::collections::HashMap;
use tokio::{
    net::TcpStream,
    sync::{Mutex, RwLock},
    time::{timeout, Duration},
};

lazy_static! {
    pub static ref CACHE: Cache = Cache::default();
}

// nfs 每次读取数据块长度都是 32768，FUSE 每次读 4096，为了刚好读完数据块，FISRT_DATA_LEN  DATA_LEN 都是倍数
static MB_115: u64 = 1024 * 1024 * 115; // 115 mb 的文件要用 down_url 接口获取 url
static FISRT_DATA_LEN: u64 = 4096 * 36; // 128 kb 是视频文件在文件夹中被选中时预览要拿的数据，512kb 的下载时间 371 ms
static DATA_LEN: u64 = 4096 * 500; // 1mb 试试，选择 2 mb 体验较好，因为 2 mb 和 2.5 mb 下载时间 645ms 和 866 ms 以内，3mb容易超出 1 秒 , 8mb 3.418298956s
static DATA_LEN_TO_CACHE: u64 = 4096 * 250; // 缓存下载的长度，要比上一级下载的长度短，才能先完成
static DATA_LEN_TO_CACHE_PLAN_B: u64 = 4096 * 250; // 缓存下载的长度，要比上一级下载的长度短，才能先完成
static DATA_COUNT_MAX: usize = 75; // 缓存最多数据块，共 150 mb 比较合适，因为小内存的机器为 256mb的话，占用一半比较合适
static DATA_COUNT_SWEEP_LEFT: usize = DATA_COUNT_MAX * 2 / 3;
static DATA_KEEP_ALIVE_SECONDS: i64 = 60; // 存活 60 秒
static CID_DATA_KEY_FOR_SWEEP_TIMESTAMP: (u64, u64) = (u64::MAX, u64::MAX); // 用来记录上次清扫的时间，如果超过 DATA_KEEP_ALIVE_SECONDS 或数据块多于 40 个，就清扫一次
static SWEEP_FILE_INTERVAL_SECONDS: i64 = 60 * 15; // 清理文件缓存的时间间隔 15 分钟，刚好是小文件的 url 有效时间
static CID_FILE_KEY_FOR_SWEEP_TIMESTAMP: u64 = u64::MAX; // 用来记录上次清扫的时间，如果超过 SWEEP_FILE_INTERVAL_SECONDS，就清扫一次

#[derive(Debug, Default, Clone)]
struct File {
    size: u64,
    pickcode: String,
    pub url: String,
    url_valid_timestamp: i64, // 超出有效期， url 就要重新获取
}

impl File {
    pub fn new(size: u64) -> Self {
        let mut file = File::default();
        file.size = size;
        file
    }

    // 返回最新的 url 和当前时间戳
    pub async fn update_url(&mut self, cid: u64) -> anyhow::Result<(String, i64)> {
        if self.pickcode.len() == 0 {
            let response = API.category(&cid.to_string()).await?;
            self.pickcode = response.pickcode;
        }
        let now = Local::now().timestamp();
        if now >= self.url_valid_timestamp || self.url.len() == 0 {
            if self.size > MB_115 {
                let response = API.down_url(&self.pickcode).await?;
                self.url = response.url;
                self.url_valid_timestamp = response.valid_timestamp.unwrap_or(0);
            } else {
                let response = API.get_file_url(&self.pickcode).await?;
                self.url = response.url;
                self.url_valid_timestamp = response.valid_timestamp;
            }
        }
        Ok((self.url.clone(), now))
    }
}

#[derive(Debug, Default)]
pub struct Cache {
    cid_file_map: RwLock<HashMap<u64, File>>, // key 是 cid， value 是 File，
    cid_data_map: RwLock<HashMap<(u64, u64), (Vec<u8>, i64)>>, // key 是 (cid, offset)， value 是字节数组 和 插入时间戳，用来做 LRU
    // key 是 cid，value 是 hyper 的 Sender ,cid_getter_map 是当场下载，cid_cacher_map 和 cid_cacher_map_plan_b 是另起异步任务下载
    cid_fetcher_map: RwLock<HashMap<u64, Mutex<SendRequest<Empty<Bytes>>>>>,
    cid_cacher_map: RwLock<HashMap<u64, Mutex<SendRequest<Empty<Bytes>>>>>,
    cid_cacher_map_plan_b: RwLock<HashMap<u64, Mutex<SendRequest<Empty<Bytes>>>>>, // 增加一组下载，但复制到本地的速度还是卡在 2mb/秒 左右
                                                                                   // 不能再增加一组下载，容易收到错误： 403 内容为 “115 pmt 3-2”
}

impl Cache {
    // 当挂载被推出时，会收到 destory 消息，此时要删除缓存
    pub async fn clear_all(self) {
        {
            let mut cid_file_map = self.cid_file_map.write().await;
            cid_file_map.clear();
        }
        {
            let mut cid_data_map = self.cid_data_map.write().await;
            cid_data_map.clear();
        }
        {
            let mut cid_fetcher_map = self.cid_fetcher_map.write().await;
            cid_fetcher_map.clear();
        }
        {
            let mut cid_cacher_map = self.cid_cacher_map.write().await;
            cid_cacher_map.clear();
        }
        {
            let mut cid_cacher_map_plan_b = self.cid_cacher_map_plan_b.write().await;
            cid_cacher_map_plan_b.clear();
        }
    }

    // 是否存在这个 cid 和 offset 的数据块
    async fn has_data_for(&self, cid: u64, offset: u64) -> bool {
        let cid_data_map = self.cid_data_map.read().await;
        for ((key_cid, key_offset), (value_data, _)) in cid_data_map.iter() {
            if *key_cid == cid {
                let value_data_len = value_data.len();
                let key_offset_end = key_offset + value_data_len as u64;
                // 在当前数据块中，取出来
                if offset >= *key_offset && offset < key_offset_end {
                    return true;
                }
            }
        }
        false
    }

    // 返回字节数组，是否读到了数据块结尾
    async fn get_data(&self, cid: u64, offset: u64, count: u64) -> (Vec<u8>, bool) {
        let cid_data_map = self.cid_data_map.read().await;
        for ((key_cid, key_offset), (value_data, _)) in cid_data_map.iter() {
            if *key_cid == cid {
                let value_data_len = value_data.len();
                let key_offset_end = key_offset + value_data_len as u64;
                // 在当前数据块中，取出来
                if offset >= *key_offset && offset < key_offset_end {
                    let start = (offset - key_offset) as usize;
                    let mut end = start + count as usize;
                    if end >= value_data_len {
                        end = value_data_len;
                    }
                    let data = value_data[start..end].to_vec();
                    // if end == value_data_len {
                    //     println!(
                    //         "get_data offset= {}, count= {}，返回：数据长度 {}，数据块结尾",
                    //         offset,
                    //         count,
                    //         data.len(),
                    //     );
                    // }
                    return (data, end == value_data_len);
                }
            }
        }
        // println!(
        //     "get_data offset= {}, count= {}，返回：没有数据",
        //     offset, count
        // );
        (vec![], true)
    }

    // 返回 key_offset 和数据块长度，offset 应该在指定区间，比如每个数据块 10 mb，那这里要计算在哪个数据块
    fn data_key_of(&self, offset: u64, file_size: u64) -> Option<(u64, u64)> {
        if offset >= file_size {
            None
        } else {
            let offset = if offset < FISRT_DATA_LEN {
                0
            } else {
                (offset - FISRT_DATA_LEN) / DATA_LEN * DATA_LEN + FISRT_DATA_LEN
            };
            let count = if offset == 0 {
                FISRT_DATA_LEN
            } else {
                DATA_LEN
            };
            // 不能超出文件大小，否则 http 返回 416，导致最后一点数据收不全
            let count = if offset + count >= file_size {
                file_size - offset
            } else {
                count
            };
            Some((offset, count))
        }
    }

    fn sweep_file(&self, now_timestamp: i64, cid_file_map: &mut HashMap<u64, File>) {
        let need_update = match cid_file_map.get(&CID_FILE_KEY_FOR_SWEEP_TIMESTAMP) {
            Some(file) => {
                // 下一次清扫的时间戳如果比当前时间戳小，说明到时间清扫了
                if file.url_valid_timestamp <= now_timestamp {
                    // println!("进入 sweep_file 时的文件数量：{:?}", cid_file_map.len());
                    // 只留下 url_valid_timestamp 未超出当前时间的数据，小于 115mb 的文件的 url 有效时间为 15分钟，大于115mb的文件的 url 有效时间为 20 小时，
                    cid_file_map.retain(|_, file| file.url_valid_timestamp >= now_timestamp);
                    // println!("完成 sweep_file 时的数据块数量：{:?}", cid_file_map.len());
                    true
                } else {
                    false
                }
            }
            None => true,
        };
        if need_update {
            // 记得更新 清扫时间戳为下一次清扫的时间戳
            let mut file = File::default();
            file.url_valid_timestamp = now_timestamp + SWEEP_FILE_INTERVAL_SECONDS;
            cid_file_map.insert(CID_FILE_KEY_FOR_SWEEP_TIMESTAMP, file);
        }
    }

    async fn update_url(&self, cid: u64, file_size: u64) -> anyhow::Result<String> {
        let mut file = {
            let cid_file_map = self.cid_file_map.read().await;
            match cid_file_map.get(&cid) {
                None => File::new(file_size),
                Some(file) => file.clone(),
            }
        };

        // 这个费时，收到数据了再调用 self.cid_file_map 的写锁
        match file.update_url(cid).await {
            // 若新建 File 肯定要更新 url
            // 从网上更新要一段时间
            Err(err) => Err(err),
            Ok((url, updated_timestamp)) => {
                // 更新成功，都保存起来
                let mut cid_file_map = self.cid_file_map.write().await;
                self.sweep_file(updated_timestamp, &mut cid_file_map); // 先清理再插入，少计算一个
                cid_file_map.insert(cid, file);
                Ok(url)
            }
        }
    }

    async fn update_fetcher(&self, cid: u64, url: &str) -> anyhow::Result<()> {
        {
            // 试试有没有，没有的话，是否还连接中，大括号让 read 锁不要影响下面的 写锁
            let cid_fetcher_map = CACHE.cid_fetcher_map.read().await;
            if let Some(mutex_fetcher) = cid_fetcher_map.get(&cid) {
                let fetcher = mutex_fetcher.lock().await;
                if !&fetcher.is_closed() {
                    return Ok(());
                }
            }
        }

        let uri: Uri = url.parse()?;
        let host = uri.host().expect(
            format!(
                "错误: {}, {}, 期望从 url= {} 中获得主机域名",
                file!(),
                line!(),
                url
            )
            .as_str(),
        );
        let port = uri.port_u16().unwrap_or(80);
        let addr = format!("{}:{}", host, port);
        let stream = TcpStream::connect(&addr).await?;
        let io = TokioIo::new(stream);
        let (sender, conn) = hyper::client::conn::http1::handshake(io).await?;
        // sender 类型是  SendRequest，是 hyper 库中用于发送请求并接收响应的类型。
        // 它内部维护了一个连接池，可以配合 Request 的 keep-alive 保持连接，复用底层的 TCP 连接。
        tokio::spawn(async move {
            // 运行一个任务，这个任务会轮询 connection 并处理 HTTP 状态。如果连接出现错误，它会打印错误信息。
            if let Err(err) = conn.await {
                warn!("update_fetcher 的 http_1 连接出错：{:?}", err);
                let mut cid_fetcher_map = CACHE.cid_fetcher_map.write().await;
                cid_fetcher_map.remove(&cid);
            }
        });
        let mut cid_fetcher_map = self.cid_fetcher_map.write().await;
        cid_fetcher_map.insert(cid, Mutex::new(sender));
        Ok(())
    }

    async fn update_cacher(&self, cid: u64, url: &str) -> anyhow::Result<()> {
        {
            // 试试有没有，没有的话，是否还连接中，大括号让 read 锁不要影响下面的 写锁
            let cid_cacher_map = CACHE.cid_cacher_map.read().await;
            if let Some(mutex_cacher) = cid_cacher_map.get(&cid) {
                let cacher = mutex_cacher.lock().await;
                if !&cacher.is_closed() {
                    return Ok(());
                }
            }
        }

        let uri: Uri = url.parse()?;
        let host = uri.host().expect(
            format!(
                "错误: {}, {}, 期望从 url= {} 中获得主机域名",
                file!(),
                line!(),
                url
            )
            .as_str(),
        );
        let port = uri.port_u16().unwrap_or(80);
        let addr = format!("{}:{}", host, port);
        let stream = TcpStream::connect(&addr).await?;
        let io = TokioIo::new(stream);
        let (sender, conn) = hyper::client::conn::http1::handshake(io).await?;
        // sender 类型是  SendRequest，是 hyper 库中用于发送请求并接收响应的类型。它内部维护了一个连接池，可以配合 Request 的 keep-alive 保持连接，复用底层的 TCP 连接。
        tokio::spawn(async move {
            // 运行一个任务，这个任务会轮询 connection 并处理 HTTP 状态。如果连接出现错误，它会打印错误信息。
            if let Err(err) = conn.await {
                warn!("警告：update_cacher 的 http_1 连接出错：{:?}", err);
                let mut cid_cacher_map = CACHE.cid_cacher_map.write().await;
                cid_cacher_map.remove(&cid);
            }
        });
        let mut cid_cacher_map = self.cid_cacher_map.write().await;
        cid_cacher_map.insert(cid, Mutex::new(sender));
        Ok(())
    }

    async fn update_cacher_plan_b(&self, cid: u64, url: &str) -> anyhow::Result<()> {
        {
            // 试试有没有，没有的话，是否还连接中，大括号让 read 锁不要影响下面的 写锁
            let cid_cacher_map_plan_b = CACHE.cid_cacher_map_plan_b.read().await;
            if let Some(mutex_cacher) = cid_cacher_map_plan_b.get(&cid) {
                let cacher = mutex_cacher.lock().await;
                if !&cacher.is_closed() {
                    return Ok(());
                }
            }
        }

        let uri: Uri = url.parse()?;
        let host = uri.host().expect(
            format!(
                "错误: {}, {}, 期望从 url= {} 中获得主机域名",
                file!(),
                line!(),
                url
            )
            .as_str(),
        );
        let port = uri.port_u16().unwrap_or(80);
        let addr = format!("{}:{}", host, port);
        let stream = TcpStream::connect(&addr).await?;
        let io = TokioIo::new(stream);
        let (sender, conn) = hyper::client::conn::http1::handshake(io).await?;
        // sender 类型是  SendRequest，是 hyper 库中用于发送请求并接收响应的类型。它内部维护了一个连接池，可以配合 Request 的 keep-alive 保持连接，复用底层的 TCP 连接。
        tokio::spawn(async move {
            // 运行一个任务，这个任务会轮询 connection 并处理 HTTP 状态。如果连接出现错误，它会打印错误信息。
            if let Err(err) = conn.await {
                warn!("警告：update_cacher_plan_b 的 http_1 连接出错：{:?}", err);
                let mut cid_cacher_map_plan_b = CACHE.cid_cacher_map_plan_b.write().await;
                cid_cacher_map_plan_b.remove(&cid);
            }
        });
        let mut cid_cacher_map_plan_b = self.cid_cacher_map_plan_b.write().await;
        cid_cacher_map_plan_b.insert(cid, Mutex::new(sender));
        Ok(())
    }

    // 获取远程数据
    async fn fetch_data(&self, cid: u64, offset: u64, file_size: u64) -> anyhow::Result<()> {
        match self.data_key_of(offset, file_size) {
            None => bail!(
                "想获取的数据的开头 offset= {} 超出了文件大小 {}",
                offset,
                file_size
            ),
            Some((offset, count)) => {
                // 检查是否已经有了所要的数据，就是是否别人已经下载好了
                let (check_data, _) = self.get_data(cid, offset, 1).await;
                if check_data.len() > 0 {
                    return Ok(()); // 已经有这个数据了，返回即可
                } else {
                    let url = self.update_url(cid, file_size).await?;
                    self.update_fetcher(cid, &url).await?;
                    let cid_fetcher_map = self.cid_fetcher_map.read().await;
                    match cid_fetcher_map.get(&cid) {
                        Some(mutex_fetcher) => {
                            let mut fetcher = mutex_fetcher.lock().await;
                            // 拿到了下载器，检查是否已经有了所要的数据，就是是否别人已经下载好了才释放这个下载器
                            let (check_data, _) = self.get_data(cid, offset, 1).await;
                            if check_data.len() > 0 {
                                return Ok(()); // 已经有这个数据了，返回即可
                            }
                            let time_out_seconds = API_TIMEOUT_SECONDS * 2; // 因为读取文件的长度为 8mb 的话，基本在 3 秒以上
                            match timeout(
                                Duration::from_secs(time_out_seconds),
                                Api::read_file_2(&url, offset, count as usize, &mut fetcher),
                            )
                            .await
                            {
                                Err(err) => {
                                    error_bail!(
                                        "请求 api 读取文件超时 {} 秒，返回错误为：{:?}",
                                        time_out_seconds,
                                        err
                                    );
                                }
                                Ok(read_file_result) => match read_file_result {
                                    Err(err) => {
                                        // error!("出错了：offset= {}, 错误为：{:#?}", offset, err);
                                        Err(err)
                                    }
                                    Ok(data) => {
                                        let mut cid_data_map = self.cid_data_map.write().await;
                                        cid_data_map.insert(
                                            (cid, offset),
                                            (data, Local::now().timestamp()),
                                        );
                                        Ok(())
                                    }
                                },
                            }
                        }
                        None => {
                            error!("没有找到 https 请求发送体");
                            bail!("没有找到 https 请求发送体");
                        }
                    }
                }
            }
        }
    }

    // 获取远程数据
    async fn cache_data(&self, cid: u64, offset: u64, file_size: u64) -> anyhow::Result<()> {
        match self.data_key_of(offset, file_size) {
            None => bail!(
                "想获取的数据的开头 offset= {} 超出了文件大小 {}",
                offset,
                file_size
            ),
            Some((offset, count)) => {
                // 检查是否已经有了所要的数据，就是是否别人已经下载好了
                let (check_data, _) = self.get_data(cid, offset, 1).await;
                if check_data.len() > 0 {
                    return Ok(()); // 已经有这个数据了，也许是别的线程下载了这个数据块，因此返回即可
                } else {
                    let url = self.update_url(cid, file_size).await?;
                    self.update_cacher(cid, &url).await?;
                    let cid_cacher_map = self.cid_cacher_map.read().await;
                    match cid_cacher_map.get(&cid) {
                        Some(mutex_cacher) => {
                            let mut cacher = mutex_cacher.lock().await;
                            // 拿到了下载器，检查是否已经有了所要的数据，就是是否别人已经下载好了才释放这个下载器
                            let (check_data, _) = self.get_data(cid, offset, 1).await;
                            if check_data.len() > 0 {
                                return Ok(()); // 已经有这个数据了，也许是别的线程下载了这个数据块，因此返回即可
                            }
                            // 这是二级缓存下载，要比一级同步或异步下载先回来
                            let cache_data_len = if count > DATA_LEN_TO_CACHE {
                                DATA_LEN_TO_CACHE
                            } else {
                                count
                            };
                            let time_out_seconds = API_TIMEOUT_SECONDS * 2; // 因为读取文件的长度为 8mb 的话，基本在 3 秒以上
                            match timeout(
                                Duration::from_secs(time_out_seconds),
                                Api::read_file_2(
                                    &url,
                                    offset,
                                    cache_data_len as usize,
                                    &mut cacher,
                                ),
                            )
                            .await
                            {
                                Err(err) => {
                                    warn_bail!(
                                        "请求 api 读取文件超时 {} 秒，返回错误为：{:?}",
                                        time_out_seconds,
                                        err
                                    );
                                }
                                Ok(read_file_result) => match read_file_result {
                                    Err(err) => {
                                        // error!("出错了：offset= {}, 错误为：{:#?}", offset, err);
                                        Err(err)
                                    }
                                    Ok(data) => {
                                        let mut cid_data_map = self.cid_data_map.write().await;
                                        let now = Local::now().timestamp();
                                        // 清理
                                        self.sweep_data(now, &mut cid_data_map);
                                        cid_data_map.insert((cid, offset), (data, now));
                                        Ok(())
                                    }
                                },
                            }
                        }
                        None => {
                            error!("没有找到 https 请求发送体");
                            bail!("没有找到 https 请求发送体");
                        }
                    }
                }
            }
        }
    }

    // 获取远程数据
    async fn cache_data_plan_b(&self, cid: u64, offset: u64, file_size: u64) -> anyhow::Result<()> {
        match self.data_key_of(offset, file_size) {
            None => bail!(
                "想获取的数据的开头 offset= {} 超出了文件大小 {}",
                offset,
                file_size
            ),
            Some((offset, count)) => {
                // 检查是否已经有了所要的数据，就是是否别人已经下载好了
                let (check_data, _) = self.get_data(cid, offset, 1).await;
                if check_data.len() > 0 {
                    return Ok(()); // 已经有这个数据了，也许是别的线程下载了这个数据块，因此返回即可
                } else {
                    let url = self.update_url(cid, file_size).await?;
                    self.update_cacher_plan_b(cid, &url).await?;
                    let cid_cacher_map_plan_b = self.cid_cacher_map_plan_b.read().await;
                    match cid_cacher_map_plan_b.get(&cid) {
                        Some(mutex_cacher) => {
                            let mut cacher = mutex_cacher.lock().await;
                            // 拿到了下载器，检查是否已经有了所要的数据，就是是否别人已经下载好了才释放这个下载器
                            let (check_data, _) = self.get_data(cid, offset, 1).await;
                            if check_data.len() > 0 {
                                return Ok(()); // 已经有这个数据了，也许是别的线程下载了这个数据块，因此返回即可
                            }
                            // 这是三级缓存下载，可以和二级异步下载差不多时间回来，但要比一级下载要早回来
                            let cache_data_len = if count > DATA_LEN_TO_CACHE {
                                DATA_LEN_TO_CACHE_PLAN_B
                            } else {
                                count
                            };
                            let time_out_seconds = API_TIMEOUT_SECONDS * 2; // 因为读取文件的长度为 8mb 的话，基本在 3 秒以上
                            match timeout(
                                Duration::from_secs(time_out_seconds),
                                Api::read_file_2(
                                    &url,
                                    offset,
                                    cache_data_len as usize,
                                    &mut cacher,
                                ),
                            )
                            .await
                            {
                                Err(err) => {
                                    warn_bail!(
                                        "请求 api 读取文件超时 {} 秒，返回错误为：{:?}",
                                        time_out_seconds,
                                        err
                                    );
                                }
                                Ok(read_file_result) => match read_file_result {
                                    Err(err) => {
                                        // error!("出错了：offset= {}, 错误为：{:#?}", offset, err);
                                        Err(err)
                                    }
                                    Ok(data) => {
                                        let mut cid_data_map = self.cid_data_map.write().await;
                                        let now = Local::now().timestamp();
                                        // 清理
                                        self.sweep_data(now, &mut cid_data_map);
                                        cid_data_map.insert((cid, offset), (data, now));
                                        Ok(())
                                    }
                                },
                            }
                        }
                        None => {
                            error!("没有找到 https 请求发送体");
                            bail!("没有找到 https 请求发送体");
                        }
                    }
                }
            }
        }
    }

    fn sweep_data(
        &self,
        now_timestamp: i64,
        cid_data_map: &mut HashMap<(u64, u64), (Vec<u8>, i64)>,
    ) {
        let time_to_sweep = if cid_data_map.len() > DATA_COUNT_MAX {
            true
        } else {
            match cid_data_map.get(&CID_DATA_KEY_FOR_SWEEP_TIMESTAMP) {
                Some((_, last_sweep_timestamp)) => {
                    &now_timestamp > last_sweep_timestamp
                        && now_timestamp - last_sweep_timestamp >= DATA_KEEP_ALIVE_SECONDS
                }
                None => {
                    cid_data_map.insert(CID_DATA_KEY_FOR_SWEEP_TIMESTAMP, (vec![], now_timestamp)); // 没有就插入一个
                    false
                }
            }
        };
        if time_to_sweep {
            // println!("进入 sweep_data 时的数据块数量：{:?}", cid_data_map.len());
            // 超出数量时清理一次只留下前几个最新的，且时间在 DATA_KEEP_ALIVE_SECONDS 内的
            let last_timestamp = now_timestamp - DATA_KEEP_ALIVE_SECONDS;
            let mut insert_timestamp_vec: Vec<i64> = cid_data_map
                .iter()
                // 过滤掉超时的
                .filter(|(_, (_, insert_timestamp))| insert_timestamp >= &last_timestamp)
                // 把剩下的数据的时间戳挑出来
                .map(|(_, (_, insert_timestamp))| *insert_timestamp)
                .collect();
            if insert_timestamp_vec.len() == 0 {
                // 一个都没有，就全部删除了
                cid_data_map.clear();
            } else {
                // 降序排列
                insert_timestamp_vec.sort_unstable_by(|a, b| b.cmp(a));
                // 获取第 DATA_COUNT_MAX 位的时间戳
                let one_third = DATA_COUNT_SWEEP_LEFT; // 清扫剩下二分之一
                let last_timestamp = if insert_timestamp_vec.len() > one_third {
                    insert_timestamp_vec[one_third]
                } else {
                    // 前面的 if insert_timestamp_vec.len() > 0 { 已经判断过，一定有数据，否则这里会崩溃
                    insert_timestamp_vec[insert_timestamp_vec.len() - 1]
                };
                // 只留下大于等于这个时间戳的数据
                cid_data_map.retain(|_, (_, insert_timestamp)| *insert_timestamp >= last_timestamp);
                // 记得更新 清扫时间戳
                cid_data_map.insert(CID_DATA_KEY_FOR_SWEEP_TIMESTAMP, (vec![], now_timestamp));
                // println!("完成 sweep_data 时的数据块数量：{:?}", cid_data_map.len());
            }
        }
    }

    pub async fn has_data(&self, cid: u64) -> bool {
        let cid_file_map = self.cid_file_map.read().await;
        match cid_file_map.get(&cid) {
            Some(_) => true,
            None => false,
        }
    }

    // 取出本地数据
    pub async fn get(
        &self,
        cid: u64,
        offset: u64,
        count: u64,
        file_size: u64,
    ) -> anyhow::Result<Vec<u8>> {
        let (data, end_of_data) = self.get_data(cid, offset, count).await;
        let no_data = data.len() == 0;
        if end_of_data {
            // 读到数据块末尾，开线程获取下下一个数据块
            let next_offset = if no_data { offset } else { offset + count };
            // 找到再下一块要下载的数据块的 offset
            let mut next_offset_2 = next_offset + DATA_LEN;
            let mut does_find_next_offset_2 = false;
            for _ in 1..20 {
                // 跑 20 次，看有没有没下载的，有则不跑了
                if !self.has_data_for(cid, next_offset_2).await {
                    does_find_next_offset_2 = true;
                    break;
                } else {
                    next_offset_2 += DATA_LEN;
                }
            }
            if does_find_next_offset_2 {
                // 开第二个线程，二级缓存下载
                if next_offset_2 < file_size {
                    tokio::spawn(async move {
                        // println!(
                        //     "2 - 异步下载 offset= {}，间隔 = {}",
                        //     next_offset_2,
                        //     next_offset_2 - next_offset
                        // );
                        // let time = Instant::now();
                        let _ = CACHE.cache_data(cid, next_offset_2, file_size).await;
                        // println!(
                        //     "2 - 异步下载 offset= {} 结束, 耗时：{:?}",
                        //     next_offset_2,
                        //     time.elapsed()
                        // );
                    });
                    // 三级缓存下载
                    let mut next_offset_3 = next_offset_2 + DATA_LEN_TO_CACHE;
                    let mut does_find_next_offset_3 = false;
                    for _ in 1..20 {
                        // 跑 20 次，看有没有没下载的，有则不跑了
                        if !self.has_data_for(cid, next_offset_3).await {
                            does_find_next_offset_3 = true;
                            break;
                        } else {
                            next_offset_3 += DATA_LEN_TO_CACHE;
                        }
                    }
                    if does_find_next_offset_3 {
                        // 开第三个线程，三级缓存下载
                        if next_offset_3 < file_size {
                            tokio::spawn(async move {
                                // println!(
                                //     "3 - 异步下载 offset= {}，间隔 = {}",
                                //     next_offset_3,
                                //     next_offset_3 - next_offset_2
                                // );
                                // let time = Instant::now();
                                let _ =
                                    CACHE.cache_data_plan_b(cid, next_offset_3, file_size).await;
                                // println!(
                                //     "3 - 异步下载 offset= {} 结束, 耗时：{:?}",
                                //     next_offset_3,
                                //     time.elapsed()
                                // );
                            });
                        }
                    }
                }
            }

            // 没有获取到数据，当场从网络上获取
            if no_data {
                // println!("0 - 同步下载 offset= {}", next_offset);
                // let time = Instant::now();
                let _ = self.fetch_data(cid, next_offset, file_size).await;
                // println!(
                //     "0 - 同步下载 offset= {} 结束, 耗时：{:?}",
                //     next_offset,
                //     time.elapsed()
                // );
            } else {
                // 开第一个线程，一级缓存下载
                tokio::spawn(async move {
                    // println!("1 - 异步下载 offset= {}", next_offset);
                    // let time = Instant::now();
                    let _ = CACHE.fetch_data(cid, next_offset, file_size).await;
                    // println!(
                    //     "1 - 异步下载 offset= {} 结束, 耗时：{:?}",
                    //     next_offset,
                    //     time.elapsed()
                    // );
                });
            }
        }
        let ret_data = if no_data {
            // 没数据，再读一次返回
            let (data, _) = self.get_data(cid, offset, count).await;
            data
        } else {
            data
        };
        Ok(ret_data)
    }
}

#[cfg(test)]
mod tests {
    use crate::util::Timestamp;

    use super::*;

    #[tokio::test]
    async fn test_file() {
        let cid: u64 = 2897206811913763792;
        let file_size = 128030466_u64;
        let mut file = File::new(file_size);
        match file.update_url(cid).await {
            Ok(_url) => {
                println!("更新成功");
            }
            Err(err) => println!("更新失败：{}", err),
        }
        let timestamp_str = Timestamp::seconds_to_local_string(file.url_valid_timestamp).unwrap();
        println!("{:?}, file.url_valid_timestamp= {}", file, timestamp_str);
    }

    // #[tokio::test]
    // async fn test_update_fetcher() {
    //     let cid: u64 = 2897206811913763792;
    //     let file_size = 128030466_u64;
    //     if let Ok(url) = CACHE.update_url(cid, file_size).await {
    //         if let Err(err) = CACHE.update_fetcher(cid, &url).await {
    //             println!("{:?}", err);
    //         }
    //     }
    // }

    #[tokio::test]
    async fn test_fetch_data() {
        let cid: u64 = 2897206811913763792;
        let file_size = 128030466_u64;
        if let Err(err) = CACHE.fetch_data(cid, 0, file_size).await {
            println!("{:?}", err);
        }
    }
}
