// fuse.rs 通过 entry.rs 连接 file.rs, dir.rs , file.rs 连接 api::cache.rs , dir.rs 连接 api::files.rs
use crate::util::Timestamp;
use crate::yyw::{
    api::{API, API_TIMEOUT_SECONDS},
    files::{Payload, Response},
};
use crate::{error, error_bail, setting};
use anyhow::Result;
use chrono::Local;
use fuser::{FileAttr, FileType};
use std::{
    ffi::{OsStr, OsString},
    time::{Duration, UNIX_EPOCH},
};
use tokio::{runtime::Handle, task::block_in_place, time::timeout};

const CHILD_UPDATE_INTERVAL_SECONDS: i64 = 1; // 子文件（夹），更新的最小间隔秒数，避免 fuse 文件系统深度遍历
const UPDATE_INTERVAL_SECONDS: i64 = 30; // 更新自己的时间间隔

#[derive(Debug, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub(crate) struct Dir {
    parent: u64,
    name: OsString,
    cid: u64,
    offset: u64,
    children: Vec<u64>, // 保持插入顺序，又不能重复，为 fuse 的 ino 列表
    create_at: i64,
    update_at: i64, // 更新时间，UPDATE_INTERVAL_SECONDS 秒内不再调用 api 获取子目录
}

impl Dir {
    pub(crate) fn new(
        parent: u64,
        name: OsString,
        cid: u64,
        offset: u64,
        create_at: i64,
        update_at: i64,
    ) -> Self {
        Self {
            parent,
            name,
            cid,
            offset,
            children: vec![],
            create_at,
            update_at,
        }
    }

    pub(crate) fn parent(&self) -> u64 {
        self.parent
    }

    pub(crate) fn set_parent(&mut self, new_parent: u64) {
        self.parent = new_parent;
    }

    pub(crate) fn name(&self) -> &OsStr {
        &self.name
    }

    pub(crate) fn set_name(&mut self, name: OsString) -> Result<(), i32> {
        if name.len() > setting::MAX_NAME_LENGTH {
            error!(
                "更改名字时出错，因超出最长限制：{}",
                setting::MAX_NAME_LENGTH
            );
            Err(libc::ENAMETOOLONG)
        } else {
            self.name = name;
            Ok(())
        }
    }

    pub(crate) fn cid(&self) -> u64 {
        self.cid
    }

    pub(crate) fn offset(&self) -> u64 {
        self.offset
    }

    pub(crate) fn children(&self) -> &[u64] {
        &self.children
    }

    pub(crate) fn did_update_recently(&self) -> bool {
        Local::now().timestamp() - self.update_at < UPDATE_INTERVAL_SECONDS
    }

    pub(crate) fn can_update_child(&self) -> bool {
        Local::now().timestamp() - self.update_at > CHILD_UPDATE_INTERVAL_SECONDS
    }

    // 更新，返回被移除的旧的子文件（夹）
    pub(crate) fn update_children(&mut self, children: &[u64]) -> Vec<u64> {
        let mut removed_items = vec![];
        for item in self.children.clone() {
            if !children.contains(&item) {
                removed_items.push(item);
            }
        }
        self.children.clear();
        self.children.extend_from_slice(children);
        self.update_at = Local::now().timestamp();
        // println!( "dir.rs name= {:?} update_children children={:?}, 删除的子文件 ino 列表为 {:?}", self.name, children, removed_items);
        removed_items
    }

    pub(crate) fn add_child(&mut self, child_ino: u64) -> Result<(), i32> {
        if !self.children.contains(&child_ino) {
            self.children.push(child_ino);
            Ok(())
        } else {
            Err(libc::EEXIST)
        }
    }

    pub(crate) fn delete_child(&mut self, child: u64) -> Option<u64> {
        // 返回被删除的 ino
        if let Some(index) = self.children.iter().position(|&value| value == child) {
            self.children.remove(index);
            Some(child)
        } else {
            None
        }
    }

    pub(crate) fn attr(&self, ino: u64) -> FileAttr {
        FileAttr {
            ino,
            size: 1,
            blocks: 0,
            atime: UNIX_EPOCH, // 1970-01-01 00:00:00
            mtime: UNIX_EPOCH,
            ctime: UNIX_EPOCH,
            crtime: Timestamp::i64_to_system_time(self.create_at),
            kind: FileType::Directory,
            perm: 0o777, // 全权限
            nlink: 2,
            uid: 501,
            gid: 20,
            rdev: 0,
            flags: 0,
            blksize: 512,
        }
    }

    pub(crate) fn update(&self) -> Result<Response> {
        let cid = self.cid;
        let offset = self.offset;
        let name = self.name.clone();
        let handle = Handle::current();
        block_in_place(|| {
            handle.block_on(async {
                let mut payload = Payload::default();
                payload.cid = cid.to_string();
                payload.offset = offset;
                match timeout(
                    Duration::from_secs(API_TIMEOUT_SECONDS),
                    API.files(&payload),
                )
                .await
                {
                    Err(err) => {
                        error_bail!(
                            "请求 api files 读取文件夹 name={:?}, cid= {} 超时 {} 秒，错误：{:?}",
                            name,
                            cid,
                            API_TIMEOUT_SECONDS,
                            err
                        );
                    }
                    Ok(file_api_result) => file_api_result,
                }
            })
        })
    }
}
