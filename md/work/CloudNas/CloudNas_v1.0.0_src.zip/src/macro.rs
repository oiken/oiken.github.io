// 用宏 error!，调用 println 和 tracing::info 或 tracing::warn 或 tracing::error
#[macro_export]
macro_rules! warn {
    ($x:expr) => {
        println!("警告： {}:{}:{}    {:?}", file!(), line!(), column!(), $x);
    };
    ($fmt:expr, $($args:tt)*) => {
        println!("警告： {}:{}:{}    {}", file!(), line!(), column!(), format!($fmt, $($args)*));
    };
}

#[macro_export]
macro_rules! warn_bail {
    ($x:expr) => {
        println!("警告： {}:{}:{}    {:?}", file!(), line!(), column!(), $x);
        anyhow::bail!("{:?}", $x);
    };
    ($fmt:expr, $($args:tt)*) => {
        println!("警告： {}:{}:{}    {}", file!(), line!(), column!(), format!($fmt, $($args)*));
        anyhow::bail!("{}", format!($fmt, $($args)*));
    };
}

#[macro_export]
macro_rules! error {
    ($x:expr) => {
        println!("出错： {}:{}:{}    {:?}", file!(), line!(), column!(), $x);
    };
    ($fmt:expr, $($args:tt)*) => {
        println!("出错： {}:{}:{}    {}", file!(), line!(), column!(), format!($fmt, $($args)*));
    };
}

#[macro_export]
macro_rules! error_bail {
    ($x:expr) => {
        println!("出错： {}:{}:{}    {:?}", file!(), line!(), column!(), $x);
        anyhow::bail!("{:?}", $x);
    };
    ($fmt:expr, $($args:tt)*) => {
        println!("出错： {}:{}:{}    {}", file!(), line!(), column!(), format!($fmt, $($args)*));
        anyhow::bail!("{}", format!($fmt, $($args)*));
    };
}
