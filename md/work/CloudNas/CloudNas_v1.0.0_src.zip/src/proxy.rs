use crate::setting::SETTING;
use crate::ui::Command;
use crate::{error, warn};
use anyhow::Result;
use bytes::Bytes;
use http_body_util::{combinators::BoxBody, BodyExt, Empty, Full};
use hyper::body::Incoming;
use hyper::client::conn::http1::Builder;
use hyper::header::{self, HeaderValue};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::upgrade::Upgraded;
use hyper::{HeaderMap, Method, Request, Response};
use hyper_util::rt::TokioIo;
use std::net::SocketAddr;
use tokio::net::{TcpListener, TcpStream};
use tokio::runtime::Handle;
use tokio::sync::mpsc::Sender;
use tokio::task::block_in_place;

lazy_static::lazy_static! {
    static ref PROXY_PORT: u16 = init_proxy_port();
}

fn init_proxy_port() -> u16 {
    let handle = Handle::current();
    block_in_place(|| {
        handle.block_on(async {
            let setting = SETTING.read().await;
            setting.proxy_service_port()
        })
    })
}

type HttpBody = BoxBody<Bytes, hyper::Error>;

pub async fn get_service_port() -> u16 {
    let port = {
        // 因为这个函数会被 run() 调用，而 run() 会执行 loop，一直不退出，会导致 SETTING.write 一直等
        // 所以要放在大括号里，离开大括号，锁就释放了
        let setting = SETTING.read().await;
        setting.proxy_service_port()
    };
    port
}

// To try this example:
// 1. cargo run --example http_proxy
// 2. config http_proxy in command line
//    $ export http_proxy=http://127.0.0.1:8080 换成实际 ip
//    $ export https_proxy=http://127.0.0.1:8080 换成实际 ip
// 3. send requests
//    $ curl -i https://www.some_domain.com/
pub async fn run(shutdown_sender: Sender<bool>) -> Result<()> {
    let port = get_service_port().await; // 获取端口号启动 proxy 服务
    let addr = SocketAddr::from(([0, 0, 0, 0], port));

    let listener = TcpListener::bind(addr).await?;
    println!(
        "代理服务器已开启，请访问：http://127.0.0.1:{0} 或：http://您的ip地址:{0}",
        port
    );

    loop {
        let (stream, _) = listener.accept().await?;
        let io = TokioIo::new(stream);
        // 进入一个新连接，复制一个 shutdown_sender 给新连接专用
        let shutdown_sender_clone = shutdown_sender.clone();
        tokio::task::spawn(async move {
            if let Err(err) = http1::Builder::new()
                .preserve_header_case(true)
                .title_case_headers(true)
                .serve_connection(
                    io,
                    service_fn(move |req| proxy_handler(req, shutdown_sender_clone.clone())),
                )
                .with_upgrades()
                .await
            {
                error!("失败：连接服务器时: {:?}", err);
            }
        });
    }
}

async fn proxy_handler(
    req: Request<Incoming>,
    shutdown_sender: Sender<bool>,
) -> Result<Response<BoxBody<Bytes, hyper::Error>>, hyper::Error> {
    // println!("代理服务器接收请求: {:?}", req);
    // 预先拦截，如果是来访问本代理服务器的，可以直接返回
    let (req, resp) = intercept_request(req, *PROXY_PORT, shutdown_sender.clone()).await;
    if let Some(response) = resp {
        return Ok(response);
    }

    if Method::CONNECT == req.method() {
        // Received an HTTP request like:
        // ```
        // CONNECT www.domain.com:443 HTTP/1.1
        // Host: www.domain.com:443
        // Proxy-Connection: Keep-Alive
        // ```
        //
        // When HTTP method is CONNECT we should return an empty body
        // then we can eventually upgrade the connection and talk a new protocol.
        //
        // Note: only after client received an empty body with STATUS_OK can the
        // connection be upgraded, so we can't return a response inside
        // `on_upgrade` future.
        if let Some(addr) = host_addr(req.uri()) {
            tokio::task::spawn(async move {
                match hyper::upgrade::on(req).await {
                    Ok(upgraded) => {
                        if let Err(_e) = tunnel(upgraded, addr).await {
                            // warn!("服务器 IO: {:?}", e);
                        };
                    }
                    Err(_e) => {
                        // warn!("http 协议升级时：{:?}", e);
                    }
                }
            });

            Ok(Response::new(empty()))
        } else {
            warn!("无效的网址: {:?}", req.uri());
            let mut resp = Response::new(full("CONNECT must be to a socket address"));
            *resp.status_mut() = hyper::http::StatusCode::BAD_REQUEST;

            Ok(resp)
        }
    } else {
        let host = req
            .uri()
            .host()
            .expect(format!("无效网址：{:?}", req.uri()).as_str());
        let port = req.uri().port_u16().unwrap_or(80);

        let stream = TcpStream::connect((host, port)).await.unwrap();
        let io = TokioIo::new(stream);

        let (mut sender, conn) = Builder::new()
            .preserve_header_case(true)
            .title_case_headers(true)
            .handshake(io)
            .await?;
        tokio::task::spawn(async move {
            if let Err(err) = conn.await {
                warn!("连接服务器时： {:?}", err);
            }
        });
        let resp = sender.send_request(req).await?;
        Ok(resp.map(|b| b.boxed()))
    }
}

fn host_addr(uri: &hyper::http::Uri) -> Option<String> {
    uri.authority().and_then(|auth| Some(auth.to_string()))
}

fn empty() -> BoxBody<Bytes, hyper::Error> {
    Empty::<Bytes>::new()
        .map_err(|never| match never {})
        .boxed()
}

fn full<T: Into<Bytes>>(chunk: T) -> BoxBody<Bytes, hyper::Error> {
    Full::new(chunk.into())
        .map_err(|never| match never {})
        .boxed()
}

// Create a TCP connection to host:port, build a tunnel between the connection and
// the upgraded connection
async fn tunnel(upgraded: Upgraded, addr: String) -> std::io::Result<()> {
    // Connect to remote server
    let mut server = TcpStream::connect(addr).await?;
    let mut upgraded = TokioIo::new(upgraded);

    // Proxying data
    let (_from_client, _from_server) =
        tokio::io::copy_bidirectional(&mut upgraded, &mut server).await?;
    // Print message when done
    // println!("client wrote {} bytes and received {} bytes", from_client, from_server);
    Ok(())
}

fn retrieve_uid_from_cookie(cookie: &str) -> String {
    // 将目标字符串和搜索关键字都转换为小写
    let lower_case_string = cookie.to_lowercase();
    let target_key = "uid=";

    // 查找关键字位置，不区分大小写
    if let Some(uid_index) = lower_case_string.find(target_key) {
        // 找到 UID= 后的位置
        let start_index = uid_index + target_key.len();
        // 从 UID= 后面开始找到 _ 前的位置
        if let Some(underscore_index) = lower_case_string[start_index..].find('_') {
            // 提取 UID 后的子字符串
            let uid_substr = &lower_case_string[start_index..start_index + underscore_index];
            return uid_substr.to_string();
        }
    }
    "".to_string()
}

async fn intercept_request(
    mut request: Request<Incoming>,
    port: u16,
    shutdown_sender: Sender<bool>,
) -> (Request<HttpBody>, Option<Response<HttpBody>>) {
    request.headers_mut().remove("Accept-Encoding");
    let req = request.map(|b| b.boxed());

    if let Some(Ok(host)) = req
        .headers()
        .get(hyper::http::header::HOST)
        .map(|h| h.to_str())
    {
        if host.contains("115.com") {
            // pringln!(" --- req= {:#?}\n --- req.headers() = {:#?}", req, req.headers());
            if let (Some(new_user_agent), Some(new_cookie)) =
                get_user_agent_and_cookie(req.headers())
            {
                println!(
                    "网关服务获取到：\nuser_agent= {}\ncookie= {}",
                    new_user_agent, new_cookie
                );
                // 更新到 SETTING 里，并保存在本地
                let handle = Handle::current();
                let _ = block_in_place(|| {
                    handle.block_on(async {
                        let old_user_agent_cookie = {
                            // SETTING.write() 锁在大括号里，用完就释放
                            let mut setting = SETTING.write().await;
                            let old_user_agent_cookie = setting.user_agent_cookie();
                            let _ = setting
                                .set_user_agent_cookie(&new_user_agent, &new_cookie)
                                .await;
                            old_user_agent_cookie
                        };
                        let old_uid = retrieve_uid_from_cookie(&old_user_agent_cookie.get_cookie());
                        let new_uid = retrieve_uid_from_cookie(&new_cookie);
                        // 如果更换了 id， 需要重新挂载 FUSE 文件夹
                        if old_uid.len() > 0 && !old_uid.eq(&new_uid) {
							warn!("重新挂载云盘，因为旧 Cookie 的 UID 为 {}, 不同于新获取的 Cookie 的 UID {}", old_uid, new_uid);
                            Command::mount_fuse(shutdown_sender.clone()).await;
                        }
                    })
                });
            }
        }
        if host.contains(&format!("127.0.0.1:{}", port).to_string())
            || host.contains(&format!("localhost:{}", port).to_string())
        {
            let resp = Response::builder()
                .header(header::CONTENT_TYPE, "text/plain; charset=UTF-8")
                .body(full(
                    "cloud_nas_proxy service say hello to you! 代理服务器向你问好\n",
                ));
            return (req, Some(resp.unwrap()));
        }
    }
    (req, None)
}

fn get_user_agent_and_cookie(headers: &HeaderMap<HeaderValue>) -> (Option<String>, Option<String>) {
    let user_agents = headers
        .get_all("user-agent")
        .iter()
        .map(|cookie| {
            String::from_utf8(cookie.as_bytes().to_vec())
                .unwrap_or_else(|_| "无效的 user_agents".to_string())
        })
        .collect::<Vec<_>>();
    let mut user_agents = user_agents.iter().filter(|x| x.len() > 0);
    let user_agent = if let Some(user_agent) = user_agents.next() {
        Some(user_agent.to_string())
    } else {
        None
    };

    // 抓取请求中的 cookie
    let cookies = headers
        .get_all("cookie")
        .iter()
        .map(|cookie| {
            String::from_utf8(cookie.as_bytes().to_vec())
                .unwrap_or_else(|_| "无效的 cookie".to_string())
        })
        .collect::<Vec<_>>();
    let mut cookies = cookies
        .iter()
        .filter(|x| x.contains("UID=") && x.contains("CID=") && x.contains("SEID="));
    let cookie = if let Some(cookie) = cookies.next() {
        Some(cookie.to_string())
    } else {
        None
    };

    (user_agent, cookie)
}
