# CloudNas
Mount the cloud storage as a local drive.
