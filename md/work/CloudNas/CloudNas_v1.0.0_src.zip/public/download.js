'use strict';

document.addEventListener("DOMContentLoaded", function () {
	fetch115Dir('', '您的 115 网盘根目录');
});


async function fetch115Dir(dirName, title_str) {
	const h1 = document.getElementById('h1');
	h1.innerText = '当前目录： ' + title_str;
	const tbody = document.getElementById('tb');
	const url = `../../fuse_115_dir${dirName}`; // 将 dirName 作为路径的一部分发送
	const response = await fetch(url);
	try {
		if (response.ok) {
			const data = await response.text();
			tbody.innerHTML = data;
		} else {
			alert(`出错了: ${response.status}`);
		}
	} catch (error) {
		alert(`出错了: ${error}`);
	}
}