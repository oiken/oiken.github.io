document.addEventListener('DOMContentLoaded', () => {
	const statusButton = document.getElementById('statusButton');
	statusButton.addEventListener('click', onClicked);
	const rebootButton = document.getElementById('rebootButton');
	rebootButton.addEventListener('click', onClicked);
	const remountButton = document.getElementById('remountButton');
	remountButton.addEventListener('click', onClicked);

	updateFuse115DiskPath();

	// 设置定时任务
	setInterval(updateCookie, 3000); // 3 秒获取一次
	setInterval(updateLoginStatus, 1000 * 60); // 一分钟获取一次

	// 先获取一次
	updateUserId();
	updateLoginStatus();
	updateProxyPort();
	updateCookie();
})

async function updateFuse115DiskPath() {
	const fuse115DiskPathLabel = document.getElementById('fuse115DiskPathLabel');
	fetch('../../fuse_115').then(response => response.text())
		.then(data => {
			fuse115DiskPathLabel.innerText = data;
		})
		.catch(error => { fuse115DiskPathLabel.innerText = error; });
}

async function updateUserId() {
	const userId = document.getElementById('userId');
	fetch('../../uid').then(response => response.text())
		.then(timestamp => {
			userId.innerText = '用户 ' + timestamp;
			const datetime = new Date(timestamp * 1000);
			//  datetime.toLocaleString() 是  "2024/7/3 11:45:50"
			// const datetime_str = datetime.toLocaleString();
			// 创建一个格式化选项对象
			var options = {
				year: 'numeric',
				month: 'long',
				day: 'numeric',
				hour: '2-digit',
				minute: '2-digit',
				second: '2-digit',
			};
			// 使用 Intl.DateTimeFormat 格式化日期和时间
			var datetime_str = new Intl.DateTimeFormat('zh-CN', options).format(datetime);
			userId.title = '        第一次开启是在：\n ' + datetime_str;
		})
		.catch(error => {
			console.error('Http 请求 api 接口 fetchUserId 失败：', error);
			userId.innerHtml = '用户账户';
		});
}

async function updateLoginStatus() {
	const statusDisplay = document.getElementById('statusDisplay');
	fetch('../../login_status').then(response => response.text())
		.then(data => {
			statusDisplay.innerText = data;
		})
		.catch(error => { statusDisplay.innerText = error; });
}

async function updateProxyPort() {
	const proxyPort = document.getElementById('proxyPort');
	fetch('../../proxy_port').then(response => response.text())
		.then(data => {
			proxyPort.innerText = data;
		})
		.catch(error => { proxyPort.innerText = error; });
}

async function updateCookie() {
	const cookieDisplay = document.getElementById('cookieDisplay');
	fetch('../../cookie').then(response => response.text())
		.then(data => {
			cookieDisplay.innerText = data;
		})
		.catch(error => { cookieDisplay.innerText = error; });
}

async function reboot() {
	const rebootButton = document.getElementById('rebootButton');
	rebootButton.innerText = '发送关闭命令';
	fetch('../../reboot').then(response => response.text())
		.then(data => {
			if (data.startsWith('关闭失败')) {
				alert(data + '，请刷新再试');
				rebootButton.innerText = '重新启动';
			} else {
				// 等待 5 秒，重启需要时间
				const wait_seconds = 5;
				for (let i = 0; i <= wait_seconds; i++) {
					setTimeout(function () {
						rebootButton.innerText = data + '，' + (wait_seconds - i) + ' 秒后尝试连接';
					}, i * 1000);
				}
				setTimeout(function () {
					// 测试随便一个接口即可
					fetch('../../proxy_port').then(response => response.text())
						.then(data => {
							alert('重启成功，自动刷新页面');
							location.reload();
						})
						.catch(error => {
							rebootButton.innerText = '重新启动';
							alert('重启失败：' + error + '，请稍后再试');
						});
				}, wait_seconds * 1000);
			}
		}).catch(error => {
			rebootButton.innerText = '重新启动';
			alert('重启失败：' + error + '，请稍后再试');
		});
}

async function remount() {
	const remountButton = document.getElementById('remountButton');
	remountButton.innerText = "正在重新挂载";
	fetch('../../remount').then(response => response.text())
		.then(data => {
			alert(data);
			remountButton.innerText = "重新挂载";
		})
		.catch(error => { remountButton.innerText = error; });
}

function onClicked(event) {
	event.preventDefault();

	switch (event.target.id) {
		case 'rebootButton': {
			reboot();
			break;
		}
		case 'statusButton': {
			document.getElementById('statusDisplay').innerText = '刷新中...';
			updateLoginStatus();
			break;
		}
		case 'remountButton': {
			remount();
			break;
		}
	}
}