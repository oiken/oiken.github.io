use axum::{
    body::Body,
    extract::{DefaultBodyLimit, Host, Multipart, Path},
    handler::HandlerWithoutStateExt,
    http::{header, StatusCode, Uri},
    response::{Html, IntoResponse, Redirect},
    routing::{delete, get, post},
    BoxError, Router,
};
use axum_server::tls_rustls::RustlsConfig;
use axum_static::static_router;
// use rustls_acme::{caches::DirCache, AcmeConfig};
use std::{ffi::OsString, net::SocketAddr, path::PathBuf};
use tokio::{
    fs::{self, remove_dir_all, remove_file, File},
    io::{self, AsyncReadExt, AsyncWriteExt},
};
// use tokio_stream::StreamExt;
use tower::ServiceBuilder;
use tower_http::{
    compression::CompressionLayer,
    cors::{Any, CorsLayer},
    decompression::DecompressionLayer,
    validate_request::ValidateRequestHeaderLayer,
};

enum ArgOption {
    PublicDirectory,
    HttpsCertDirectory,
    // IsProductionOfLetsEncrypt,
    Help,
}

#[derive(Clone, Copy)]
struct Port {
    http: u16,
    https: u16,
}

#[tokio::main]
async fn main() {
    if let (_, Some(_)) = _parse_arg_of_command(ArgOption::Help) {
        // 如果用户的命令有 -h 会返回空字符串的值
        println!("Usage: {} [options...]", _get_command_name());
        println!("-p, <public_directory_path>	Public files such as index.html, default is current path ./public");
        // println!("-c, <https_cert_directory_path> Cert files for https service. Will use let's encrypt acme if not given");
        // println!("--prod			Is production enviroment of let's encrypt acme");
        println!("-h				Get help for commands");
        let args: Vec<OsString> = std::env::args_os().collect();
        if args.len() == 2 {
            // 只有 xxx -h  那这里就执行完毕了
            return;
        }
    }

    let public_dir_path_result = _public_directory_path();
    if let Some(public_dir_path) = public_dir_path_result {
        let service = ServiceBuilder::new()
            // 启用压缩和解压缩，json校验以及 禁止跨站请求
            .layer(CompressionLayer::new())
            .layer(DecompressionLayer::new())
            .layer(ValidateRequestHeaderLayer::accept("application/json"))
            .layer(CorsLayer::new().allow_origin(Any));

        let router = Router::new()
            .route("/greeting", get(|| async { "Hello, world!" }))
            .route(
                "/",
                get(|| async { Redirect::permanent("/public/index.html") }),
            )
            //	实现了下载的网页和大文件流传输，但决定不用它，直接在网页上用静态文件夹里的文件
            // .route("/download", get(download_html))
            // .route("/download/*file_name", get(do_download))
            .route("/upload", get(upload_html))
            .route("/do_upload", post(do_upload))
            .route("/delete/*file_name", delete(do_delete))
            .route("/contract", get(contract_html))
            .nest("/public", static_router(public_dir_path))
            .layer(DefaultBodyLimit::max(1024 * 1024 * 100))
            .layer(service);

        let command_name = _get_command_name();
        let ports = Port {
            http: 80,
            https: 443,
        };
        // 可选: spawn a second server to redirect http requests to this server
        tokio::spawn(redirect_http_to_https(ports));
        let addr = SocketAddr::from(([0, 0, 0, 0], ports.https));

        // 如果命令选项提供了自签名的证书文件夹，创建 HTTPS 连接器 来自：https://github.com/tokio-rs/axum/blob/main/examples/tls-rustls
        let https_cert_dir_result = _https_cert_directory_path();
        if let Some(https_cert_dir) = https_cert_dir_result {
            let https_cert_pem = https_cert_dir.join("cert.pem");
            let https_key_pem = https_cert_dir.join("key.pem");
            if https_cert_pem.exists() && https_key_pem.exists() {
                // 有自签名的证书才有 https 功能
                if let Ok(config) = RustlsConfig::from_pem_file(https_cert_pem, https_key_pem).await
                {
                    println!(
                        "Website {} is listening https：0.0.0.0:443 , using self signed certs",
                        command_name
                    );
                    axum_server::bind_rustls(addr, config)
                        .serve(router.into_make_service())
                        .await
                        .unwrap();
                    return;
                }
            }
        }
        // // 如果命令选项没有提供自签名证书的目录，就用 lets encrypt 颁发的证书
        // let mut is_production_now = false;
        // if let (_, Some(_)) = _parse_arg_of_command(ArgOption::IsProductionOfLetsEncrypt) {
        //     is_production_now = true;
        // }
        // let mut state = AcmeConfig::new(["iken.3d.tc".to_string()])
        //     .contact(["mailto:oiken@qq.com".to_string()])
        //     .cache_option(Some(DirCache::new("./acme_cert")))
        //     .directory_lets_encrypt(is_production_now)
        //     .state();
        // // 要设置 rustls-acme = { version = "0.9.2", feature = ["axum"] }
        // let acceptor = state.axum_acceptor(state.default_rustls_config());
        // tokio::spawn(async move {
        //     loop {
        //         match state.next().await.unwrap() {
        //             Ok(ok) => println!("event: {:?}", ok),
        //             Err(err) => println!("error: {:?}", err),
        //         }
        //     }
        // });
        // println!(
        //     "Use let's encrypt acme https cert.\nWebsite {} is listening https：0.0.0.0:443",
        //     command_name
        // );
        // axum_server::bind(addr)
        //     .acceptor(acceptor)
        //     .serve(router.into_make_service())
        //     .await
        //     .unwrap();
        // return;

        println!(
            "There is no any https cert.\nWebsite {} is listening https：0.0.0.0:80",
            command_name
        );
        let listenr = tokio::net::TcpListener::bind("0.0.0.0:80").await.unwrap();
        axum::serve(listenr, router.into_make_service())
            .await
            .unwrap();
    } else {
        println!("Failed: The public directory is not exist.\nPlease type -h for help.");
    }
}

async fn contract_html() -> impl IntoResponse {
    let mut html = _read_public_file_to_string("contract.html").await;
    let p_element = "<p id=\"sourceCodeText\" style=\"width: 90vw; height: 100%;\"></p>";
    let contract_source_code = _read_public_file_to_string("download/odd_or_even.sol")
        .await
        .replace("\n", "<br>")
        .replace("    ", "&nbsp;&nbsp;&nbsp;&nbsp;")
        .replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
    let new_p_elements = format!(
        "<p id=\"sourceCodeText\" style=\"width: 90vw; height: 100%;\">{}</p>",
        contract_source_code
    );
    html = html.replace(&p_element, &new_p_elements);
    Html(html)
}

async fn do_delete(Path(file_name): Path<String>) -> impl IntoResponse {
    if let Some(download_dir) = _download_directory_path() {
        let current_path = download_dir.join(&file_name);
        if current_path.exists() {
            // 处理文件
            if current_path.is_file() {
                if let Err(err) = remove_file(&current_path).await {
                    return (
                        axum::http::StatusCode::INTERNAL_SERVER_ERROR,
                        format!("删除文件失败: {}", err),
                    )
                        .into_response();
                }
            }

            // 处理文件夹
            if current_path.is_dir() {
                if let Err(err) = remove_dir_all(&current_path).await {
                    return (
                        axum::http::StatusCode::INTERNAL_SERVER_ERROR,
                        format!("删除文件夹失败: {}", err),
                    )
                        .into_response();
                }
            }

            return (
                axum::http::StatusCode::OK,
                format!("成功删除文件或文件夹: {}", file_name),
            )
                .into_response();
        }
    }
    (
        axum::http::StatusCode::NOT_FOUND,
        format!("文件或文件夹不存在: {}", file_name),
    )
        .into_response()
}

#[allow(dead_code)]
async fn download_html() -> impl IntoResponse {
    let mut html = _read_public_file_to_string("download.html").await;
    html = insert_file_list_html(&html, false).await;
    Html(html)
}

async fn insert_file_list_html(html: &str, has_delete_button: bool) -> String {
    let mut html = html.to_string();
    let ul_element = "<div class=\"dmgFileList\"></div>";
    if let Ok(li_elements) = file_list_html(has_delete_button, ".*").await {
        let new_ul_elements = format!("<div class=\"dmgFileList\">{}</div>", &li_elements);
        html = html.replace(ul_element, &new_ul_elements);
    }
    html
}

#[allow(dead_code)]
async fn do_download(file_path_string: String) -> impl IntoResponse {
    if let Some(download_dir) = _download_directory_path() {
        let curent_path = download_dir.join(&file_path_string);
        if curent_path.is_file() {
            return {
                // 下载逻辑
                let file = tokio::fs::File::open(curent_path.to_str().unwrap())
                    .await
                    .unwrap();
                let stream = tokio_util::io::ReaderStream::new(file);
                let body = Body::from_stream(stream);

                let headers = [
                    (
                        header::CONTENT_TYPE,
                        "text/plain; charset=utf-8".to_string(),
                    ),
                    (
                        header::CONTENT_DISPOSITION,
                        format!(
                            "attachment; filename=\"{}\"",
                            curent_path.file_name().unwrap().to_str().unwrap()
                        ),
                    ),
                ];

                (headers, body)
            };
        }

        // 处理目录嵌套
        if curent_path.is_dir() {
            let entries = std::fs::read_dir(&curent_path).unwrap();
            let mut lines = vec![];
            for entry in entries {
                let entry = entry.unwrap();
                let filename = entry.file_name().to_str().unwrap().to_string();

                lines.push(format!(
                    "<a href=/{}/{}> {} </a>",
                    &file_path_string, &filename, &filename
                ));
            }
            let res_content = lines.join("<br/>");

            return (
                [
                    (header::CONTENT_TYPE, "text/html; charset=utf-8".to_string()),
                    (header::SERVER, "axum".to_string()),
                ],
                Body::from(res_content),
            );
        }
    }
    (
        [
            (header::CONTENT_TYPE, "text/html; charset=utf-8".to_string()),
            (header::SERVER, "axum".to_string()),
        ],
        Body::from(format!("无效路径: {}", file_path_string)),
    )
}

// 把目录下的所有 dmg 列出成 li 组件进行下载
async fn file_list_html(has_delete_button: bool, file_suffix: &str) -> Result<String, io::Error> {
    if let Some(download_dir) = _download_directory_path() {
        let mut html = String::new();
        let mut entries = fs::read_dir(download_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            let file_path = entry.path();
            if let Some(file_name) = file_path.file_name().and_then(|name| name.to_str()) {
                if !file_suffix.eq(".*") && !file_name.ends_with(file_suffix) {
                    // 如果后缀不是 。* 全要，就匹配的文件才要
                    continue;
                }
                let button = if has_delete_button {
                    format!(
                        "<button class=\"deleteButton\" data-filename=\"{}\">删除</button>\t",
                        file_name
                    )
                } else {
                    "".to_string()
                };
                html.push_str(&format!(
                    "<p>{}<a href=\"/download/{}\">{}</a></p>",
                    button, file_name, file_name
                ));
            }
        }
        return Ok(html);
    }
    Err(io::Error::new(
        io::ErrorKind::NotFound,
        "Error: Download directory not found!",
    ))
}

async fn upload_html() -> impl IntoResponse {
    let mut html = _read_public_file_to_string("upload.html").await;
    html = insert_file_list_html(&html, true).await;
    Html(html)
}

async fn do_upload(mut multipart: Multipart) -> Result<impl IntoResponse, (StatusCode, String)> {
    if let Some(download_dir) = _download_directory_path() {
        while let Some(mut field) = multipart
            .next_field()
            .await
            .map_err(|err| (StatusCode::BAD_REQUEST, err.to_string()))?
        {
            let file_name = field.file_name().unwrap();
            let file_path = format!("{}/{}", download_dir.display(), file_name);
            println!("upload file: {}", file_path);
            let mut o_file = fs::File::create(file_path.as_str()).await.unwrap();

            while let Some(chunk) = field
                .chunk()
                .await
                .map_err(|err| (StatusCode::BAD_REQUEST, err.to_string()))?
            {
                o_file.write_all(&chunk).await.unwrap();
            }
        }
    }
    Ok(upload_html().await)
}

async fn _read_public_file_to_string(partial_file_path: &str) -> String {
    let mut file_content = String::new();
    // 可以直接写死在运行程序里，比如 include_str!("../public/upload.html");
    // 但修改了 html ，也就要重新打包运行程序 ，所以选择读入文件
    if let Some(public_directory_path) = _public_directory_path() {
        let file_path = public_directory_path.join(partial_file_path);
        match File::open(file_path).await {
            Ok(mut file) => {
                if let Err(error) = file.read_to_string(&mut file_content).await {
                    file_content = format!("{:?}", error);
                };
            }
            Err(error) => file_content = format!("{:?}", error),
        }
        return file_content;
    }
    "".to_string()
}

// https 功能
#[allow(dead_code)]
async fn redirect_http_to_https(ports: Port) {
    fn make_https(host: String, uri: Uri, ports: Port) -> Result<Uri, BoxError> {
        let mut parts = uri.into_parts();

        parts.scheme = Some(axum::http::uri::Scheme::HTTPS);

        if parts.path_and_query.is_none() {
            parts.path_and_query = Some("/".parse().unwrap());
        }

        let https_host = host.replace(&ports.http.to_string(), &ports.https.to_string());
        parts.authority = Some(https_host.parse()?);

        Ok(Uri::from_parts(parts)?)
    }

    let redirect = move |Host(host): Host, uri: Uri| async move {
        match make_https(host, uri, ports) {
            Ok(uri) => Ok(Redirect::permanent(&uri.to_string())),
            Err(_error) => Err(StatusCode::BAD_REQUEST),
        }
    };

    let addr = SocketAddr::from(([0, 0, 0, 0], ports.http));
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, redirect.into_make_service())
        .await
        .unwrap();
}

fn _upload_directory_path() -> Option<PathBuf> {
    if let Some(path) = _public_directory_path() {
        let path = path.join("upload");
        if path.exists() {
            return Some(path);
        }
    }
    None
}

fn _download_directory_path() -> Option<PathBuf> {
    if let Some(path) = _public_directory_path() {
        let path = path.join("download");
        if path.exists() {
            return Some(path);
        }
    }
    None
}

fn _public_directory_path() -> Option<PathBuf> {
    let mut path: PathBuf = std::env::current_dir().unwrap().join("public");
    if let (_, Some(option_value)) = _parse_arg_of_command(ArgOption::PublicDirectory) {
        let Ok(result) = PathBuf::try_from(option_value);
        path = result;
    }
    if path.exists() {
        Some(path)
    } else {
        None
    }
}

fn _https_cert_directory_path() -> Option<PathBuf> {
    // 不用默认的，选项没设置就用 lets encrypt acme的证书，
    let mut path: PathBuf = std::env::current_dir().unwrap().join("https_cert");
    if let (_, Some(option_value)) = _parse_arg_of_command(ArgOption::HttpsCertDirectory) {
        let Ok(result) = PathBuf::try_from(option_value);
        path = result;
    }
    if path.exists() {
        return Some(path);
    } else {
        None
    }
}

fn _parse_arg_of_command(option_type: ArgOption) -> (String, Option<String>) {
    let option = match option_type {
        ArgOption::PublicDirectory => "-p",
        ArgOption::HttpsCertDirectory => "-c",
        // ArgOption::IsProductionOfLetsEncrypt => "--prod",
        ArgOption::Help => "-h",
    };
    let args: Vec<OsString> = std::env::args_os().collect();
    for i in 1..args.len() {
        // 第一个是程序的名称
        if let Some(arg) = args.get(i) {
            if arg.eq(&OsString::from(option)) {
                if let Some(next_arg) = args.get(i + 1) {
                    let next_arg_string = <OsString as Clone>::clone(&next_arg)
                        .into_string()
                        .unwrap_or_else(|os_str| os_str.to_string_lossy().into_owned());
                    return (option.to_string(), Some(next_arg_string)); // 有选项，有值
                } else {
                    return (option.to_string(), Some("".to_string())); // 有选项，没值
                }
            }
        }
    }
    (option.to_string(), None) // 没选项，返回 None
}

fn _get_command_name() -> String {
    let args: Vec<OsString> = std::env::args_os().collect();
    match args.get(0) {
        Some(name) => <OsString as Clone>::clone(&name)
            .into_string()
            .unwrap_or_else(|os_str| os_str.to_string_lossy().into_owned()),
        None => "website.oiken.wang".to_string(),
    }
}
