'use strict';

document.addEventListener("DOMContentLoaded", function () {
	// 获取所有删除按钮
	const deleteButtons = document.querySelectorAll('.deleteButton');

	// 为每个删除按钮添加点击事件处理程序
	deleteButtons.forEach(button => {
		button.addEventListener('click', () => {
			// 获取要删除的文件名
			const filename = button.getAttribute('data-filename');
			// 发送删除请求到服务器
			fetch(`/delete/${filename}`, {
				method: 'DELETE'
			})
				.then(response => {
					if (!response.ok) {
						throw new Error('删除文件失败');
					}
					// 删除成功后移除文件列表中对应的元素
					button.parentElement.remove();
				})
				.catch(error => {
					console.error('删除文件失败:', error);
				});
		});
	});
});

// <input type="submit" value="上传" onclick="return validateUploadForm()"></input>
// 如果没有，则弹出警告并返回 false，阻止表单提交。如果有选择文件，则返回 true，允许表单提交
function validateUploadForm() {
	// 获取文件输入框
	var fileInput = document.getElementById('filePathInput');
	// 检查是否已选择文件
	if (fileInput.files.length === 0) {
		// 如果没有选择文件，阻止表单提交
		// alert('请先选择要上传的文件');
		return false;
	}
	// 如果选择了文件，允许表单提交
	return true;
}
