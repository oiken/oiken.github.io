-- test.lua
function add(a, b)
    return a + b
end

print("LuaJIT 对你说：Hello!")
return add(10, 20)
