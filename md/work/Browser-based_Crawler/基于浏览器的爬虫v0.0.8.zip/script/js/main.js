// 使用 ES6(ES2015)
'use strict';

const taskContent = {}; // 装载要上传任务的内容

// 注意 ` 不是普通的单引号 '
const divHtml = `
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css">
<style>
    body {
        margin: 0;
        padding: 0;
        min-height: 100vh;
        background-color: #fff;
    }
    .toolbar-container {
        display: flex;
        gap: 1em;
    }
    .content-container {
        flex: 1;
    }
</style>
<!-- 顶部固定工具栏 -->
<div class="pure-g" style="position: fixed; top: 0; left: 30.5vw; width: 68vw; background-color:rgb(163, 159, 159); z-index: 1000;">
	<div class="pure-u-1 toolbar-container">
		<div id="canvasContainer" style="max-width: 30%; min-width: 0;">
		</div>

        <div class="content-container" style="padding: 1em;">
            <div class="pure-u-1">
                <textarea id="contentText" class="pure-u-1"
                    style="height: 300px; padding: 8px; margin-bottom: 5px; resize: none; box-sizing: border-box;" readonly></textarea>
            </div>
            <div class="pure-u-1">
                <form class="pure-form" style="display: flex; gap: 5px;">
                    <input value="" id="typeValue" placeholder="要爬取的类型" class="pure-u-1" style="flex: 1;">
                    <input value="" id="pageValue" placeholder="要爬取的第几页" class="pure-u-1" style="flex: 1;">
                    <button type="button" id="restartStateBtn" class="pure-button pure-button-primary">重新开始</button>
					<button type="button" id="excuteStateActionBtn" class="pure-button pure-button-primary">执行此步骤</button>
                </form>
            </div>
        </div>
    </div>
</div>
`;

// 模拟人工滚动页面
class HumanScroller {
	constructor() {
		this.phase = 'initial-down';  // 初始阶段：下滑
		this.isScrolling = false;
		this.lastScrollPosition = 0;
		this.scrollTimeout = null;
	}

	// 开始滚动
	start() {
		if (this.isScrolling) return;
		this.isScrolling = true;
		this.scroll();
	}

	// 停止滚动
	stop() {
		this.isScrolling = false;
		if (this.scrollTimeout) {
			clearTimeout(this.scrollTimeout);
		}
	}

	// 获取基于阶段的随机延迟
	getRandomDelay() {
		switch (this.phase) {
			case 'initial-down':
				return Math.random() * 1800 + 1200;  // ms，慢速下滑
			case 'slow-up':
				return Math.random() * 1500 + 750;  // ms，中速上滑
			case 'random':
				return Math.random() * 2800 + 750;  // ms，随机慢速
		}
	}

	// 获取基于阶段的步长
	getScrollStep() {
		switch (this.phase) {
			case 'initial-down':
				// 慢速下滑，偶尔很小幅上滑
				if (Math.random() < 0.9) {
					return Math.random() * 150 + 100; // 100-250px 慢速向下
				} else {
					return -(Math.random() * 30 + 10); // 10-40px 很小幅向上
				}

			case 'slow-up':
				// 中速上滑，偶尔小幅下滑
				if (Math.random() < 0.85) {
					return -(Math.random() * 180 + 120); // 120-300px 中速向上
				} else {
					return Math.random() * 100 + 50; // 50-150px 小幅向下
				}

			case 'random':
				// 随机慢速滚动：35%向下，35%向上，30%中幅度随机
				const rand = Math.random();
				if (rand < 0.35) {
					return Math.random() * 150 + 80; // 80-230px 向下
				} else if (rand < 0.7) {
					return -(Math.random() * 150 + 80); // 80-230px 向上
				} else {
					return (Math.random() * 300 + 150) * (Math.random() < 0.5 ? 1 : -1); // ±150-450px
				}
		}
	}

	// 检查并更新滚动阶段
	updatePhase() {
		const currentPosition = window.scrollY;
		const maxScroll = document.documentElement.scrollHeight - window.innerHeight;

		// 如果在初始下滑阶段且到达底部，切换到上滑阶段
		if (this.phase === 'initial-down' && currentPosition >= maxScroll - 50) {
			this.phase = 'slow-up';
		}
		// 如果在上滑阶段且到达顶部，切换到随机阶段
		else if (this.phase === 'slow-up' && currentPosition <= 50) {
			this.phase = 'random';
		}
	}

	// 执行滚动
	scroll() {
		if (!this.isScrolling) return;

		// 获取当前滚动位置和最大滚动位置
		const currentPosition = window.scrollY;
		const maxScroll = document.documentElement.scrollHeight - window.innerHeight;

		// 获取滚动步长
		const step = this.getScrollStep();

		// 计算新的滚动位置
		let newPosition = currentPosition + step;

		// 确保不超出边界
		newPosition = Math.max(0, Math.min(newPosition, maxScroll));

		// 执行滚动
		window.scrollTo({
			top: newPosition,
			behavior: 'smooth'
		});

		// 更新阶段
		this.updatePhase();

		// 设置下一次滚动
		this.scrollTimeout = setTimeout(() => {
			this.scroll();
		}, this.getRandomDelay());
	}
}

function watchScrollDepth(timeOutSeconds, maxTimeOutSeconds, callback) {
	let hasExceededThreshold = false;
	let elapsedTime = 0;
	let intervalId;

	function checkScrollDepth() {
		// 获取页面总高度和当前滚动位置
		const pageHeight = Math.max(
			document.documentElement.scrollHeight,
			document.body.scrollHeight
		);
		const scrollPosition = window.scrollY + window.innerHeight;
		const threshold = pageHeight * 0.5;

		// 每隔 3 秒打印当前时间和滚动深度信息
		if (elapsedTime > 0 && elapsedTime % 10 === 0) {
			logInfo(`已经过 ${elapsedTime} 秒，超过 ${maxTimeOutSeconds} 秒或滚动到页面一半高度，触发下个动作`);
		}
		// 检查是否超过阈值
		if (scrollPosition > threshold) {
			hasExceededThreshold = true;
		}

		elapsedTime++;

		// 修改点：达到 maxTimeOutSeconds 时强制触发回调
		if (elapsedTime >= maxTimeOutSeconds) {
			logInfo('达到最大超时时间，强制触发回调！');
			callback();
			// 重置状态并重新开始
			hasExceededThreshold = false;
			elapsedTime = 0;
		} else if (elapsedTime >= timeOutSeconds && hasExceededThreshold) {
			logInfo('达到超时时间且已超过阈值，触发回调！');
			callback();
			// 重置状态并重新开始
			hasExceededThreshold = false;
			elapsedTime = 0;
		}
	}

	// 设置每秒检查一次
	intervalId = setInterval(checkScrollDepth, 1000);

	return () => {
		clearInterval(intervalId);
	};
}

// 状态机类
class StateMachine {
	constructor(initialState) {
		this.currentState = initialState;
		this.stateActions = {};
		this.beforeTransitionCallbacks = {};
	}

	/**
	* 获取当前状态
	* @returns {string} 当前状态
	*/
	getCurrentState() {
		return this.currentState;
	}

	/**
	* 设置当前状态
	* @returns {string} 当前状态
	*/
	setCurrentState(newState) {
		this.currentState = newState;
	}

	/**
	 * 添加状态持续动作
	 * @param {string} state 状态
	 * @param {function} action 持续动作函数，返回需要触发的事件名称或null
	 */
	addStateAction(state, action) {
		this.stateActions[state] = action;
	}

	/**
	 * 执行当前状态的持续动作
	 */
	async executeStateAction() {
		if (this.stateActions[this.currentState]) {
			await this.stateActions[this.currentState]();
		}
	}

	/**
	 * 添加状态转换前的回调函数
	 * @param {string} fromState 起始状态
	 * @param {string} event 事件名称
	 * @param {function} callback 回调函数
	 */
	addBeforeTransitionCallback(fromState, event, callback) {
		if (!this.beforeTransitionCallbacks[fromState]) {
			this.beforeTransitionCallbacks[fromState] = {};
		}
		if (!this.beforeTransitionCallbacks[fromState][event]) {
			this.beforeTransitionCallbacks[fromState][event] = [];
		}
		this.beforeTransitionCallbacks[fromState][event].push(callback);
	}

	/**
	 * 执行状态转换前的回调函数
	 */
	async executeBeforeTransitionCallback(fromState, event) {
		if (this.beforeTransitionCallbacks[fromState][event]) {
			for (const callback of this.beforeTransitionCallbacks[fromState][event]) {
				// await delay(3000); // 延时3秒执行
				await callback();
			}
		}
	}
}

class WordPressAPI {
	constructor(apiSite, username, appPassword) {
		this.apiUrl = `${apiSite}/wp-json/wp/v2/posts`;
		this.credentials = btoa(`${username}:${appPassword}`);
	}

	/**
	 * 检查文章是否存在
	 * @param {string} slug 文章别名
	 * @returns {Promise<Array>} 查询到的文章列表
	 */
	async checkPostExists(slug) {
		try {
			const queryUrl = `${this.apiUrl}?slug=${encodeURIComponent(slug)}&status=any`;
			const response = await fetch(queryUrl, {
				method: 'GET',
				headers: {
					'Authorization': `Basic ${this.credentials}`,
					'Content-Type': 'application/json'
				}
			});

			if (!response.ok) {
				throw new Error(`HTTP 错误! 状态码: ${response.status}`);
			}

			const posts = await response.json();
			if (posts.length > 0) {
				const titles = posts
					.map(post => post.title.rendered)
					.join(' , ');
				return `${titles}`;
			}
			return "";
		} catch (error) {
			logError(`行号: ${getLineNumber()}错误是：    检查文章是否存在时出错：${error}`);
			throw error;
		}
	}
}

async function uploadTaskContentToWordPress({ siteUrl, username, password, post }) {
	const url = `${siteUrl}/wp-json/wp/v2/posts`;
	const credentials = btoa(`${username}:${password}`);

	try {
		const response = await fetch(url, {
			method: 'POST',
			headers: {
				'Authorization': 'Basic ' + credentials,
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(post)
		});

		if (!response.ok) {
			logError(`行号: ${getLineNumber()}错误是：    post返回不是 OK： response.status = ${response.status}, statusText: ${response.statusText}, headers: ${JSON.stringify([...response.headers])}`);
			doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
			return;
		}
		const responseData = await response.json();

		if (responseData.id) {
			logInfo(`行号: ${getLineNumber()}    成功入库: ${post.title}，返回 responseData.id = ${responseData.id}，response status: ${response.status}, statusText: ${response.statusText}`);
			getSavedUploadedMovieSum().then(value => {
				const newValue = value + 1;
				ui.pageValue.value = "已上传总数： " + newValue;
				saveUploadedMovieSum(newValue).then(_ => { });
			});
			doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.FOUND).then(_ => { });
		} else {
			logError(`行号: ${getLineNumber()}错误是：    创建失败： ${post.title}，response status: ${response.status}, statusText: ${response.statusText}`);
			doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
		}
	} catch (error) {
		logError(`行号: ${getLineNumber()}错误是：    入库时出错，不一定是失败了: ${error}`);
		doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
	}
}

// WordPress上传图片函数
async function uploadImageToWordPress({ siteUrl, username, password, blob, filename, mimeType }) {
	const url = `${siteUrl}/wp-json/wp/v2/media`;
	const credentials = btoa(`${username}:${password}`);

	try {
		const response = await fetch(url, {
			method: 'POST',
			headers: {
				'Authorization': `Basic ${credentials}`,
				'Content-Disposition': `attachment; filename="${filename}"`,
				'Content-Type': mimeType,
			},
			body: blob // 直接发送blob数据
		});
		if (!response.ok) {
			logError(`行号: ${getLineNumber()}错误是：    HTTP 出错 状态是: ${response.status}\n`);
		}
		const data = await response.json();
		if (data.id) {
			return data.id; // 返回媒体ID
		} else {
			logError(`行号: ${getLineNumber()}错误是：    上传图片失败：${data.message}`);
		}
	} catch (error) {
		logError(`行号: ${getLineNumber()}错误是：    上传图片失败: ${error.message}`);
	}
}

const STATE = {
	GET_TASK_JSON: 'STATE.GET_TASK_JSON',
	NEXT_TASK: 'STATE.NEXT_TASK',
	NEXT_PAGE_TYPE: 'STATE.NEXT_PAGE_TYPE',
	GET_CONTENT: 'STATE.GET_CONTENT',
	UPLOAD_CONTENT: 'STATE.UPLOAD_CONTENT'
};
const EVENT = {
	FOUND: 'EVENT.FOUND',
	EMPTY: 'EVENT.EMPTY',
};
// 创建状态机实例
const doubanFSM = new StateMachine(STATE.GET_TASK_JSON);

doubanFSM.addStateAction(STATE.UPLOAD_CONTENT, async () => {
	log(`行号: ${getLineNumber()}    状态 ${STATE.UPLOAD_CONTENT} 的 动作，获取图片剪裁，上传成功后得到 media_id 放进已经保存好的 taskContent 上传，\
		不论成败，进入 STATE.NEXT_TASK`);
	const movieSlug = await getSavedMovieSlug();
	if (undefined === movieSlug || 0 === movieSlug.length) {
		await doubanFSM.executeBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.EMPTY);
	} else {
		getTaskImage(movieSlug).then(({ fileName, imgBase64String }) => { // getTaskImage 里面得到图片再渲染，还要剪裁，还要上传图片，还要上传数据，有问题或错误，就转 NEXT_TASK, 没问题也是转 NEXT_TASK
			logInfo(`行号: ${getLineNumber()}   获取到电影名字为 ${fileName} 的图片 base64 字符串长度： ${imgBase64String.length}，去上传数据`);
		}).catch(error => {
			logError(`行号: ${getLineNumber()}错误是：   ${error}\n返回：EVENT.EMPTY，将去找新任务`);
			doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
		});
	}
});
doubanFSM.addBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.FOUND, async () => {
	logInfo(`行号: ${getLineNumber()}    上传成功，再去获取未入库的电影`);
	doubanFSM.setCurrentState(STATE.NEXT_TASK);
	await saveCurrentState(STATE.NEXT_TASK);
	ui.canvasContainer.innerHTML = '';
});
doubanFSM.addBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY, async () => {
	logInfo(`行号: ${getLineNumber()}    上传数据中途失败，再去获取未入库的电影`);
	doubanFSM.setCurrentState(STATE.NEXT_TASK);
	await saveCurrentState(STATE.NEXT_TASK);
	ui.canvasContainer.innerHTML = '';
});


doubanFSM.addStateAction(STATE.NEXT_PAGE_TYPE, async () => {
	log(`行号: ${getLineNumber()}    状态 ${STATE.NEXT_PAGE_TYPE} 的 动作，下一页，\
		如果超过了 25，则跳到下一个 type，从 0 页开始，如果 type 已经是最后一个，则保存为第一个，再次开始轮回`);
	let savedType = await getSavedType();
	let savedPage = await getSavedPage();
	logInfo(`行号: ${getLineNumber()}   当前的 type 是 ${savedType}，page 是 ${savedPage}`);
	let parsedValue = parseInt(savedPage);
	if (isNaN(parsedValue) || parsedValue < 1 || parsedValue > 25) {
		parsedValue = 1;
	} else {
		parsedValue += 1;
		if (isNaN(parsedValue) || parsedValue < 1 || parsedValue > 25) {
			parsedValue = 1;
			// 下一页
			const typeList = ["22", "3", "27", "16", "15", "12", "29", "30", "18", "31"];
			savedType = typeList[(typeList.indexOf(savedType) + 1) % typeList.length]; // 下一个直到 type 已经是最后一个，则又回到第一个，再次开始轮回
			await saveType(savedType);
		}
	}
	await savePage(parsedValue);
	showTypeAndPage();
	logInfo(`行号: ${getLineNumber()}   新的类型号是 ${savedType}，第几 ${parsedValue} 页面`);
	await doubanFSM.executeBeforeTransitionCallback(STATE.NEXT_PAGE_TYPE, EVENT.FOUND);
});
doubanFSM.addBeforeTransitionCallback(STATE.NEXT_PAGE_TYPE, EVENT.FOUND, async () => {
	logInfo(`行号: ${getLineNumber()}    下一页面 或 下一个电影类型，去获取新页面的任务 json}`);
	doubanFSM.setCurrentState(STATE.GET_TASK_JSON);
	await saveCurrentState(STATE.GET_TASK_JSON);
});


doubanFSM.addStateAction(STATE.NEXT_TASK, async () => {
	log(`行号: ${getLineNumber()}    状态 ${STATE.NEXT_TASK} 的 动作，\
		获取保存的 json 字符串，解释 json 出来，\
		找个没有处理过的任务，提取标题，询问自己网站是否已经入库，\
		如果没有入库，去获取内容；如果全都已经入库，就下一页"`);
	const movieArray = await getSavedTaskJsonObject();
	if (undefined == movieArray || 0 < movieArray.length) {
		if (typeof Pinyin === 'undefined') {
			await window.eval_js_file_bind("./script/js/pinyin.js"); // 避免重复加载
			// const slug2 = Pinyin.getPinyin("测试书名号");
			// log(`行号: ${getLineNumber()}   测试书名号  转换拼音别名： ${slug2}`);
		}
		const wordPressAPI = new WordPressAPI(
			'https://sy.lahooo.com',
			'admin',
			'5FIg tLMZ JlYK 8XPW pZVz eUnF'
		);
		for (var movie of movieArray) {
			if (undefined === movie.slug) {
				const slug = Pinyin.getPinyin(movie.title);
				log(`行号: ${getLineNumber()}   ${movie.title}  的拼音转换别名： ${slug}`);
				movie.slug = slug;
			}
			log(`行号: ${getLineNumber()}   验证入库：${movie.url}`);
			if (undefined === movie.did_verify && undefined === movie.did_upload) { // 没有验证过，也没有上传过
				try {
					const result = await wordPressAPI.checkPostExists(movie.slug);
					movie.did_verify = true;
					if (result != movie.title) { // 说明没有入库，是新任务
						const taskContent = getInitialTaskContentFrom(movie, movie.slug); // 从 movie 这条记录里获取要上传的前期资料资料
						await saveTaskContentObject(taskContent);
						log(`行号: ${getLineNumber()}   拿到并保存起步的 taskContent 数据 taskContent ：\n${taskContent}\n返回：EVENT.FOUND`);
						movie.did_upload = true; //上传过一次就行，别死循环
						await saveTaskJsonObject(movieArray); // 保存更新过的 task json
						log(`行号: ${getLineNumber()}   保存将要进入的任务网页：${movie.url}`);
						await saveUrlForState(STATE.UPLOAD_CONTENT, movie.url);
						await saveMovieSlug(movie.slug);
						logInfo(`行号: ${getLineNumber()}   新电影：${movie.title}，去爬取数据然后上传`)
						await doubanFSM.executeBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.FOUND);
						return;
					}
				} catch (error) {
					logError(`行号: ${getLineNumber()}错误是：    入库时出错了：${error}`);
				}
			}
		}
		await saveTaskJsonObject(movieArray); // 保存更新过的 task json	
		await doubanFSM.executeBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.EMPTY);
	} else {
		await doubanFSM.executeBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.EMPTY);
	}
});
// 本状态转入别的状态之前的处理
doubanFSM.addBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.FOUND, async () => {
	log(`行号: ${getLineNumber()}    ${STATE.NEXT_TASK} -- ${EVENT.FOUND} ->  ${STATE.UPLOAD_CONTENT}`);
	await saveCurrentState(STATE.UPLOAD_CONTENT);
	const navigateUrl = await getSavedUrlForState(STATE.UPLOAD_CONTENT);
	log(`行号: ${getLineNumber()}   提取出将要进入的任务网页：${navigateUrl}`);
	await window.navigate_bind(navigateUrl);
});
doubanFSM.addBeforeTransitionCallback(STATE.NEXT_TASK, EVENT.EMPTY, async () => {
	logInfo(`行号: ${getLineNumber()}   这批电影都已经入库，去下一页或下一个类型`);
	log(`行号: ${getLineNumber()}    ${STATE.NEXT_TASK} -- ${EVENT.EMPTY} ->  ${STATE.NEXT_PAGE_TYPE}`);
	doubanFSM.setCurrentState(STATE.NEXT_PAGE_TYPE);
	await saveCurrentState(STATE.NEXT_PAGE_TYPE);
});


doubanFSM.addStateAction(STATE.GET_TASK_JSON, async () => {
	log(`行号: ${getLineNumber()}    状态 ${STATE.GET_TASK_JSON} 的 动作，获取保存的 type 和 page，组成 url，去获取 json 字符串并保存`);
	const savedType = await getSavedType();
	const savedPage = await getSavedPage();
	const startPage = (savedPage - 1) * 10;
	const url = `https://movie.douban.com/j/chart/top_list?type=${savedType}&interval_id=100%3A90&action=&start=${startPage}&limit=10`;
	fetch(url)
		.then(response => {
			if (!response.ok) {
				logError(`行号: ${getLineNumber()}错误是：    获取 ${url} 时回应：${response.status} response = ${response}\n`);
				doubanFSM.executeBeforeTransitionCallback(STATE.GET_TASK_JSON, EVENT.EMPTY).then(_ => { });
			} else {
				return response.text().then(responseText => {
					return saveTaskJsonString(responseText).then(_ => {
						log(`行号: ${getLineNumber()}   ${responseText} 返回：EVENT.FOUND`);
						doubanFSM.executeBeforeTransitionCallback(STATE.GET_TASK_JSON, EVENT.FOUND).then(_ => { });
					});
				});
			}
		})
		.catch(async error => {
			logError(`行号: ${getLineNumber()}错误是：    获取 ${url} 时 ${error}\n返回：EVENT.EMPTY`);
			doubanFSM.executeBeforeTransitionCallback(STATE.GET_TASK_JSON, EVENT.EMPTY).then(_ => { });
		});
});
doubanFSM.addBeforeTransitionCallback(STATE.GET_TASK_JSON, EVENT.FOUND, async () => {
	logInfo(`行号: ${getLineNumber()}    获取到了任务 json，去获取未入库的电影`);
	doubanFSM.setCurrentState(STATE.NEXT_TASK);
	await saveCurrentState(STATE.NEXT_TASK);
});
doubanFSM.addBeforeTransitionCallback(STATE.GET_TASK_JSON, EVENT.EMPTY, async () => {
	logInfo(`行号: ${getLineNumber()}    没有获取到了任务 json，去下一页或下一类型`);
	log(`行号: ${getLineNumber()}    ${STATE.GET_TASK_JSON} -- ${EVENT.EMPTY} ->  ${STATE.NEXT_PAGE_TYPE}`);
	doubanFSM.setCurrentState(STATE.NEXT_PAGE_TYPE);
	await saveCurrentState(STATE.NEXT_PAGE_TYPE);
});

let ui = null;

window.onload = function () {
	const div = document.createElement('div');
	div.id = 'initDiv';
	div.style.padding = '2em';
	div.innerHTML = divHtml;
	document.body.appendChild(div);

	const humanScroller = new HumanScroller();
	humanScroller.start(); // 开始模拟人类滚动网页

	ui = getElements(['initDiv', 'contentText', 'typeValue', 'pageValue', 'restartStateBtn', 'excuteStateActionBtn', 'canvasContainer']);
	ui.restartStateBtn.addEventListener('click', restartState);
	ui.excuteStateActionBtn.addEventListener('click', excuteStateAction);

	getSavedCurrentState().then(savedState => {
		doubanFSM.setCurrentState(savedState);
		log(`当前状态是：${doubanFSM.getCurrentState()}\n\n`);
	});

	showTypeAndPage();
	watchScrollDepth(5, 50, async () => {
		excuteStateAction();
		showTypeAndPage();
	});
}

function showTypeAndPage() {
	getSavedType().then(value => {
		const typeMap = {
			"22": "战争",
			"3": "犯罪",
			"27": "西部",
			"16": "奇幻",
			"15": "冒险",
			"12": "灾难",
			"29": "武侠",
			"30": "古装",
			"18": "运动",
			"31": "黑帮"
		};
		const typeDesc = typeMap[value];  // 比如 3 会输出：犯罪
		getSavedPage().then(value => {
			ui.typeValue.value = "当前种类：  " + typeDesc + "   在第 " + value + " 页面";
		});
	});
	getSavedUploadedMovieSum().then(value => {
		ui.pageValue.value = "已经上传文章数量： " + value;
	});
}

async function restartState() {
	const initState = STATE.GET_TASK_JSON;
	doubanFSM.setCurrentState(initState);
	await saveCurrentState(initState)
	const url = await getSavedUrlForState(initState);
	await window.navigate_bind(url);
}

async function excuteStateAction() {
	getSavedCurrentState().then(savedState => {
		doubanFSM.setCurrentState(savedState);
		log(`行号: ${getLineNumber()}    当前状态是：${doubanFSM.getCurrentState()}\n\n`);
		doubanFSM.executeStateAction().then(savedState => { });
	});
}

function getInitialTaskContentFrom(movie, slugTitle) {
	// 调用 getTaskContentFrom 之前一定要去校验文章没有存在
	const item_cover = movie["cover_url"];
	const item_regions = movie["regions"];
	const item_rank = movie["rank"];
	const item_types = movie["types"];
	const item_id = movie["id"];
	const item_title = movie["title"];
	const item_url = movie["url"];
	const slug = slugTitle;

	function arrayToString(array) {
		// 检查是否为数组
		if (Array.isArray(array)) {
			// 使用 join 方法将数组元素用逗号连接
			array = array.join(',');
		}
		return array;
	}

	const item_rank_int = parseInt(item_rank);
	if (isNaN(item_rank_int)) {
		item_rank_int = 0;
	}
	return {
		guid: item_id,
		title: item_title,
		// content: content,
		// excerpt: excerpt,
		status: 'draft',
		slug: slug,
		menu_order: item_rank_int,  // PHP intval() -> JS parseInt()
		categories: movieCategoryTag(item_types, 'category'),
		tags: movieCategoryTag(item_types, 'tag'),
		// featured_media: 0, // 暂时没有，先占位置
		meta: {
			// sourcecontent: sourcecontent,
			// encontent: encontent,
			// playlink: playlink,
			rank: String(item_rank),      // PHP strval() -> JS String()
			regions: arrayToString(item_regions),
			release_date: movie["release_date"],
			score: movie["score"],
			actors: arrayToString(movie["actors"]),
			// actors_full: infoData.actors_full,
			// ranklist: rating_list,
			// director: infoData["director"],
			// screenwriter: infoData["screenwriter"],
			// release_date_full: infoData["release_date_full"],
			// duration: duration
		}
	};
}

function getOtherTaskContentFromWebPage(initialTaskContent) {
	// 调用 getOtherTaskContentFromWebPage 之前一定要去校验文章没有存在
	// const item_cover = movie["cover_url"];
	// const item_regions = movie["regions"];
	// const item_rank = movie["rank"];
	// const item_types = movie["types"];
	// const item_id = movie["id"];
	// const item_title = movie["title"];
	// const item_url = movie["url"];
	// const slug = slugTitle;
	// 使用可选链和空值判断
	let content = document.querySelector('#link-report-intra .all')?.innerHTML;
	if (!content) {
		content = document.querySelector('span[property="v:summary"]')?.innerHTML;
	}
	const rating = document.querySelectorAll('#interest_sectl .rating_per');
	let rating_list = [];
	rating.forEach(rating_item => {
		// innerText 只会获取可见的文本内容，并且会忽略 HTML 标签，更接近 PHP 代码原有的行为
		rating_list.push(rating_item.innerText);
	});
	rating_list = rating_list.join(','); // 变成字符串
	// 之前已经去校验文章没有存在

	function removeHtmlTagsExceptBr(html) {
		// 去除特殊的中文全角空格 \u3000
		html = html.replace(/\u3000/g, '');
		// 去除前后的空格（包括半角和全角空格）
		html = html.trim();
		// 使用正则表达式匹配所有HTML标签，但保留<br>标签
		// (?!br\s*\/?): 否定预查，不匹配 br 或 br/ 或 br /
		return html.replace(/<(?!br\s*\/?)[^>]+>/g, '');
	}

	function removeAllHtml(html) {
		// 去除特殊的中文全角空格 \u3000
		html = html.replace(/\u3000/g, '');
		// 删除所有HTML标签
		html = html.replace(/<[^>]+>/g, '');
		// 去除前后的空白字符
		html = html.trim();
		return html;
	}

	content = removeHtmlTagsExceptBr(content);		//原文
	const sourcecontent = content;
	//$tran_zh = Translate($tran_en,'en','zh');			//用英文翻译成中文
	const tran_en = content;			//翻译英文
	const tran_zh = content;			//用英文翻译成中文
	const excerpt = removeAllHtml(tran_zh);					//拿到中文后去标签化
	content = tran_zh;
	const encontent = removeAllHtml(tran_en);

	const duration = document.querySelector('meta[property="video:duration"]').getAttribute('content');

	function querySelector_contains(selector, text) {
		const element = Array.from(document.querySelectorAll(selector))
			.find(element => element.textContent.includes(text));
		const nextSpan = element?.nextElementSibling?.querySelector('.attrs') || element?.nextElementSibling;
		return nextSpan?.innerText || '';
	}
	const infoData = {
		director: querySelector_contains('#info span.pl', '导演'),
		screenwriter: querySelector_contains('#info span.pl', '编剧'),
		actors_full: querySelector_contains('#info span.pl', '主演'),
		release_date_full: Array.from(document.querySelectorAll('#info span[property="v:initialReleaseDate"]'))
			.map(element => element.innerText)
			.join(' / ')
	};

	let playlink = '';
	const bsli = document.querySelectorAll('ul.bs li');
	if (bsli.length > 0) {
		bsli.forEach(li => {
			const anchor = li.querySelector('a');
			if (anchor) {
				const text = anchor.getAttribute('data-cn') || '';
				const link = anchor.getAttribute('href') || '';
				playlink += `${text}:${link}\r\n`;
			}
		});
	}

	// function arrayToString(array) {
	// 	// 检查是否为数组
	// 	if (Array.isArray(array)) {
	// 		// 使用 join 方法将数组元素用逗号连接
	// 		array = array.join(',');
	// 	}
	// 	return array;
	// }

	// const item_rank_int = parseInt(item_rank);
	// if (isNaN(item_rank_int)) {
	// 	item_rank_int = 0;
	// }
	// return {
	// 	guid: item_id,
	// 	title: item_title,
	initialTaskContent.content = content;
	initialTaskContent.excerpt = excerpt;
	// status: 'draft',
	// slug: slug,
	// menu_order: item_rank_int,  // PHP intval() -> JS parseInt()
	// categories: movieCategoryTag(item_types, 'category'),
	// tags: movieCategoryTag(item_types, 'tag'),
	// featured_media: 0, // 暂时没有，先占位置
	// meta: {
	initialTaskContent.meta.sourcecontent = sourcecontent;
	initialTaskContent.meta.encontent = encontent;
	initialTaskContent.meta.playlink = playlink;
	// rank: String(item_rank),      // PHP strval() -> JS String()
	// regions: arrayToString(item_regions),
	// release_date: movie["release_date"],
	// score: movie["score"],
	// actors: arrayToString(movie["actors"]),
	initialTaskContent.meta.actors_full = infoData.actors_full;
	initialTaskContent.meta.ranklist = rating_list;
	initialTaskContent.meta.director = infoData["director"];
	initialTaskContent.meta.screenwriter = infoData["screenwriter"];
	initialTaskContent.meta.release_date_full = infoData["release_date_full"];
	initialTaskContent.meta.duration = duration;
	// 		}
	// };
	return initialTaskContent;
}

function movieCategoryTag(category, type = 'category') {
	// 创建类别和标签的映射对象
	const categoryMap = {
		'传记': { categoryId: 57, tagId: 99 },
		'儿童': { categoryId: 58, tagId: 98 },
		'冒险': { categoryId: 59, tagId: 105 },
		'剧情': { categoryId: 60, tagId: 29 },
		'动作': { categoryId: 61, tagId: 85 },
		'动画': { categoryId: 62, tagId: 88 },
		'历史': { categoryId: 63, tagId: 100 },
		'古装': { categoryId: 64, tagId: 108 },
		'喜剧': { categoryId: 65, tagId: 84 },
		'奇幻': { categoryId: 66, tagId: 104 },
		'家庭': { categoryId: 67, tagId: 97 },
		'恐怖': { categoryId: 68, tagId: 91 },
		'悬疑': { categoryId: 69, tagId: 89 },
		'**': { categoryId: 70, tagId: 94 },
		'惊悚': { categoryId: 71, tagId: 90 },
		'战争': { categoryId: 72, tagId: 101 },
		'歌舞': { categoryId: 73, tagId: 96 },
		'武侠': { categoryId: 74, tagId: 107 },
		'灾难': { categoryId: 75, tagId: 106 },
		'爱情': { categoryId: 76, tagId: 86 },
		'犯罪': { categoryId: 77, tagId: 102 },
		'短片': { categoryId: 78, tagId: 93 },
		'科幻': { categoryId: 79, tagId: 87 },
		'纪录片': { categoryId: 80, tagId: 92 },
		'西部': { categoryId: 81, tagId: 103 },
		'运动': { categoryId: 82, tagId: 109 },
		'音乐': { categoryId: 83, tagId: 95 }
	};

	const categoryIds = [];
	const tagIds = [];

	// 遍历类别数组
	category.forEach(categoryName => {
		if (categoryMap[categoryName]) {
			categoryIds.push(categoryMap[categoryName].categoryId);
			tagIds.push(categoryMap[categoryName].tagId);
		}
	});

	// 根据类型返回相应的数组
	return type === 'category' ? categoryIds : tagIds;
}

// 使用 URL 对象（更安全的方式）
function getFileExtension(url) {
	const pathname = new URL(url).pathname;
	const extension = pathname.split('.').pop();
	const result = extension.toLowerCase();
	log(`行号: ${getLineNumber()}    获取网址的文件后缀 ${url} 为 ${result}`);
	return result;
}

function getTaskImage(slug) {
	log(`行号: ${getLineNumber()}   准备获取图片，渲染到 canvas 上进行裁剪缩放，上传后得到 mediaId 给 taskContent，再上传整个数据taskContent`);
	// #mainpic a img 能成功把图片变成 base64，渲染到 canvas 上进行裁剪缩放，上传后得到 mediaId
	var selector = '#mainpic a img';
	var targetElement = document.querySelector(selector);
	if (targetElement && targetElement.tagName === 'IMG') {
		var imgAttributeSrc = targetElement.getAttribute('src');
		var imgFileName = slug + "." + getFileExtension(imgAttributeSrc);
		// 返回一个 Promise，确保图片加载完成
		return new Promise((resolve, reject) => { // Promise 的 then 回调函数只能接收一个值，多个值的话将它们包装在一个对象或数组中
			if (targetElement.complete) {
				// 如果图片已经加载完成，直接进行转换
				imgToBase64(targetElement)
					.then(base64String => {
						imageToBase64Promise(imgFileName, base64String);
						log(`行号: ${getLineNumber()}    获取图片 ${imgFileName} 成功`);
						resolve({ fileName: imgFileName, imgBase64String: base64String }); // 将它们包装在一个对象或数组中
					})
					.catch(err => {
						logError(`行号: ${getLineNumber()}错误是：    获取图片 ${imgFileName} 失败，因为： ${err}`);
						reject(err);
					}
					);
			} else {
				// 如果图片未加载完成，等待 load 事件
				targetElement.onload = () => {
					imgToBase64(targetElement)
						.then(base64String => {
							imageToBase64Promise(imgFileName, base64String);
							log(`行号: ${getLineNumber()}    获取图片 ${imgFileName} 成功`);
							resolve({ fileName: imgFileName, imgBase64String: base64String }); // 将它们包装在一个对象或数组中
						})
						.catch(err => {
							logError(`行号: ${getLineNumber()}错误是：    获取图片 ${imgFileName} 失败，因为： ${err}`);
							reject(err);
						}
						);
				};

				// 处理加载失败的情况
				targetElement.onerror = () => {
					logError(`行号: ${getLineNumber()}错误是：    加载图片 ${imgFileName} 失败，原因未知`);
					reject(new Error('图片加载失败'));
				};
			}
		});
	} else {
		logInfo(`行号: ${getLineNumber()}    没有封面图的元素，应该是页面不存在或不对，去获取未入库的电影`);
		return new Promise((resolve, reject) => {
			reject(new Error('寻找 #mainpic a img 对应的 img 元素 失败'));
		});
	}
}

function imageToBase64Promise(imgFileName, base64String) {
	try {
		var img = new Image();
		img.onload = function () {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			canvas.width = img.naturalWidth;
			canvas.height = img.naturalHeight;
			ctx.drawImage(img, 0, 0);
			ui.canvasContainer.innerHTML = '';
			ui.canvasContainer.appendChild(canvas);
			// 在图片显示后立即进行裁剪和缩放
			try {
				log(`行号: ${getLineNumber()}    尝试图片裁剪和缩放并上传`);
				cropAndResizeCanvasImageAndUpload(imgFileName).then(_ => { }); // 上传保存处理后的图片
			} catch (error) {
				logError(`行号: ${getLineNumber()}错误是：    裁剪图片失败: ${error.messag}`);
				doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
			}
		};
		// 设置图片源为 base64String 字符串
		img.src = base64String;
	} catch (error) {
		logError(`行号: ${getLineNumber()}错误是：    获取图片数据失败: ${error.message}`);
		ui.canvasContainer.innerHTML = '';
		doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
	}
}

function imgToBase64(imgElement) { // 这个快，1秒
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = 'Anonymous';
		img.onload = function () {
			const canvas = document.createElement('canvas');
			canvas.width = img.width;
			canvas.height = img.height;

			const ctx = canvas.getContext('2d');
			ctx.drawImage(img, 0, 0, img.width, img.height);

			const imgSrc = imgElement.src;
			const mimeType = getMimeType(imgSrc);
			resolve(canvas.toDataURL(mimeType)); // 以base64字符串导出
		};
		img.onerror = reject;
		img.src = imgElement.src;
	});
}

function getMimeType(imgSrc) {
	// 获取图片类型
	let mimeType = 'image/png'; // 默认类型
	// '不支持的文件格式，请上传 JPG、PNG 或 WEBP 图片。';
	if (imgSrc.endsWith('.jpg') || imgSrc.endsWith('.jpeg')) {
		mimeType = 'image/jpg';
	} else if (imgSrc.endsWith('.webp')) {
		mimeType = 'image/webp';
	} else if (imgSrc.endsWith('.gif')) {
		mimeType = 'image/gif';
	}
	return mimeType;
}

async function cropAndResizeCanvasImageAndUpload(imgFileName) {
	// 获取现有的 canvas
	const existingCanvas = ui.canvasContainer.querySelector('canvas');
	if (!existingCanvas) {
		throw new Error('Canvas not found');
	}

	// 获取原始尺寸
	const width = existingCanvas.width;
	const height = existingCanvas.height;

	// 裁切后的尺寸
	const newWidth = width - 2;  // 裁切1像素
	const newHeight = height - 2; // 裁切1像素

	// 创建裁切用的 canvas
	const cropCanvas = document.createElement('canvas');
	cropCanvas.width = newWidth;
	cropCanvas.height = newHeight;
	const cropCtx = cropCanvas.getContext('2d');

	// 从原始 canvas 裁切图像，去除四边1像素
	cropCtx.drawImage(existingCanvas,
		1, 1, newWidth, newHeight,  // 源图像裁切区域
		0, 0, newWidth, newHeight   // 目标区域
	);

	// 创建最终缩放用的 canvas
	const finalCanvas = document.createElement('canvas');
	finalCanvas.width = 270;
	finalCanvas.height = 400;
	const finalCtx = finalCanvas.getContext('2d');

	// 缩放图像
	finalCtx.drawImage(cropCanvas,
		0, 0, newWidth, newHeight,  // 源图像区域
		0, 0, 270, 400             // 目标区域
	);

	// 清除原有的 canvas
	ui.canvasContainer.innerHTML = '';
	// 显示处理后的 canvas
	ui.canvasContainer.appendChild(finalCanvas);

	finalCanvas.toBlob(async (blob) => {
		try {
			const mimeType = getMimeType(imgFileName);
			const mediaId = await uploadImageToWordPress({
				siteUrl: 'https://sy.lahooo.com',
				username: 'admin',
				password: '5FIg tLMZ JlYK 8XPW pZVz eUnF',
				blob: blob,
				filename: imgFileName,
				mimeType: mimeType
			});
			logInfo(`行号: ${getLineNumber()}    上传图片成功，收到 media id：${mediaId}`);
			const initialTaskContent = await getSavedTaskContentObject();
			await getOtherTaskContentFromWebPage(initialTaskContent); // 抓取网页上的数据
			initialTaskContent.featured_media = mediaId; // 保存,上传
			await uploadTaskContentToWordPress({
				siteUrl: 'https://sy.lahooo.com',
				username: 'admin',
				password: '5FIg tLMZ JlYK 8XPW pZVz eUnF',
				post: initialTaskContent
			});
		} catch (error) {
			logError(`行号: ${getLineNumber()}错误是：    上传图片和内容数据失败：${error}`);
			doubanFSM.executeBeforeTransitionCallback(STATE.UPLOAD_CONTENT, EVENT.EMPTY).then(_ => { });
		}
	});
	// 返回处理后的 base64 数据
	// return finalCanvas.toDataURL();
}

async function saveUploadedMovieSum(uploadedMovieSum) {
	await saveKeyValue("movie.uploaded.sum", "" + uploadedMovieSum); // 注意 value 给字符串，否则不会保存成功
}

async function getSavedUploadedMovieSum() {
	const defaultValue = 0;
	const result = await getValueWithDefault("movie.uploaded.sum", defaultValue, (value) => {
		const parsedValue = parseInt(value);
		if (isNaN(parsedValue) || parsedValue < 0) {
			return 0;
		}
		return parsedValue;
	});
	return result;
}

async function getSavedTaskContentObject() {
	const result = await getSavedTaskContentString();
	return JSON.parse(result);;
}

async function saveTaskContentObject(taskContentObject) {
	const taskContentString = JSON.stringify(taskContentObject);
	await saveKeyValue("movie.taskContent", taskContentString);
}

async function getSavedTaskContentString() {
	const defaultValue = "{}"; // 是一个对象
	const result = await getValueWithDefault("movie.taskContent", defaultValue, (value) => {
		if (value.length <= 2) {
			return defaultValue;
		} else {
			return value;
		}
	});
	return result;
}

async function saveTaskContentString(taskContentString) {
	await saveKeyValue("movie.taskContent", taskContentString);
}

async function saveMovieSlug(slug) {
	await saveKeyValue("movie.slug", slug);
}

async function getSavedMovieSlug() {
	const defaultValue = "";
	const result = await getValueWithDefault("movie.slug", defaultValue, null);
	return result;
}

async function saveTaskJsonString(taskJsonString) {
	await saveKeyValue("task_json", taskJsonString);
}

async function getSavedTaskJsonString() {
	const defaultValue = "[]"; // 是一个数组
	const result = await getValueWithDefault("task_json", defaultValue, (value) => {
		if (value.length <= 2) {
			return defaultValue;
		} else {
			return value;
		}
	});
	return result;
}

async function saveTaskJsonObject(taskJsonObject) {
	await saveKeyValue("task_json", JSON.stringify(taskJsonObject));
}

async function getSavedTaskJsonObject() {
	const result = await getSavedTaskJsonString();
	return JSON.parse(result);
}

async function saveUrlForState(state, url) {
	await saveKeyValue(`${state}`, url);
}

async function getSavedUrlForState(state) {
	const defaultValue = "https://movie.douban.com";
	const result = await getValueWithDefault(`${state}`, defaultValue, null);
	return result;
}

async function saveType(typeValue) {
	await saveKeyValue("param_type", "" + typeValue); // 注意 value 给字符串，否则不会保存成功
}

async function getSavedType() {
	const defaultValue = "22";
	const result = await getValueWithDefault("param_type", defaultValue, (value) => {
		const resultList = ["22", "3", "27", "16", "15", "12", "29", "30", "18", "31"];
		return resultList.includes(value) ? value : defaultValue;
	}).then(value => {
		return value;
	});
	return result;
}

async function savePage(pageValue) {
	await saveKeyValue("param_page", "" + pageValue); // 注意 value 给字符串，否则不会保存成功
}

async function getSavedPage() {
	const defaultValue = 0;
	const result = await getValueWithDefault("param_page", defaultValue, (value) => {
		const parsedValue = parseInt(value);
		if (isNaN(parsedValue) || parsedValue < 1 || parsedValue > 25) {
			return 1;
		}
		return parsedValue;
	});
	return result;
}

async function saveCurrentState(currentState) {
	await saveKeyValue("current_state", currentState);
}

async function getSavedCurrentState() {
	const defaultValue = STATE.GET_TASK_JSON;
	const result = await getValueWithDefault("current_state", defaultValue, (value) => {
		const resultList = [STATE.GET_TASK_JSON, STATE.NEXT_TASK, STATE.NEXT_PAGE_TYPE, STATE.GET_CONTENT, STATE.UPLOAD_CONTENT,];
		return resultList.includes(value) ? value : defaultValue;
	});
	return result;
}

async function saveKeyValue(key_str, value_str) {
	await window.set_key_value_bind({ key: key_str, value: value_str }).catch(error => { // 先处理失败
		logError(`行号: ${getLineNumber()}，错误是：    saveKeyValue 保存失败\n  {key: "${key_str}", value: "${value_str}"}\n  因为：${error}`);
	}).then(getResult => {
		if (getResult?.err_msg) {
			logError(`行号: ${getLineNumber()}，错误是：    保存失败\n  {key: "${key_str}", value: "${value_str}"}\n  因为：${getResult?.err_msg}`);
		} else {
			if (undefined === key_str) {
				logError(`行号: ${getLineNumber()}，错误是：    key_str 是 undefined`);
			}
			const first100Str = value_str.length <= 100 ? value_str : (value_str.substring(0, 100) + '...');
			log(`行号: ${getLineNumber()}    saveKeyValue 保存 ${key_str} 的值成功 ${first100Str}`);
		}
	});
}

async function getValueWithDefault(key, defaultValue, validateFn) {
	return await window.get_value_by_key_bind(key).catch(error => { // 先处理失败
		logError(`行号: ${getLineNumber()}，错误是：    getValueWithDefault 获取 ${key} 失败，使用默认值 ${defaultValue}，因为：${error}`);
		return defaultValue;
	}).then(getResult => {
		let result = defaultValue;
		if (getResult?.err_msg) {
			logError(`行号: ${getLineNumber()}，错误是：    getValueWithDefault 获取 ${key} 失败，使用默认值 ${defaultValue}，因为：${getResult?.err_msg}`);
		} else if (undefined !== getResult?.value) {
			result = validateFn ? validateFn(getResult.value) : getResult.value;
		}
		log(`行号: ${getLineNumber()}    getValueWithDefault 获取 ${key} 成功：${result}`);
		return result;
	});
}

function getElements(ids) {
	var result = {};
	for (var i = 0; i < ids.length; i++) {
		var id = ids[i];
		result[id] = document.getElementById(id);
	}
	return result;
}

// 创建延时函数
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function logInfo(info) {
	showInContentText(info);
	console.info(`bbcrawl: 信息，${info}`);
}

function logError(err) {
	showInContentText(err);
	console.error(`bbcrawl: 出错了，${err}`);
}

function log(log) {
	// 不重要的不要显示 ui.contentText.value = ui.contentText.value + "\n" + log;
	// ui.contentText.scrollTop = textarea.scrollHeight;
	console.log(`bbcrawl: ${log}`);
}

function showInContentText(msg) {
	ui.contentText.value = ui.contentText.value + "\n" + msg;
	ui.contentText.scrollTop = ui.contentText.scrollHeight;
}

// 获取行号，不出错也能用
function getLineNumber() {
	try {
		throw new Error();
	} catch (e) {
		const stack = e.stack.split('\n');
		// 不同浏览器的堆栈格式可能不同，我们做更健壮的匹配
		for (let i = 1; i < stack.length; i++) {
			const line = stack[i].match(/(\d+):\d+\)?$/);
			if (line) return line[1];
		}
		return '';
	}
}