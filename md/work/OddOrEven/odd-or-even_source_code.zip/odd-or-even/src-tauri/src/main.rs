// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tokio;

mod ethers_funcs;

#[macro_use]
extern crate lazy_static;

#[tokio::main]
async fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            /*放在 tauri::Builder::default().invoke_handler(tauri::generate_handler![] 里面的函数，
            tauri自动赋值一个参数为 app: tauri::AppHandle
            */
            ethers_funcs::get_gas_price,
            ethers_funcs::create_random_wallet,
            ethers_funcs::get_wallet_balance,
            ethers_funcs::get_contract_balance,
            ethers_funcs::get_deploy_contract_estimate_fee,
            ethers_funcs::deploy_contract,
            ethers_funcs::transform_value_for_units,
            ethers_funcs::get_contract_version,
            ethers_funcs::local_keccak256_odd_secret_string,
            ethers_funcs::call_contract,
            ethers_funcs::get_latest_gambles,
            ethers_funcs::get_my_latest_gambles,
            ethers_funcs::batch_get_contract_gambles,
            ethers_funcs::batch_get_contract_my_gambles,
            ethers_funcs::contract_keccak256_odd_secret_string,
            ethers_funcs::subscribe_event,
            ethers_funcs::unsubscribe_event,
            get_contract_source_code,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

// 请注意，当使用 snake_case 在 Rust 中声明参数时，参数会转换为 JavaScript 的 camelCase。
// #[tauri::command(rename_all = "snake_case")]  在 JavaScript 中使用 snake_case

#[tauri::command]
fn get_contract_source_code() -> String {
    String::from(include_str!("../../asset/solidity/odd_or_even.sol"))
}
