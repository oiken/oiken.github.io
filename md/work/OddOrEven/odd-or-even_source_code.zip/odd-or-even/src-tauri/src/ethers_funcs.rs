use ethers::abi;
use ethers::abi::Abi;
use ethers::abi::Token;
use ethers::contract::ContractFactory;
use ethers::middleware::SignerMiddleware;
use ethers::prelude::*;
use ethers::providers::Middleware;
use ethers::providers::Provider;
use ethers::providers::StreamExt;
use ethers::signers::LocalWallet;
use ethers::solc::Solc;
use ethers::utils::{self, keccak256};
use rand::thread_rng;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::convert::TryFrom;
use std::error::Error;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use std::str::FromStr;
use std::sync::Arc;
use std::sync::Mutex;
use tauri::Manager;

static BODD_OR_EVEN_VERSION: &str = "0.1.0";

// 使用编译好的 ABI 和 bytecode 文件
abigen!(
    OddOrEven,
    "../asset/solidity/odd_or_even.json",
    event_derives(serde::Deserialize, serde::Serialize)
);

lazy_static! {
    static ref SUBSCRIBE_EVENT_CONTRACT_ADDRESS: Arc<Mutex<String>> =
        Arc::new(Mutex::new("".to_string()));
}

#[tauri::command]
pub async fn unsubscribe_event(contract_address: String) {
    let current_contract = _get_subscribe_event_contract_address();
    if contract_address.eq(current_contract.as_str()) {
        _set_subscribe_event_contract_address("".to_string());
        println!("停止监听合约{contract_address}的事件！");
    }
}

// define the payload struct
#[derive(Clone, Serialize, Deserialize)]
struct Payload {
    contract_address_prefix: String,
    gamble_id: String,
    message: String,
}

#[tauri::command]
pub async fn subscribe_event(
    app: tauri::AppHandle,
    /* 在 JavaScript 中调用 Rust 后端的 subscribe_event 函数时，你不需要手动传递 AppHandle。
    Tauri 框架会自动处理这部分，确保在 Rust 函数中可以直接使用 AppHandle 参数。 */
    rpc_url: String,
    contract_address: String,
) -> String {
    return match _subscribe_event(app, rpc_url, contract_address).await {
        Ok(_) => "".to_string(),
        Err(error) => {
            println!("subscribe_event 出错");
            _parse_ethers_error(error)
        }
    };
}

async fn _subscribe_event(
    app: tauri::AppHandle,
    rpc_url: String,
    contract_address: String,
) -> Result<(), Box<dyn Error>> {
    let current_contract_address = _get_subscribe_event_contract_address();
    if contract_address.len() == 0 {
        Err("订阅事件失败，因合约地址为空".into())
    } else if contract_address.eq(current_contract_address.as_str()) {
        Err("不需要重复监听合约的事件".into())
    } else {
        let websocket_rpc_url: String;
        if rpc_url.starts_with("http://") {
            websocket_rpc_url = rpc_url.replace("http://", "ws://");
        } else if rpc_url.starts_with("https://") {
            websocket_rpc_url = rpc_url.replace("https://", "ws://");
        } else {
            websocket_rpc_url = rpc_url;
        }
        // 如果有可能用这个 websocket 比骄好，
        let provider = Provider::<Ws>::connect(websocket_rpc_url).await?;
        // let provider = Provider::try_from(websocket_rpc_url.as_str())?;
        let arc_provider = Arc::new(provider);
        // 设置为新的合约地址，其它已经在运行的侦听 while 循环会拿它自己的合约地址比较，不一致则会退出
        _set_subscribe_event_contract_address(contract_address.clone());
        let contract_address_address: Address = contract_address.parse()?;
        let contract_provider = OddOrEven::new(contract_address_address, arc_provider.clone());
        let events = contract_provider.events();
        let mut events_stream = events.stream().await?;
        println!("开始监听合约{contract_address}的事件...");
        let contract_address_prefix = format!("{}", contract_address).as_str()[..6].to_string(); // 前缀 6 个，变成字符串时会中间放置省略号 ...

        while let Some(Ok(event)) = events_stream.next().await {
            // 获取当前最新的侦听事件的，如果不一致，说明不用再侦听这个了，退出这个 while 循环
            let current_contract_address = _get_subscribe_event_contract_address();
            if !contract_address.eq(current_contract_address.as_str()) {
                // 不一致，退出此 while
                break;
            }
            // 这个 events_stream.next() 需要导入 use ethers::providers::StreamExt;
            println!("\n监听到事件：{event:?}，解释出内容为：");
            let event_desc: String;
            let gamble_id: String;
            match event {
                odd_or_even::OddOrEvenEvents::GambleStartedFilter(
                    odd_or_even::GambleStartedFilter {
                        index_of_gamble,
                        starter,
                        bet,
                    },
                ) => {
                    event_desc = format!(
                        "新开局：编号 {}，金额 {}，开局者 {}",
                        index_of_gamble + 1,
                        _get_shorter_string_of_balance(bet),
                        starter,
                    );
                    gamble_id = format!("{}", index_of_gamble);
                    app.emit_all(
                        "EventGambleStartedFilter",
                        Payload {
                            contract_address_prefix: contract_address_prefix.to_string(),
                            gamble_id: gamble_id,
                            message: event_desc.clone(),
                        },
                    )?;
                }
                odd_or_even::OddOrEvenEvents::GambleAgainstedFilter(
                    odd_or_even::GambleAgainstedFilter {
                        index_of_gamble,
                        starter,
                        bet_amount,
                        againster,
                        is_odd,
                    },
                ) => {
                    event_desc = format!(
                        "有人对局：编号 {}，金额 {}，对局者 {}，选择 {}，开局者 {}，",
                        index_of_gamble + 1,
                        _get_shorter_string_of_balance(bet_amount),
                        againster,
                        if is_odd { "单数" } else { "双数" },
                        starter,
                    );
                    gamble_id = format!("{}", index_of_gamble);
                    app.emit_all(
                        "EventGambleAgainstedFilter",
                        Payload {
                            contract_address_prefix: contract_address_prefix.to_string(),
                            gamble_id: gamble_id,
                            message: event_desc.clone(),
                        },
                    )?;
                }
                odd_or_even::OddOrEvenEvents::GambleRevealedFilter(
                    odd_or_even::GambleRevealedFilter {
                        index_of_gamble,
                        winner,
                        bet_amount,
                    },
                ) => {
                    event_desc = format!(
                        "开盘啦：编号 {}，金额总额 {}， 赢家 {}，",
                        index_of_gamble + 1,
                        _get_shorter_string_of_balance(bet_amount),
                        winner,
                    );
                    gamble_id = format!("{}", index_of_gamble);
                    app.emit_all(
                        "EventGambleRevealedFilter",
                        Payload {
                            contract_address_prefix: contract_address_prefix.to_string(),
                            gamble_id: gamble_id,
                            message: event_desc.clone(),
                        },
                    )?;
                }
                odd_or_even::OddOrEvenEvents::GambleWithdrawedFilter(
                    odd_or_even::GambleWithdrawedFilter {
                        index_of_gamble,
                        winner,
                        bet_amount,
                    },
                ) => {
                    event_desc = format!(
                        "提取金额：编号 {}，金额总额 {}, 赢家 {}",
                        index_of_gamble + 1,
                        _get_shorter_string_of_balance(bet_amount),
                        winner,
                    );
                    gamble_id = format!("{}", index_of_gamble);
                    app.emit_all(
                        "EventGambleWithdrawedFilter",
                        Payload {
                            contract_address_prefix: contract_address_prefix.to_string(),
                            gamble_id: gamble_id,
                            message: event_desc.clone(),
                        },
                    )?;
                }
            }
            println!("{}", event_desc);
        }
        Ok(())
    }
}

fn _get_subscribe_event_contract_address() -> String {
    let value = SUBSCRIBE_EVENT_CONTRACT_ADDRESS.lock().unwrap();
    value.clone()
}

fn _set_subscribe_event_contract_address(new_value: String) {
    let mut value = SUBSCRIBE_EVENT_CONTRACT_ADDRESS.lock().unwrap();
    *value = new_value;
}

#[tauri::command]
pub async fn contract_keccak256_odd_secret_string(
    rpc_url: String,
    contract_address: String,
    is_odd: bool,
    secret: String,
) -> (String, String) {
    return match _contract_keccak256_odd_secret_string(rpc_url, contract_address, is_odd, secret)
        .await
    {
        Ok(str) => (str, "".to_string()),
        Err(error) => {
            println!("contract_keccak256_odd_secret_string 出错");
            ("".to_string(), _parse_ethers_error(error))
        }
    };
}

async fn _contract_keccak256_odd_secret_string(
    rpc_url: String,
    contract_address: String,
    is_odd: bool,
    secret: String,
) -> Result<String, Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url.as_str())?;
    let arc_provider = Arc::new(provider);
    let contract_address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(contract_address, arc_provider);
    let result = contract
        .get_keccak_256(is_odd, secret.clone())
        .call()
        .await?;
    let result_str = hex::encode(result);
    // 测试是否和自己实现的结果一样
    let local_kecak256_string = local_keccak256_odd_secret_string(is_odd, secret);
    assert!(
        result_str.eq_ignore_ascii_case(&local_kecak256_string),
        "严重错误：solidity上实现的和自己rust实现的结果不一样"
    );
    Ok(result_str)
}

#[tauri::command]
pub async fn get_latest_gambles(
    rpc_url: String,
    contract_address: String,
    count: u64,
) -> (Vec<ReadableGamble>, u64, String) {
    return match _get_latest_gambles(rpc_url, contract_address, count).await {
        Ok((gambles, gambles_amount)) => (gambles, gambles_amount, "".to_string()),
        Err(error) => {
            println!("get_latest_gambles 出错");
            (Vec::new(), 0_u64, _parse_ethers_error(error))
        }
    };
}

async fn _get_latest_gambles(
    rpc_url: String,
    contract_address: String,
    count: u64,
) -> Result<(Vec<ReadableGamble>, u64), Box<dyn Error>> {
    let provider = Provider::<Http>::try_from(rpc_url.as_str())?;
    let provider = Arc::new(provider);
    let address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(address, provider);
    let gamble_count = U256::from(count);
    let (gambles_result, gamble_amount) = contract.get_latest_gambles(gamble_count).call().await?;
    let mut gambles: Vec<ReadableGamble> = vec![];
    for gamble in gambles_result {
        gambles.push(gamble.into());
    }
    Ok((gambles, gamble_amount.as_u64()))
}

#[tauri::command]
pub async fn get_my_latest_gambles(
    rpc_url: String,
    contract_address: String,
    count: u64,
    wallet_address: String,
) -> (Vec<ReadableGamble>, u64, String) {
    return match _get_my_latest_gambles(rpc_url, contract_address, count, wallet_address).await {
        Ok((gambles, gambles_amount)) => (gambles, gambles_amount, "".to_string()),
        Err(error) => {
            println!("get_my_latest_gambles 出错");
            (Vec::new(), 0_u64, _parse_ethers_error(error))
        }
    };
}

async fn _get_my_latest_gambles(
    rpc_url: String,
    contract_address: String,
    count: u64,
    wallet_address: String,
) -> Result<(Vec<ReadableGamble>, u64), Box<dyn Error>> {
    let provider = Provider::<Http>::try_from(rpc_url.as_str())?;
    let provider = Arc::new(provider);
    let address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(address, provider);
    let count = U256::from(count);
    let wallet_address: Address = wallet_address.parse()?;
    let (gambles_result, gambles_amount) = contract
        .get_my_latest_gambles(wallet_address, count)
        .call()
        .await?;
    let mut gambles: Vec<ReadableGamble> = vec![];
    for gamble in gambles_result {
        gambles.push(gamble.into());
    }
    Ok((gambles, gambles_amount.as_u64()))
}

#[tauri::command]
pub async fn batch_get_contract_gambles(
    rpc_url: String,
    contract_address: String,
    from_index_of_gamble: u64,
    gamble_count: u64,
) -> (Vec<ReadableGamble>, u64, String) {
    return match _batch_get_contract_gambles(
        rpc_url,
        contract_address,
        from_index_of_gamble,
        gamble_count,
    )
    .await
    {
        Ok((gambles, amount)) => (gambles, amount, "".to_string()),
        Err(error) => {
            println!("batch_get_contract_gambles 出错");
            (Vec::new(), 0_u64, _parse_ethers_error(error))
        }
    };
}

async fn _batch_get_contract_gambles(
    rpc_url: String,
    contract_address: String,
    from_index_of_gamble: u64,
    gamble_count: u64,
) -> Result<(Vec<ReadableGamble>, u64), Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url.as_str())?;
    let arc_provider = Arc::new(provider);
    let contract_address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(contract_address, arc_provider);
    let from_index = U256::from(from_index_of_gamble);
    let count = U256::from(gamble_count);
    let (gambles_result, amount) = contract.batch_get_gambles(from_index, count).call().await?;
    let mut gambles: Vec<ReadableGamble> = vec![];
    for gamble in gambles_result {
        gambles.push(gamble.into());
    }
    Ok((gambles, amount.as_u64()))
}

#[tauri::command]
pub async fn batch_get_contract_my_gambles(
    rpc_url: String,
    contract_address: String,
    wallet_address: String,
    from_index_of_gamble: u64,
    gamble_count: u64,
) -> (Vec<ReadableGamble>, u64, String) {
    return match _batch_get_contract_my_gambles(
        rpc_url,
        contract_address,
        wallet_address,
        from_index_of_gamble,
        gamble_count,
    )
    .await
    {
        Ok((gambles, amount)) => (gambles, amount, "".to_string()),
        Err(error) => {
            println!("batch_get_contract_my_gambles 出错");
            (Vec::new(), 0_u64, _parse_ethers_error(error))
        }
    };
}

async fn _batch_get_contract_my_gambles(
    rpc_url: String,
    contract_address: String,
    wallet_address: String,
    from_index_of_gamble: u64,
    gamble_count: u64,
) -> Result<(Vec<ReadableGamble>, u64), Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url.as_str())?;
    let arc_provider = Arc::new(provider);
    let contract_address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(contract_address, arc_provider);
    let wallet_address: Address = wallet_address.parse()?;
    let from_index = U256::from(from_index_of_gamble);
    let count = U256::from(gamble_count);
    let (gambles_result, gambles_amount) = contract
        .batch_get_my_gambles(wallet_address, from_index, count)
        .call()
        .await?;
    let mut gambles: Vec<ReadableGamble> = vec![];
    for gamble in gambles_result {
        gambles.push(gamble.into());
    }
    Ok((gambles, gambles_amount.as_u64()))
}

fn _get_contract(
    rpc_url: String,
    contract_address: String,
) -> Result<OddOrEven<Provider<Http>>, Box<dyn Error>> {
    let provider = Provider::<Http>::try_from(rpc_url.as_str())?;
    let provider = Arc::new(provider);
    let address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(address, provider);
    Ok(contract)
}

async fn _get_contract_with_wallet(
    rpc_url: String,
    contract_address: String,
    wallet_private_key: String,
) -> Result<
    (
        Address,
        OddOrEven<SignerMiddleware<Provider<Http>, LocalWallet>>,
    ),
    Box<dyn Error>,
> {
    let wallet = LocalWallet::from_str(&wallet_private_key)?;
    let wallet_address = wallet.address();
    let contract_address: Address = contract_address.parse()?;
    let provider = Provider::try_from(rpc_url)?;
    let chain_id = provider.get_chainid().await?.as_u64();
    let singed_provider = SignerMiddleware::new(provider, wallet.clone().with_chain_id(chain_id));
    let arc_signed_provider = Arc::new(singed_provider);
    let contract = OddOrEven::new(contract_address, arc_signed_provider.clone());
    Ok((wallet_address, contract))
}

#[derive(Debug, Serialize, Deserialize)]
pub struct OddOrEvenParamStart {
    bet_wei: String,
    is_odd: bool,
    secret: String,
    betting_time: u64,
    reveal_time: u64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct OddOrEvenParamAgainst {
    gamble_id: u64,
    bet_wei: String,
    is_odd: bool,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct OddOrEvenParamReveal {
    gamble_id: u64,
    is_odd: bool,
    secret: String,
    keccak_256_result: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub enum OddOrEvenParam {
    Start { param: OddOrEvenParamStart },
    Against { param: OddOrEvenParamAgainst },
    Reveal { param: OddOrEvenParamReveal },
    Withdraw(u64),
}

#[tauri::command]
pub async fn call_contract(
    rpc_url: String,
    wallet_private_key: String,
    contract_address: String,
    odd_or_even_param: OddOrEvenParam,
) -> (String, String, String, String) {
    let result: Result<(f64, f64, U256, String), Box<dyn Error>> = _call_contract(
        rpc_url,
        wallet_private_key,
        contract_address,
        odd_or_even_param,
    )
    .await;
    return match result {
        Ok((wallet_balance, contract_balance, fee_wei, report_str)) => (
            format!("{wallet_balance}"),
            format!("{contract_balance}"),
            format!("{fee_wei}"),
            report_str,
        ),
        Err(error) => {
            println!("call_contract 出错");
            (
                "".to_string(),
                "".to_string(),
                _parse_ethers_error(error),
                "".to_string(),
            )
        }
    };
}

async fn _call_contract(
    rpc_url: String,
    wallet_private_key: String,
    contract_address: String,
    odd_or_even_param: OddOrEvenParam,
) -> Result<(f64, f64, U256, String), Box<dyn Error>> {
    let wallet = wallet_private_key.parse::<LocalWallet>()?;
    let wallet_address = wallet.address();
    let contract_address: Address = contract_address.parse()?;
    let provider = Provider::try_from(rpc_url)?;
    let chain_id = provider.get_chainid().await?.as_u64();
    let singed_provider = SignerMiddleware::new(provider, wallet.clone().with_chain_id(chain_id));
    let arc_signed_provider = Arc::new(singed_provider);
    let contract_provider = OddOrEven::new(contract_address, arc_signed_provider.clone());
    let gas_price = arc_signed_provider.get_gas_price().await?;

    let wallet_balance_begin = arc_signed_provider
        .get_balance(wallet_address.clone(), None)
        .await?;
    let wallet_balance_begin_eth = utils::format_ether(wallet_balance_begin).parse::<f64>()?;
    let contract_balance_begin = arc_signed_provider
        .get_balance(contract_address, None)
        .await?;
    let contract_balance_begin_eth = utils::format_ether(contract_balance_begin).parse::<f64>()?;

    let (transfered_wei, estimate_gas, contract_reciept, contract_function_desc) =
        match odd_or_even_param {
            OddOrEvenParam::Start { param } => {
                let bet_wei = U256::from_dec_str(param.bet_wei.as_str())?;
                let is_odd = param.is_odd;
                let secret = param.secret;
                let keccak_256_result = _local_keccak256_odd_secret_string(is_odd, secret);
                let betting_time = U256::try_from(param.betting_time)?;
                let reveal_time = U256::try_from(param.reveal_time)?;
                let pending_contract = contract_provider
                    .start(keccak_256_result, betting_time, reveal_time)
                    .value(bet_wei);
                let estimate_gas = pending_contract.estimate_gas().await?;
                // 第一个await是等待交易返回PendingTransaction，第二个await是等待此交易被提交
                // todo: 下面这两个await? 要改为用函数 handule_contract_error 处理返回的错误
                // 而不是全部往上返回 Box<dyn std::error:Error>
                let contract_reciept = pending_contract.send().await?.await?;
                (bet_wei, estimate_gas, contract_reciept, " start ")
            }
            OddOrEvenParam::Against { param } => {
                let gamble_id = U256::from(param.gamble_id);
                let bet_wei = U256::from_dec_str(param.bet_wei.as_str())?;
                let is_odd = param.is_odd;
                let pending_contract = contract_provider.against(gamble_id, is_odd).value(bet_wei);
                let estimate_gas: U256 = pending_contract.estimate_gas().await?;
                let contract_reciept = pending_contract.send().await?.await?;
                (bet_wei, estimate_gas, contract_reciept, " against ")
            }
            OddOrEvenParam::Reveal { param } => {
                let gamble_id = U256::from(param.gamble_id);
                let is_odd = param.is_odd;
                let secret = param.secret;
                // keccak_256_result 必须和 OddOrEvenParam::Start 里提交的值是同一个函数计算得来，这里用来向 solidity 合约验证

                // 验证用户输入正确，再提交，因为 reveal 动作用的是 send，没有返回值，这里正确，保证了 reveal 正确
                let contract_kecak256_string = contract_provider
                    .get_keccak_256(is_odd, secret.clone())
                    .call()
                    .await?;
                let contract_kecak256_string = hex::encode(contract_kecak256_string);
                if !(param.keccak_256_result.eq(&contract_kecak256_string)) {
                    let error_msg = "失败，您输入的单双和密码跟开局时的不一致！".to_string();
                    return Err(error_msg.into());
                }
                let pending_contract = contract_provider.reveal(gamble_id, is_odd, secret);
                let estimate_gas: U256 = pending_contract.estimate_gas().await?;
                let contract_reciept = pending_contract.send().await?.await?;
                (U256::from(0), estimate_gas, contract_reciept, " reveal ")
                // send 主要用于向合约发送以太币，而不是调用合约函数并获取返回值。
                // call 则更适合用于调用合约函数并获取返回值
            }
            OddOrEvenParam::Withdraw(gamble_index) => {
                let gamble_index = U256::from(gamble_index);
                let pending_contract = contract_provider.withdraw(gamble_index);
                let estimate_gas: U256 = pending_contract.estimate_gas().await?;
                let contract_reciept = pending_contract.send().await?.await?;
                (U256::from(0), estimate_gas, contract_reciept, " withdraw ")
            }
        };
    let estimate_fee = estimate_gas * gas_price;
    println!(
        "收据返回的信息：{:?}",
        serde_json::to_string(&contract_reciept)?
    );

    let wallet_balance = arc_signed_provider
        .get_balance(wallet_address.clone(), None)
        .await?;
    let wallet_balance_eth = utils::format_ether(wallet_balance).parse::<f64>()?;
    let contract_balance = arc_signed_provider
        .get_balance(contract_address, None)
        .await?;
    let contract_balance_eth = utils::format_ether(contract_balance).parse::<f64>()?;
    let fee_wei = wallet_balance_begin - transfered_wei - wallet_balance;
    let gas_used_realy = fee_wei / gas_price;
    let fee_desc = format!(
        " {fee_wei} 等于 {wallet_balance_begin} - {transfered_wei} - {wallet_balance}) wei "
    );
    let report_str = format!(
        r#"钱包 {wallet_address} 余额 eth {wallet_balance_begin_eth},
钱包 {wallet_address} 余额 wei {wallet_balance_begin},
合约 {contract_address} 余额 eth {contract_balance_begin_eth},
合约 {contract_address} 余额 wei {contract_balance_begin},
gas 价格 为： {gas_price} wei,
调用合约 {contract_address} 的代码：{contract_function_desc}, 
预估的 gas 消耗为： {estimate_gas}, 
所以预估的费用为： {estimate_fee} 等于 {estimate_gas} X {gas_price} wei,
调用完毕，
现在钱包的余额 eth {wallet_balance_eth},
现在钱包的余额 wei {wallet_balance},
现在合约余额 eth {contract_balance_eth},
现在合约余额 wei {contract_balance},
所以实际消耗费用为： {fee_desc},
实际消耗 gas 为：{gas_used_realy} wei 等于 {fee_wei} 除以 {gas_price} wei .
"#
    );
    println!("{report_str}");
    Ok((
        wallet_balance_eth,
        contract_balance_eth,
        fee_wei, //	因为消耗的 fee 一般不会太大，用 wei 更直观
        report_str,
    ))
}

#[tauri::command]
pub fn local_keccak256_odd_secret_string(is_odd: bool, secret: String) -> String {
    let result = _local_keccak256_odd_secret_string(is_odd, secret);
    hex::encode(result)
}

pub fn _local_keccak256_odd_secret_string(is_odd: bool, secret: String) -> [u8; 32] {
    // 将布尔值和字符串转换为Token类型
    let is_odd_token = Token::Bytes(if is_odd { vec![1_u8] } else { vec![0_u8] });
    let secret_token = Token::Bytes(secret.into_bytes());

    // 使用Token数组进行打包
    let tokens = vec![is_odd_token, secret_token];
    if let Ok(isood_and_secret) = abi::encode_packed(&tokens) {
        // 对打包后的数据进行keccak256哈希
        keccak256(&isood_and_secret)
    } else {
        [0_u8; 32]
    }
}

#[tauri::command]
pub async fn get_contract_version(
    rpc_url: String,
    contract_address: String,
) -> (String, String, String) {
    return match _get_contract_version(rpc_url, contract_address).await {
        Ok(version) => (version, BODD_OR_EVEN_VERSION.to_string(), "".to_string()),
        Err(error) => {
            println!("get_contract_version 出错");
            (
                "".to_string(),
                BODD_OR_EVEN_VERSION.to_string(),
                _parse_ethers_error(error),
            )
        }
    };
}

async fn _get_contract_version(
    rpc_url: String,
    contract_address: String,
) -> Result<String, Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url.as_str())?;
    let arc_provider = Arc::new(provider);
    let contract_address: Address = contract_address.as_str().parse()?;
    let contract = OddOrEven::new(contract_address, arc_provider);
    let version_str = contract.get_version().call().await?;
    // println!("获取到的版本号是：{version_str}。\n只用合约地址就能获取数据，可见获取值不需要花费 gas");
    Ok(version_str.to_string())
}

#[tauri::command]
pub fn transform_value_for_units(
    value_str: String,
    from_unit_str: String,
    to_unit_str: String,
) -> String {
    // from_unit_str 和 to_unit_str 可以是 "wei"  "eth"
    let pu_result = utils::parse_units(value_str, from_unit_str.as_str());
    return match pu_result {
        Ok(pu) => {
            let from = U256::from(pu);
            let to_result = utils::format_units(from, to_unit_str.as_str());
            match to_result {
                Ok(to_string) => {
                    let to_str = to_string.as_str();
                    // 如果小数点后面全是0，则去掉小数点及其后面的所有字符串
                    if let Some(index) = to_str.find('.') {
                        let to_str_int_part = &to_str[0..index];

                        let mut is_decimal_all_zero = true;
                        for ch in to_str.chars().skip(index + 1) {
                            if ch != '0' {
                                is_decimal_all_zero = false;
                                break;
                            }
                        }
                        if is_decimal_all_zero {
                            to_str_int_part.to_string()
                        } else {
                            to_string
                        }
                    } else {
                        to_string
                    }
                }
                Err(error) => format!("出错了：{error}"),
            }
        }
        Err(error) => format!("出错了：{error}"),
    };
}

#[tauri::command]
pub async fn deploy_contract(
    rpc_url: String,
    wallet_private_key: String,
) -> (String, String, String) {
    let result = _deploy_contract(&rpc_url, &wallet_private_key).await;
    match result {
        Ok((contract_address, used_fee, report_str)) => {
            return (contract_address, used_fee, report_str);
        }
        Err(error) => {
            println!("deploy_contract 出错");
            return ("".to_string(), "".to_string(), _parse_ethers_error(error));
        }
    }
}

async fn _deploy_contract(
    rpc_url: &str,
    wallet_private_key: &str,
) -> Result<(String, String, String), Box<dyn Error>> {
    let wallet = wallet_private_key.parse::<LocalWallet>()?;
    // let wallet_address = wallet.address();
    let wallet_address = wallet.address();

    let provider = Provider::try_from(rpc_url)?;
    let chain_id = provider.get_chainid().await?.as_u64();
    let gas_price = provider.get_gas_price().await?;
    let signed_provider = SignerMiddleware::new(provider, wallet.with_chain_id(chain_id));
    let arc_signed_provider = Arc::new(signed_provider);
    let balance_before_deploy = arc_signed_provider
        .get_balance(wallet_address, None)
        .await?;

    let abi_json = include_str!("../../asset/solidity/odd_or_even.json");
    let abi: Abi = serde_json::from_str(&abi_json)?;
    let bytecode = Bytes::try_from(include_bytes!("../../asset/solidity/odd_or_even.bytecode"))?;
    let factory = ContractFactory::new(abi, bytecode, arc_signed_provider.clone());

    // factory.deploy() 的参数根据文档提示，如果智能合约构造函数没有参数，就用 ()
    let pending_deploy_transaction = factory.deploy(())?.send();
    let contract = pending_deploy_transaction.await?; // 等待提交
    let contract_address = contract.address();
    let contract_address_bytes = contract_address.as_bytes();
    let contract_address_str = hex::encode(contract_address_bytes);

    let balance_after_deploy = arc_signed_provider
        .get_balance(wallet_address, None)
        .await?;
    let deploy_used_fee = balance_before_deploy - balance_after_deploy;
    let gas_usage = if gas_price > U256::from(0) {
        deploy_used_fee / gas_price
    } else {
        U256::from(0)
    };
    let ganache_gas_usage = U256::from(1288341);
    let gas_usage_delta = gas_usage - ganache_gas_usage;
    let deploy_used_fee_eth = utils::format_ether(deploy_used_fee).parse::<f64>()?;
    let report_str = format!("新部署合约地址为 {contract_address_str}\n部署前的余额是：{balance_before_deploy}，部署后的余额是：{balance_after_deploy}\n部署花费：{deploy_used_fee} wei，当前gas_price 是 {gas_price}，所以 Gas Usage 是：{gas_usage}\n观察 {rpc_url} 输出：Gas usage: 1288341 ，所以差值是：{gas_usage_delta}\n单位转换成 eth 为 {deploy_used_fee_eth} eth");
    let deploy_used_fee = _get_shorter_string_of_balance(deploy_used_fee);
    println!("{report_str}");
    return Ok((contract_address_str, deploy_used_fee, report_str));
}

#[tauri::command]
pub async fn get_deploy_contract_estimate_fee(rpc_url: String) -> (String, String) {
    let result = _get_deploy_contract_estimate_fee(&rpc_url).await;
    match result {
        Ok(estimate_fee) => (estimate_fee, "".to_string()),
        Err(error) => {
            println!("get_deploy_contract_estimate_fee 出错");
            ("".to_string(), _parse_ethers_error(error))
        }
    }
}

async fn _get_deploy_contract_estimate_fee(rpc_url: &str) -> Result<String, Box<dyn Error>> {
    // Connect to the Ethereum network
    let provider = Provider::<Http>::try_from(rpc_url)?;
    let chain_id = provider.get_chainid().await?.as_u64();
    let bytecode = include_bytes!("../../asset/solidity/odd_or_even.bytecode");
    let tx_request = TransactionRequest::new().data(bytecode).chain_id(chain_id);
    let gas_price = provider.get_gas_price().await?;
    let estimated_gas = provider
        .estimate_gas(&tx_request.clone().into(), None)
        .await?;
    let estimated_fee_wei = gas_price * estimated_gas;
    let estimated_fee = _get_shorter_string_of_balance(estimated_fee_wei);
    Ok(estimated_fee)
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GetWalletBalanceParams {
    blockchain: String,
    network: String,
    rpc_url: String,
    address: String,
}

#[tauri::command]
pub async fn get_contract_balance(rpc_url: String, contract_address: String) -> String {
    let result = _get_contract_balance(rpc_url, contract_address).await;
    match result {
        Ok(balance) => balance,
        Err(error) => {
            println!("get_contract_balance 出错");
            _parse_ethers_error(error)
        }
    }
}

pub async fn _get_contract_balance(
    rpc_url: String,
    contract_address: String,
) -> Result<String, Box<dyn Error>> {
    let contract_address: Address = contract_address.parse()?;
    let provider = Provider::try_from(rpc_url)?;
    let balance_wei = provider.get_balance(contract_address, None).await?;
    let contract_balance = _get_shorter_string_of_balance(balance_wei);
    Ok(contract_balance)
}

#[tauri::command]
pub async fn get_wallet_balance(params: GetWalletBalanceParams) -> String {
    let result: Result<String, Box<dyn Error>> =
        _get_wallet_balance(&params.rpc_url, &params.address).await;
    match result {
        Ok(balance) => balance,
        Err(error) => {
            println!("get_wallet_balance 出错");
            _parse_ethers_error(error)
        }
    }
}

// 获取钱包或者合约余额
async fn _get_wallet_balance(rpc_url: &str, address: &str) -> Result<String, Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url)?;
    let balance_wei = provider.get_balance(address, None).await?;
    let balance = _get_shorter_string_of_balance(balance_wei);
    Ok(balance)
}

#[tauri::command]
pub fn create_random_wallet() -> (String, String) {
    // 创建随机钱包
    let wallet = LocalWallet::new(&mut thread_rng());
    let private_key = hex::encode(wallet.signer().to_bytes());
    let binding = wallet.address();
    let address = binding.as_bytes();
    let address = hex::encode(address);
    (private_key, address)
}

fn _compile_contract_save_json_bytecode(
    contract_file_path: &str,
    contract_name: &str,
) -> Result<String, Box<dyn Error>> {
    if contract_file_path.ends_with(".sol") {
        let solidity_file_path = PathBuf::from(contract_file_path);
        if !solidity_file_path.is_file() || !solidity_file_path.exists() {
            let error_msg = format!("文件 {} 不存在", contract_file_path);
            return Err(error_msg.into());
        } else {
            let solidity_compiled = Solc::default().compile_source(&contract_file_path)?;
            if solidity_compiled.has_error() {
                let error_msg = format!("编译失败，错误为: {:?}", solidity_compiled.errors);
                return Err(error_msg.into());
            } else {
                let (abi, bytecode, _runtime_bytecode) = solidity_compiled
                    .find(contract_name)
                    .unwrap()
                    .into_parts_or_default();
                let byte_code_file_path = solidity_file_path.with_extension("bytecode");
                let mut file = File::create(byte_code_file_path)?;
                file.write_all(&bytecode)?;

                let abi_json = serde_json::to_string(&abi)?;
                let json_file_path = solidity_file_path.with_extension("json");
                let mut file = File::create(json_file_path)?;
                file.write_all(abi_json.as_bytes())?;
                return Ok(abi_json);
            }
        }
    } else {
        let error_msg = format!(
            "参数 {} 不是 solidity 文件，后缀名不是 .sol",
            contract_file_path
        );
        return Err(error_msg.into());
    }
}

#[tauri::command]
pub async fn get_gas_price(rpc_url: String) -> (String, String) {
    let result = _get_gas_price(rpc_url).await;
    match result {
        Ok(gas_price) => (gas_price, "".to_string()),
        Err(error) => {
            println!("get_gas_price 出错");
            ("".to_string(), _parse_ethers_error(error))
        }
    }
}

pub async fn _get_gas_price(rpc_url: String) -> Result<String, Box<dyn Error>> {
    let provider = Provider::try_from(rpc_url)?;
    let gas_price_wei = provider.get_gas_price().await?;
    let gas_price = _get_shorter_string_of_balance(gas_price_wei);
    Ok(gas_price)
}

fn _parse_ethers_error(error: Box<dyn Error>) -> String {
    let error_str = format!("{}", error.to_string());
    println!("_parse_ethers_error: 解释错误信息：{}", error_str);
    //if let json_rpc_error = MyJsonRpcError::from(error) {
    // 尝试将错误转换为 MyJsonRpcError
    let json_rpc_error: MyJsonRpcError = error.into();
    // 返回错误消息
    if json_rpc_error.code != 0 && !json_rpc_error.message.eq("Unknown Error") {
        // -32003 表示错误码，它是以太坊 JSON-RPC 错误码之一。在这种情况下，-32003 表示一个 "交易失败" 的错误
        // "(code: -32003, message: insufficient funds for gas * price + value, data: None) "
        if json_rpc_error.code == -32003 {
            "失败，因余额不够支付转账和 Gas 费用".to_string()
        } else {
            format!(
                "失败：编号：{}, 信息：{}",
                json_rpc_error.code, json_rpc_error.message
            )
        }
    } else {
        match &error_str {
            _s if error_str.contains("Connection reset by peer") => {
                "节点网址的服务器意外地关闭了连接，请再次尝试。".to_string()
            }
            _s if error_str.contains("Connection refused") => "网址连接失败".to_string(),
            s if s.starts_with("ens name not found") => "新地址，无记录".to_string(),
            s => {
                if let Some(readable_text) = _decode_revert_reason(&error_str) {
                    readable_text
                } else {
                    s.to_string()
                }
            }
        }
    }
}

fn _decode_revert_reason(revert_str: &str) -> Option<String> {
    let invalid_method_name_str = "Invalid name: please ensure the contract and method you're calling exist! failed to decode empty bytes. if you're using jsonrpc this is likely due to jsonrpc returning `0x` in case contract or method don't exist";
    let revert_start_str = "Contract call reverted with data: 0x";
    match revert_str {
        s if s.eq(invalid_method_name_str) || s.eq(revert_start_str) => Some(format!(
            "当前合约拒绝您的操作，请注意版本是否为：{BODD_OR_EVEN_VERSION}。"
        )),
        s if s.starts_with(revert_start_str) => {
            let clean_str = s.trim_start_matches(revert_start_str);
            // 将十六进制字符串转换为字节序列
            let bytes = match hex::decode(clean_str) {
                Ok(b) => b,
                Err(_) => return None, // 如果解码失败，返回 None
            };
            // 确保提供的字节序列至少有 4 个字节，因为前面 4 个字节表示错误类型
            if bytes.len() < 4 {
                return None;
            }
            // 提取错误类型，它是前面 4 个字节的内容
            let error_type_bytes = &bytes[..4];
            let error_type = hex::encode(error_type_bytes);
            // 检查错误类型是否为 "0x08c379a0"，这是 Solidity 中 revert 的标准错误类型，暂时只处理这个，以后遇到了再添加
            if error_type != "08c379a0" {
                return None;
            }

            // 剩余的字节是错误消息的内容
            let error_message_bytes = &bytes[4..];

            // 将字节序列转换为 ASCII 字符串
            let error_message = match String::from_utf8(error_message_bytes.to_vec()) {
                Ok(msg) => msg,
                Err(_) => return None,
            };
            // 去掉前面的所有 '\0' 和 '%' 和 ' '
            let start_index = error_message
                .find(|c| c != '\0' && c != ' ' && c != '%' && c != '#' && c != '&')
                .unwrap_or(error_message.len());
            let clear_zero_str = &error_message[start_index..];
            Some(clear_zero_str.to_string())
        }
        _ => match serde_json::from_str::<JsonRpcError>(revert_str) {
            Ok(json_rpc_error) => match json_rpc_error.code {
                _ => Some(revert_str.to_string()),
            },
            Err(_error) => Some(revert_str.to_string()),
        },
    }
}

#[derive(Debug, Deserialize, Serialize)]
pub struct ReadableGamble {
    pub id: String,
    pub starter: Address,
    pub bet_wei: String,
    pub bet: String,
    pub bet_amount: String,
    pub keccak256_result: String,
    pub is_odd: bool,
    pub secret: String,
    pub bet_end: u64,
    pub reveal_end: u64,
    pub againster: Address,
    pub is_odd_against: bool,
}

impl From<odd_or_even::Gamble> for ReadableGamble {
    fn from(gamble: odd_or_even::Gamble) -> Self {
        let bet = _get_shorter_string_of_balance(gamble.2);
        let bet_amount = _get_shorter_string_of_balance(gamble.3);
        let keccak256_result = hex::encode(gamble.4);
        let secret = String::from(gamble.6);
        ReadableGamble {
            id: gamble.0.to_string(),
            starter: Address::from(gamble.1),
            bet_wei: format!("{}", gamble.2), // 在对局时要用到 wei 单位数值
            bet: bet,                         // 一般显示比较短的单位值
            bet_amount: bet_amount,
            keccak256_result: keccak256_result,
            is_odd: gamble.5,
            secret: secret,
            bet_end: gamble.7.as_u64(),
            reveal_end: gamble.8.as_u64(),
            againster: Address::from(gamble.9),
            is_odd_against: gamble.10,
        }
    }
}

fn _get_shorter_string_of_balance(wei_u_256: U256) -> String {
    let wei = format!("{} wei", wei_u_256);
    let eth = format!("{} eth", _u256_to_f64(wei_u_256));
    if wei.len() > eth.len() {
        eth
    } else {
        wei
    }
}

// 转换出错了就返回 0
fn _u256_to_f64(from: U256) -> f64 {
    let result = utils::format_ether(from).parse::<f64>();
    match result {
        Ok(to) => to,
        Err(_error) => 0_f64,
    }
}

#[derive(Debug, Deserialize, Serialize)]
pub struct MyJsonRpcError {
    pub code: i64,
    pub message: String,
    pub data: Option<Value>,
}

impl From<Box<dyn Error>> for MyJsonRpcError {
    fn from(error: Box<dyn Error>) -> Self {
        // 将错误转换为字符串
        let error_string = error.to_string();

        // 解析错误字符串
        let mut code: Option<i64> = None;
        let mut message: Option<String> = None;
        let mut data: Option<Value> = None;

        // 解析 code
        if let Some(start_idx) = error_string.find("code: ") {
            if let Some(end_idx) = error_string[start_idx..].find(",") {
                let code_str = &error_string[start_idx + 6..start_idx + end_idx].trim();
                if let Ok(code_val) = i64::from_str(code_str) {
                    code = Some(code_val);
                }
            }
        }

        // 解析 message
        if let Some(start_idx) = error_string.find("message: ") {
            if let Some(end_idx) = error_string[start_idx..].find(",") {
                message = Some(
                    error_string[start_idx + 9..start_idx + end_idx]
                        .trim()
                        .to_string(),
                );
            }
        }

        // 解析 data
        if let Some(start_idx) = error_string.find("data: ") {
            if let Some(end_idx) = error_string[start_idx..].find(")") {
                let data_str = &error_string[start_idx + 6..start_idx + end_idx].trim();
                if let Ok(data_val) = serde_json::from_str(data_str) {
                    data = Some(data_val);
                }
            }
        }

        // 构建 MyJsonRpcError
        let code = code.unwrap_or(0);
        let message = message.unwrap_or_else(|| "Unknown Error".to_string());
        MyJsonRpcError {
            code,
            message,
            data,
        }
    }
}

// 将字符串转换为 [u8; 64]
fn _string_to_bytes64(input: &str) -> Result<[u8; 64], hex::FromHexError> {
    // 将输入的字符串编码为十六进制
    let encoded_input = hex::encode(input);
    // 将十六进制字符串解码为字节数组
    let decoded_bytes = hex::decode(encoded_input)?;
    // 将字节数组转换为固定长度的数组
    let result: [u8; 64] = decoded_bytes[..64].try_into().unwrap();
    Ok(result)
}

// 将字符串转换为 [u8; 32]
fn _string_to_bytes32(input: &str) -> Result<[u8; 32], hex::FromHexError> {
    // 将输入的字符串编码为十六进制
    let encoded_input = hex::encode(input);
    // 将十六进制字符串解码为字节数组
    let decoded_bytes = hex::decode(encoded_input)?;
    // 将字节数组转换为固定长度的数组
    let result: [u8; 32] = decoded_bytes[..32].try_into().unwrap();
    Ok(result)
}

// 将 [u8; 32] 转换为字符串
fn _bytes32_to_string(input: &[u8; 32]) -> String {
    // 将字节数组编码为十六进制字符串
    let encoded_bytes_str = hex::encode(input);
    // 将十六进制字符串解码为字符串
    hex::decode(encoded_bytes_str.clone()).unwrap_or_else(|_| {
        // 如果解码失败，则返回一个错误字符串
        "Error: Failed to decode hex string".as_bytes().to_vec()
    });
    String::from_utf8_lossy(&hex::decode(encoded_bytes_str).unwrap()).into_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bytes32_string_converter() {
        let input_string = "Hello, world!Hello, world!Hello, world!"; // 输入字符串
        if let Ok(byte) = _string_to_bytes32(&input_string) {
            let output_string = _bytes32_to_string(&byte);
            assert_eq!(
                input_string[..32],
                output_string,
                "string 和 byte32 转换出来的前 32 位应该一样"
            );
        }
    }

    #[test]
    fn test_deploy_contract() {
        tokio_test::block_on(async {
            let result = deploy_contract(
                "http://127.0.0.1:8545".to_string(),
                "0x4f3edf983ac636a65a842ce7c78d9aa706d3b113bce9c46f30d7d21715b23b1d".to_string(),
            )
            .await;
            let (contract_address, used_fee, report_str) = result;
            println!("test_deploy_contract 执行完成，返回的新部署合约地址为 {contract_address}，部署费用为：{used_fee} eth");
            println!("test_deploy_contract 的 report_str 是 {report_str}");
            // ganache输出的 Gas Usage是 1288341  gas_price 是 2000000000，所以预计费用是：0.002576682 eth
            // 测试输出 ：修改合约后，要重新部署，并删掉旧的合约地址，因为程序已经更改了，调用合约会失败
            // 1 	新部署合约地址为 af5c4c6c7920b4883bc6252e9d9b8fe27187cf68
            // 部署前的余额是：999958078110591976928，部署后的余额是：999954123918536296740
            // 所以部署花费：3954192055680188 wei，当前gas_price 是 2000000000，所以 Gas Usage 是：1977096
            // 观察 http://127.0.0.1:8545 输出：Gas usage: 1288341 ，所以差值是：688755
            // 单位转换成 eth 为 0.003954192055680188 eth
        });
    }

    #[test]
    fn test_compile_contract_odd_or_even() {
        let result = _compile_contract_save_json_bytecode(
            "/Users/wdfc/Documents/Practice/Rust/odd-or-even/asset/solidity/odd_or_even.sol",
            "OddOrEven",
        );
        match result {
            Ok(abi_json) => println!(
                "test_compile_contract_odd_or_even 编译了 odd_or_even.sol 的 abi json 是 {:?}",
                abi_json
            ),
            Err(error) => println!("test_compile_contract_odd_or_even 失败：{}", error),
        }
    }
}

/*
match err {
    ContractError::MiddlewareError { e } => match e {
        SignerMiddlewareError::MiddlewareError(provider_error) => match provider_error {
            ProviderError::JsonRpcClientError(err) => {
                if let Some(JsonRpcError {
                    code: _,
                    message: _,
                    data: Some(Value::String(hex)),
                }) = err.as_error_response() // try to convert JsonRpcClientError into JsonRpcError
                {
                    let name = Hello::decode_hex(hex)?.name;
                    assert_eq!(name, "World");
                } else {
                    println!("{err:?}");
                }
            }
            ProviderError::EnsError(_) => todo!(),
            ProviderError::EnsNotOwned(_) => todo!(),
            ProviderError::SerdeJson(_) => todo!(),
            ProviderError::HexError(_) => todo!(),
            ProviderError::HTTPError(_) => todo!(),
            ProviderError::CustomError(_) => todo!(),
            ProviderError::UnsupportedRPC => todo!(),
            ProviderError::UnsupportedNodeClient => todo!(),
            ProviderError::SignerUnavailable => todo!(),
        },
        SignerMiddlewareError::SignerError(_) => todo!(),
        SignerMiddlewareError::NonceMissing => todo!(),
        SignerMiddlewareError::GasPriceMissing => todo!(),
        SignerMiddlewareError::GasMissing => todo!(),
        SignerMiddlewareError::WrongSigner => todo!(),
        SignerMiddlewareError::DifferentChainID => todo!(),
    },
    ContractError::DecodingError(_) => todo!(),
    ContractError::AbiError(_) => todo!(),
    ContractError::DetokenizationError(_) => todo!(),
    ContractError::ProviderError { e: _ } => todo!(),
    ContractError::Revert(_) => todo!(),
    ContractError::ConstructorError => todo!(),
    ContractError::ContractNotDeployed => todo!(),
}*/
