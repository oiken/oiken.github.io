'use strict';

// 与 Tauri 交互的都在这里写，方便更换为网页服务器

// window.__TAURI__. 可以搭配的有以下的
// app;
// cli;
// clipboard;
// dialog;
// event;
// fs;
// globalShortcut;
// http;
// notification;
// path;
// process;
// shell;
// tauri;
// updater;
// window;
// os;
// invoke;

const { invoke } = window.__TAURI__.tauri;
const invokeTauriJs = {

	// 监听合约事件
	listenContractEvents: async function (eventNameFromRust, func) {
		const { listen } = window.__TAURI__.event;
		const unlisten = listen(eventNameFromRust, (event) => {
			func(event);
		});
		return unlisten; // 在 调用这个函数的地方记住这个变量，需要取消监听合约事件时调用  unlisten(); 就行了
	},

	unsubscribeEvent: async function (contractAddress) {
		const { invoke } = window.__TAURI__.tauri;
		await invoke('unsubscribe_event', { contractAddress: contractAddress });
	},

	subscribeEvent: async function (rpcUrl, contractAddress) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('subscribe_event', {
			rpcUrl: rpcUrl, contractAddress: contractAddress,
		});
		return result; // 没有返回值
	},

	withdrawGamble: async function (rpcUrl, walletPrivateKey, contractAddress, gambleId) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('call_contract', {
			rpcUrl: rpcUrl, walletPrivateKey: walletPrivateKey, contractAddress: contractAddress,
			oddOrEvenParam: {
				Withdraw: gambleId
			}
		});
		return { walletBalance: result[0], contractBalance: result[1], feeWei: result[2], reportStr: result[3] };
	},

	revealGamble: async function (rpcUrl, walletPrivateKey, contractAddress, gambleId, isOdd, secret, keccak256Result) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('call_contract', {
			rpcUrl: rpcUrl, walletPrivateKey: walletPrivateKey, contractAddress: contractAddress,
			oddOrEvenParam: {
				Reveal: {
					param: {
						gamble_id: gambleId,
						is_odd: isOdd,
						secret: secret,
						keccak_256_result: keccak256Result,
					}
				}
			}
		});
		return { walletBalance: result[0], contractBalance: result[1], feeWei: result[2], reportStr: result[3] };
	},

	againstGamble: async function (rpcUrl, walletPrivateKey, contractAddress, gambleId, betWei, isOdd) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('call_contract', {
			rpcUrl: rpcUrl, walletPrivateKey: walletPrivateKey, contractAddress: contractAddress,
			oddOrEvenParam: {
				Against: {
					param: {
						gamble_id: gambleId,
						bet_wei: betWei,
						is_odd: isOdd,
					}
				}
			}
		});
		return { walletBalance: result[0], contractBalance: result[1], feeWei: result[2], reportStr: result[3] };
	},

	startGamble: async function (rpcUrl, walletPrivateKey, contractAddress, betWei, isOdd, secret, bettingTime, revealTime) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('call_contract', {
			rpcUrl: rpcUrl, walletPrivateKey: walletPrivateKey, contractAddress: contractAddress,
			oddOrEvenParam: {
				Start: {
					param: {
						bet_wei: betWei,
						is_odd: isOdd,
						secret: secret,
						betting_time: bettingTime,
						reveal_time: revealTime,
					}
				}
			}
		});
		return { walletBalance: result[0], contractBalance: result[1], feeWei: result[2], reportStr: result[3] };
	},

	getLatestGambles: async function (rpcUrl, contractAddress, count,) {
		const result = await invoke('get_latest_gambles', { rpcUrl: rpcUrl, contractAddress: contractAddress, count: count });
		return { gambles: result[0], gamblesAmount: result[1], errorMsg: result[2] };
	},

	getMyLatestGambles: async function (rpcUrl, contractAddress, count, walletAddress,) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('get_my_latest_gambles', { rpcUrl: rpcUrl, contractAddress: contractAddress, count: count, walletAddress: walletAddress, });
		return { gambles: result[0], gamblesAmount: result[1], errorMsg: result[2] };
	},

	batchGetContractGambles: async function (rpcUrl, contractAddress, fromIndex, count) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('batch_get_contract_gambles', { rpcUrl: rpcUrl, contractAddress: contractAddress, fromIndexOfGamble: fromIndex, gambleCount: count });
		return { gambles: result[0], gamblesAmount: result[1], errorMsg: result[2] };
	},

	batchGetContractMyGambles: async function (rpcUrl, contractAddress, walletAddress, fromIndex, count) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('batch_get_contract_my_gambles', { rpcUrl: rpcUrl, contractAddress: contractAddress, walletAddress: walletAddress, fromIndexOfGamble: fromIndex, gambleCount: count });
		return { gambles: result[0], gamblesAmount: result[1], errorMsg: result[2] };
	},

	// 从合约获取哈希值，用来验证已开盘的赌局的判断是否正确
	contractKeccak256OddSecret: async function (rpcUrl, contractAddress, isOdd, secret) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('contract_keccak256_odd_secret_string', {
			rpcUrl: rpcUrl, contractAddress: contractAddress, isOdd: isOdd, secret: secret
		});
		return { keccak256Str: result[0], reportStr: result[1] };
	},

	// rust 本地产生的哈希值，在开局时使用，发给合约保存，不能调用合约来生成，开局的密码连合约也不可以知道
	localKeccak256OddSecretString: async function (isOdd, secret) {
		const { invoke } = window.__TAURI__.tauri;
		return await invoke('local_keccak256_odd_secret_string', {
			isOdd: isOdd, secret: secret
		});
	},

	getContractVersion: async function (rpcUrl, contractAddress) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('get_contract_version', {
			rpcUrl: rpcUrl, contractAddress: contractAddress
		});
		return { contractVersion: result[0], appVersion: result[1], errorMsg: result[2] };
	},

	transformValueForUnits: async function (valueStr, fromUnitStr, toUnitStr) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('transform_value_for_units', { valueStr: valueStr, fromUnitStr: fromUnitStr, toUnitStr: toUnitStr });
		return result;
	},

	deployContract: async function (rpcUrl, walletPrivateKey) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('deploy_contract', { rpcUrl: rpcUrl, walletPrivateKey: walletPrivateKey });
		return { contractAddress: result[0], gasUsage: result[1], reportStr: result[2] };
	},

	getDeployContractEstimateGas: async function (rpcUrl) {
		const { invoke } = window.__TAURI__.tauri;
		// 注意：给 rust 函数参数的名字，是没有下划线的，tauri自己会把驼峰变成下划线的蛇形，否则无法获取到参数
		const result = await invoke('get_deploy_contract_estimate_fee', { rpcUrl: rpcUrl });
		return { estimateGas: result[0], reportStr: result[1] };
	},

	getContractSourceCode: async function () {
		const { invoke } = window.__TAURI__.tauri;
		const sourceCode = await invoke('get_contract_source_code');
		console.log("get_contract_source_code: 返回结果：", sourceCode);
		return sourceCode;
	},

	getContractBalance: async function (rpcUrl, contractAddress) {
		const { invoke } = window.__TAURI__.tauri;
		const balance = await invoke('get_contract_balance', { rpcUrl: rpcUrl, contractAddress: contractAddress });
		return balance;
	},

	getWalletBalance: async function (rpcUrl, address) {
		const params = {
			params: {
				blockchain: 'ethereum',
				network: 'privateNet',
				rpc_url: rpcUrl, // 给 rust 的参数要用 蛇形命名
				address: address,
			}
		};

		const { invoke } = window.__TAURI__.tauri;
		const balance = await invoke('get_wallet_balance', params);
		return balance;
	},

	createRandomWallet: async function () {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('create_random_wallet');
		return [result[0], result[1]]; // 返还相同的，可以数组形式
	},

	getGasPrice: async function (rpcUrl) {
		const { invoke } = window.__TAURI__.tauri;
		const result = await invoke('get_gas_price', { rpcUrl: rpcUrl });
		return { gasPriceEth: result[0], reportStr: result[1] }; // 最简单的用这种类似 map 的格式
	},
}