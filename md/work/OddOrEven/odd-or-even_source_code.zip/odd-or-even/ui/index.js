'use strict';

const MyWalletPrivateKeyId = 'myWalletPrivateKeyId';
const MyWalletOptgroupId = 'myWalletOptgroup';
const NodeUrlInputId = "nodeUrlInput";
const DeployedContractAddressSelectId = "deployedContractAddressSelect";
const DeployedContractAddressSelectIndex = 'deployedContractAddressSelectIndex';
const TestWalletAndPrivateKey = {
	'0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1': '0x4f3edf983ac636a65a842ce7c78d9aa706d3b113bce9c46f30d7d21715b23b1d',
	'0xFFcf8FDEE72ac11b5c542428B35EEF5769C409f0': '0x6cbed15c793ce57650b9877cf6fa156fbef513c4e6134f022a85b1ffdd59b2a1',
	'0x22d491Bde2303f2f43325b2108D26f1eAbA1e32b': '0x6370fd033278c143179d81c5526140625662b8daa446c22ee2d73db3707e620c',
	'0xE11BA2b4D45Eaed5996Cd0823791E0C93114882d': '0x646f1ce2fdad0e6deeeb5c7e8e5543bdde65e86029e2fd9fc169899c440a7913',
	'0xd03ea8624C8C5987235048901fB614fDcA89b117': '0xadd53f9a7e588d003326d1cbf9e4a43c061aadd9bc938c843a79e7b4fd2ad743',
	'0x95cED938F7991cd0dFcb48F0a06a40FA1aF46EBC': '0x395df67f0c2d2d9fe1ad08d1bc8b6627011959b79c53d7dd6a3536a33ab8a4fd',
	'0x3E5e9111Ae8eB78Fe1CC3bb8915d5D461F3Ef9A9': '0xe485d098507f54e7733a205420dfddbe58db035fa577fc294ebd14db90767a52',
	'0x28a8746e75304c0780E011BEd21C72cD78cd535E': '0xa453611d9419d0e56f499079478fd72c37b251a94bfde4d19872c44cf65386e3',
	'0xACa94ef8bD5ffEE41947b4585a84BdA5a3d3DA6E': '0x829e924fdf021ba3dbbc4225edfece9aca04b929d6e75613329ca6f1d31c0bb4',
	'0x1dF62f291b2E969fB0849d99D9Ce41e2F137006e': '0xb0057716d5917badaf911b193b12b910811c1497b5bada8d7711f758981c3773',
}
const GambleDetailsLabelPrefix = 'gambleDetailsLabel_';
const NullAdress = "0x0000000000000000000000000000000000000000";
const EventListLabelPrefix = 'evenLabel';

let gambleBetInputWeiPrevious = "";
let gambleBetInputEthPrevious = "";
let secretInputPrevious = "";
let revealSecretInputPrevious = "";

const GetGamblesCount = 4; // 每次获取局的数量
let gamblesAmount = 0;
let myGamblesAmount = 0;
let isShowingMyGambles = false;
let gambleArray = [];
let currentPageIndexOfGambles = 0;
let currentIndexOfGambles = 0; // 当前列表中正在显示的局的序号 ，点击列表中的一个时显示蓝色外框记住序号，去掉上次的蓝色外框

let unlistenEventStart = null;
let unlistenEventAgainst = null;
let unlistenEventReveal = null;
let unlistenEventWithdraw = null;

document.addEventListener("DOMContentLoaded", function () {
	const blockchainSelect = document.getElementById('blockchainSelect');
	blockchainSelect.addEventListener('change', onValueChanged);
	const networkSelect = document.getElementById('networkSelect');
	networkSelect.addEventListener('change', onValueChanged);
	const newWalletButton = document.getElementById('newWalletButton');
	newWalletButton.addEventListener('click', onClicked);
	const useWalletButton = document.getElementById('useWalletButton');
	useWalletButton.addEventListener('click', onClicked);
	const notUseWalletButton = document.getElementById('notUseWalletButton');
	notUseWalletButton.addEventListener('click', onClicked);

	let urlSaved = localStorage.getItem(NodeUrlInputId);
	if (urlSaved === null || urlSaved === undefined || urlSaved.length == 0) {
		urlSaved = "http://64.176.193.137:8545";
		localStorage.setItem(NodeUrlInputId, urlSaved);
	}
	const nodeUrlInput = document.getElementById(NodeUrlInputId);
	nodeUrlInput.value = urlSaved;
	nodeUrlInput.addEventListener('change', onValueChanged);
	const gasPriceLabel = document.getElementById('gasPriceLabel');
	gasPriceLabel.addEventListener('click', onClicked);

	const walletSelect = document.getElementById('walletSelect');
	reloadWalletSelectFromLocalStorage();
	const walletSaved = localStorage.getItem("walletSelectValue");
	if (!(walletSaved === null || walletSaved === undefined || walletSaved.length == 0)) {
		walletSelect.value = walletSaved;
	}
	walletSelect.addEventListener('change', onValueChanged);
	const walletBanlance = document.getElementById('walletBanlance');
	walletBanlance.addEventListener('click', onClicked);

	const gasLimitInput = document.getElementById('gasLimitInput');
	const gasLimitSaved = localStorage.getItem("gasLimitInputValue");
	if (!(gasLimitSaved === null || gasLimitSaved === undefined || gasLimitSaved.length == 0)) {
		gasLimitInput.value = gasLimitSaved;
	}
	gasLimitInput.addEventListener('change', onValueChanged);

	const deployContractEstimateGasLabel = document.getElementById('deployContractEstimateGasLabel');
	deployContractEstimateGasLabel.addEventListener('click', onClicked);
	const deployContractButton = document.getElementById('deployContractButton');
	deployContractButton.addEventListener('click', onClicked);

	const deployedContractAddressSelectId = document.getElementById(DeployedContractAddressSelectId);
	deployedContractAddressSelectId.addEventListener('change', onValueChanged);
	const removeContractAddressButton = document.getElementById('removeContractAddressButton');
	removeContractAddressButton.addEventListener('click', onClicked);
	const contractVersionLabel = document.getElementById('contractVersionLabel');
	contractVersionLabel.addEventListener('click', onClicked);
	const contractBalanceLabel = document.getElementById('contractBalanceLabel');
	contractBalanceLabel.addEventListener('click', onClicked);
	const contractAddressInput = document.getElementById('contractAddressInput');
	contractAddressInput.addEventListener('change', onValueChanged);
	const addContractAddressButton = document.getElementById('addContractAddressButton');
	addContractAddressButton.addEventListener('click', onClicked);

	const listLatestGambles = document.getElementById('listLatestGambles');
	listLatestGambles.addEventListener('click', onClicked);
	const listMyLatestGambles = document.getElementById('listMyLatestGambles');
	listMyLatestGambles.addEventListener('click', onClicked);
	const startGamble = document.getElementById('startGamble');
	startGamble.addEventListener('click', onClicked);

	const oddOption = document.getElementById('oddOption');
	oddOption.addEventListener('change', onValueChanged);
	const oddOptionLabel = document.getElementById('oddOptionLabel');
	oddOptionLabel.addEventListener('click', onClicked);
	const evenOption = document.getElementById('evenOption');
	evenOption.addEventListener('change', onValueChanged);
	const evenOptionLabel = document.getElementById('evenOptionLabel');
	evenOptionLabel.addEventListener('click', onClicked);

	const genRandomSecret = document.getElementById('genRandomSecret');
	genRandomSecret.addEventListener('click', onClicked);
	const secretInput = document.getElementById('secretInput');
	secretInput.oninput = onValueChanged; // 一边输入一边转换
	secretInput.addEventListener('change', onValueChanged);
	const submitButtonOfStartedGamble = document.getElementById('submitButtonOfStartedGamble');
	submitButtonOfStartedGamble.addEventListener('click', onClicked);

	const gambleBetInputWei = document.getElementById('gambleBetInputWei');
	gambleBetInputWei.oninput = onValueChanged; // 一边输入一边转换
	gambleBetInputWei.addEventListener('change', onValueChanged);
	const gambleBetInputEth = document.getElementById('gambleBetInputEth');
	gambleBetInputEth.oninput = onValueChanged;
	gambleBetInputEth.addEventListener('change', onValueChanged);

	const previousPageButton = document.getElementById('previousPageButton');
	previousPageButton.addEventListener('click', onClicked);
	const nextPageButton = document.getElementById('nextPageButton');
	nextPageButton.addEventListener('click', onClicked);

	const revealSecretInput = document.getElementById('revealSecretInput');
	revealSecretInput.oninput = onValueChanged; // 一边输入一边转换
	revealSecretInput.addEventListener('change', onValueChanged);
	const withdrawButton = document.getElementById('withdrawButton');
	withdrawButton.addEventListener('click', onClicked);
	const againstButton = document.getElementById('againstButton');
	againstButton.addEventListener('click', onClicked);
	const revealButton = document.getElementById('revealButton');
	revealButton.addEventListener('click', onClicked);
	const revealOddOptionLabel = document.getElementById('revealOddOptionLabel');
	revealOddOptionLabel.addEventListener('click', onClicked);
	const revealOddOption = document.getElementById('revealOddOption');
	revealOddOption.addEventListener('change', onValueChanged);
	const revealEvenOptionLabel = document.getElementById('revealEvenOptionLabel');
	revealEvenOptionLabel.addEventListener('click', onClicked);
	const revealEvenOption = document.getElementById('revealEvenOption');
	revealEvenOption.addEventListener('change', onValueChanged);

	const verifyButton = document.getElementById('verifyButton');
	verifyButton.addEventListener('click', onClicked);

	initBettingAndRevealTimeSelect();
	getGasPrice();
	refreshWalletBalance();
	getDeployContractEstimateGas();
	refreshContractContents();
	listenContractEvents();
});

function onValueChanged(event) {
	event.preventDefault();

	switch (event.target.id) {
		case 'revealSecretInput': {
			const revealSecretInput = document.getElementById('revealSecretInput');
			const input = revealSecretInput.value;
			const allowedCharacters = /^[A-Za-z0-9]+$/;
			if (input.length > 0 && !allowedCharacters.test(input)) {
				revealSecretInput.value = revealSecretInputPrevious;
				alert("只能输入大小字母和数字！");
			} else {
				revealSecretInputPrevious = input;
				getKeccak256OddSecretForReveal();
			}
			break;
		}
		case 'secretInput': {
			const secretInput = document.getElementById('secretInput');
			const input = secretInput.value;
			const allowedCharacters = /^[A-Za-z0-9]+$/;
			if (input.length > 0 && !allowedCharacters.test(input)) {
				secretInput.value = secretInputPrevious;
				alert("只能输入大小字母和数字！");
			} else {
				secretInputPrevious = input;
				getKeccak256OddSecret();
			}
			break;
		}
		case 'revealOddOption':
		case 'revealEvenOption': {
			getKeccak256OddSecretForReveal();
		}
		case 'oddOption':
		case 'evenOption': {
			getKeccak256OddSecret();
			break;
		}
		case 'gambleBetInputEth': {
			const gambleBetInputEth = document.getElementById('gambleBetInputEth');
			const input = gambleBetInputEth.value;
			if (!/^\d*\.?\d*$/.test(input)) {
				gambleBetInputEth.value = gambleBetInputEthPrevious;
				alert("只能输入数字！");
			} else {
				gambleBetInputEthPrevious = input;

				invokeTauriJs.transformValueForUnits(gambleBetInputEth.value, 'eth', 'wei').then(
					result => {
						const gambleBetInputWei = document.getElementById('gambleBetInputWei');
						gambleBetInputWei.value = result;
						gambleBetInputWeiPrevious = result;
					}
				);
			}
			break;
		}
		case 'gambleBetInputWei': {
			const gambleBetInputWei = document.getElementById('gambleBetInputWei');
			const input = gambleBetInputWei.value;
			if (!/^\d*\d*$/.test(input)) {
				gambleBetInputWei.value = gambleBetInputWeiPrevious;
				alert("只能输入数字！");
			} else {
				gambleBetInputWeiPrevious = input;

				invokeTauriJs.transformValueForUnits(gambleBetInputWei.value, 'wei', 'eth').then(
					result => {
						const gambleBetInputEth = document.getElementById('gambleBetInputEth');
						gambleBetInputEth.value = result;
						gambleBetInputEthPrevious = result;
					}
				);
			}
			break;
		}
		case 'deployedContractAddressSelect': {
			// 更换后侦听新合约地址的事件之前会停止监听原来合约的事件，只有删除合约时不知是否还有合约地址，才主动不侦听被删除的合约
			let deployedContractAddressSelectId = document.getElementById(DeployedContractAddressSelectId);
			localStorage.setItem(DeployedContractAddressSelectIndex, deployedContractAddressSelectId.selectedIndex);
			refreshContractContents();
			break;
		}
		case "gasLimitInput": {
			const gasLimitInput = document.getElementById('gasLimitInput');
			const minGas = 21000;
			let gasLimit = gasLimitInput.value;
			if (gasLimit < minGas) {
				alert("您设置的 gas 限额低于" + minGas + "，交易可能因为 gas 耗尽而失败");
				gasLimit = minGas;
				gasLimitInput.value = minGas
			}
			localStorage.setItem("gasLimitInputValue", gasLimitInput.value);
		}
		case "walletSelect": {
			const walletSelect = document.getElementById('walletSelect');
			localStorage.setItem("walletSelectValue", walletSelect.value);
			refreshWalletBalance();
			refreshContractContents();
			break;
		}
		case NodeUrlInputId: {
			const nodeUrlInput = document.getElementById(NodeUrlInputId);
			let urlSaved = nodeUrlInput.value;
			if (urlSaved === null || urlSaved === undefined || urlSaved.length == 0) {
				urlSaved = "http://64.176.193.137:8545";
			}
			nodeUrlInput.value = urlSaved;
			localStorage.setItem(NodeUrlInputId, urlSaved);
			getGasPrice();
			refreshWalletBalance();
			refreshContractContents();
			break;
		}
		case "networkSelect": {
			const networkSelect = document.getElementById('networkSelect');
			const onlyValue = '指定测试网';
			if (onlyValue != networkSelect.value) {
				networkSelect.value = 'privateNet';
				alert("抱歉，只实现了指定测试网");
			}
			break;
		}
		case 'blockchainSelect': {
			const blockchainSelect = document.getElementById('blockchainSelect');
			const onlyValue = 'ethereum';
			if (onlyValue != blockchainSelect.value) {
				blockchainSelect.value = onlyValue;
				alert("抱歉，只实现了以太坊");
			}
			break;
		}
	}
}

function onClicked(event) {
	event.preventDefault();

	switch (event.target.id) {
		case 'previousPageButton': {
			if (currentPageIndexOfGambles > 1) {
				currentPageIndexOfGambles--;
				getLatestGambles(GetGamblesCount, false, isShowingMyGambles, (currentPageIndexOfGambles - 1) * GetGamblesCount);
			}
			const previousPageButton = document.getElementById('previousPageButton');
			previousPageButton.disabled = currentPageIndexOfGambles <= 1;
			break;
		}
		case 'nextPageButton': {
			let pageAmount = 0;
			if (isShowingMyGambles) {
				pageAmount = Math.floor(myGamblesAmount / GetGamblesCount);
				if (pageAmount * GetGamblesCount < myGamblesAmount) {
					pageAmount++;
				}
			} else {
				pageAmount = Math.floor(gamblesAmount / GetGamblesCount);
				if (pageAmount * GetGamblesCount < gamblesAmount) {
					pageAmount++;
				}
			}
			if (currentPageIndexOfGambles < pageAmount) {
				currentPageIndexOfGambles++;
				let fromIndex = (currentPageIndexOfGambles - 1) * GetGamblesCount;
				getLatestGambles(GetGamblesCount, false, isShowingMyGambles, fromIndex);
			} else if (currentPageIndexOfGambles == pageAmount) {
				getLatestGambles(GetGamblesCount, false, isShowingMyGambles, undefined);
			}
			if (currentPageIndexOfGambles > 1) {
				const previousPageButton = document.getElementById('previousPageButton');
				previousPageButton.disabled = false;
			}
			break;
		}
		case 'verifyButton': {
			verifyGamble();
			break;
		}
		case 'revealButton': {
			revealGamble();
			break;
		}
		case 'againstButton': {
			againstGamble();
			break;
		}
		case 'withdrawButton': {
			withdrawGamble();
			break;
		}
		case 'submitButtonOfStartedGamble': {
			submitStartGamble();
			break;
		}
		case 'genRandomSecret': {
			const secretInput = document.getElementById('secretInput');
			secretInput.value = createRandomSecret(32);
			getKeccak256OddSecret();
			break;
		}
		case 'listLatestGambles': {
			isShowingMyGambles = false;
			currentIndexOfGambles = 0;
			refreshContractContents();
			break;
		}
		case 'listMyLatestGambles': {
			isShowingMyGambles = true;
			currentIndexOfGambles = 0;
			refreshContractContents();
			break;
		}
		case 'startGamble': {
			startGamble();
			break;
		}
		case 'revealOddOptionLabel': {
			const revealOddOption = document.getElementById('revealOddOption');
			revealOddOption.checked = true;
			getKeccak256OddSecretForReveal();
			break;
		}
		case 'revealEvenOptionLabel': {
			const revealEvenOption = document.getElementById('revealEvenOption');
			revealEvenOption.checked = true;
			getKeccak256OddSecretForReveal();
			break;
		}
		case 'oddOptionLabel': {
			const oddOption = document.getElementById('oddOption');
			oddOption.checked = true;
			getKeccak256OddSecret();
			break;
		}
		case 'evenOptionLabel': {
			const evenOption = document.getElementById('evenOption');
			evenOption.checked = true;
			getKeccak256OddSecret();
			break;
		}
		case 'addContractAddressButton': {
			const contractAddressInput = document.getElementById('contractAddressInput');
			let contractAddress = contractAddressInput.value;
			if (contractAddress.length == 42) {
				contractAddress = contractAddress.slice(2);
			}
			if (contractAddress.length != 40) {
				alert("以太坊的合约地址长度是40，如果前面两位是 0x ，请先删掉");
			} else {
				saveValueToListByLocalStorage(contractAddress, DeployedContractAddressSelectId);
				refreshContractContents();
				alert("完成！\n请注意：请注意合约的版本号，如果版本不一致，本 app 将无法操作这个地址的合约。");
			}
			break;
		}
		case 'contractVersionLabel': {
			refreshContractVersion();
			break;
		}
		case 'contractBalanceLabel': {
			refreshContractBalance();
			break;
		}
		case 'removeContractAddressButton': {
			removeCurrentContractAddress();
			break;
		}
		case 'deployContractButton': {
			deployContract();
			break;
		}
		case 'deployContractEstimateGasLabel': {
			const deployContractEstimateGasLabel = document.getElementById('deployContractEstimateGasLabel');
			deployContractEstimateGasLabel.innerText = "正在查询";
			getDeployContractEstimateGas();
			break;
		}
		case 'walletBanlance': {
			const walletBanlance = document.getElementById('walletBanlance');
			walletBanlance.innerText = "正在查询";
			refreshWalletBalance();
			break;
		}
		case 'notUseWalletButton': {
			const walletInput = document.getElementById('walletInput');
			const walletInputValue = walletInput.value;
			removeValueToListByLocalStorage(walletInputValue, MyWalletOptgroupId);
			localStorage.removeItem(walletInputValue);	// 删除密钥
			reloadWalletSelectFromLocalStorage();
			const walletSelect = document.getElementById('walletSelect');
			walletSelect.selectedIndex = 0;
			refreshWalletBalance();
			break;
		}
		case 'useWalletButton': {
			const privateKeyInput = document.getElementById('privateKeyInput');
			const privateKeyInputValue = privateKeyInput.value;
			// 等刷新后获取钱包地址，再提示给用户保留密钥
			const walletInput = document.getElementById('walletInput');
			const walletInputValue = walletInput.value;
			if (walletInputValue.length > 0) {
				saveValueToListByLocalStorage(walletInput.value, MyWalletOptgroupId);
				localStorage.setItem(walletInputValue, privateKeyInputValue); // 保存密码，选择的时候用
				reloadWalletSelectFromLocalStorage();
				const walletSelect = document.getElementById('walletSelect');
				walletSelect.selectedIndex = 0; // 用刚刚加入进去的钱包
				refreshWalletBalance();
				if (privateKeyInputValue.length > 0) {
					alert('在本地记住了钱包 ' + walletInputValue + '\n和密钥：' + privateKeyInputValue);
				} else {
					alert('在本地记住了钱包 ' + walletInputValue + '\n没有密钥。');
				}
			} else {
				alert('钱包地址为空。');
			}
			break;
		}
		case 'newWalletButton': {
			invokeTauriJs.createRandomWallet().then(
				result => {
					const privateKeyInput = document.getElementById('privateKeyInput');
					const walletInput = document.getElementById('walletInput');
					privateKeyInput.value = result[0];
					walletInput.value = result[1];

					const useWalletButton = document.getElementById('useWalletButton');
					const notUseWalletButton = document.getElementById('notUseWalletButton');
					useWalletButton.disabled = false;
					notUseWalletButton.disabled = false;
				}
			);
			break;
		}
		case 'gasPriceLabel': {
			getGasPrice();
		}
	}
}

async function listenContractEvents() {
	if (unlistenEventStart != null) {
		unlistenEventStart();
		unlistenEventStart = null;
	}
	invokeTauriJs.listenContractEvents('EventGambleStartedFilter', (event) => {
		showContractEvent(event);
	}).then(result => {
		unlistenEventStart = result;
	});

	if (unlistenEventAgainst != null) {
		unlistenEventAgainst();
		unlistenEventAgainst = null;
	}
	invokeTauriJs.listenContractEvents('EventGambleAgainstedFilter', (event) => {
		showContractEvent(event);
	}).then(result => {
		unlistenEventAgainst = result;
	});

	if (unlistenEventReveal != null) {
		unlistenEventReveal();
		unlistenEventReveal = null;
	}
	invokeTauriJs.listenContractEvents('EventGambleRevealedFilter', (event) => {
		showContractEvent(event);
	}).then(result => {
		unlistenEventReveal = result;
	});

	if (unlistenEventWithdraw != null) {
		unlistenEventWithdraw();
		unlistenEventWithdraw = null;
	}
	invokeTauriJs.listenContractEvents('EventGambleWithdrawedFilter', (event) => {
		showContractEvent(event);
	}).then(result => {
		unlistenEventWithdraw = result;
	});
}

function subscribeContractEvents(isQuiet) {
	const rpcUrl = document.getElementById(NodeUrlInputId).value;
	const contractAddress = document.getElementById('contractAddressInput').value;
	if (contractAddress.length > 0) {
		invokeTauriJs.subscribeEvent(rpcUrl, contractAddress).then(result => {
			if (result.length > 0 && !isQuiet) {
				alert(result);
			}
		});
	}
}

function getIndexOfGamebleArrayById(gambleId) {
	let index = gambleArray.length - 1; // 在当前的 gambleArray 中的序号
	for (let i = gambleArray.length - 1; i >= 0; i--) {
		const gamble = gambleArray[i];
		if (parseInt(gamble.id) === gambleId) {
			index = i;
			break;
		}
	}
	return index;
}

function getIdOfGamebleByIndex(index) {
	if (index < 0 || index >= gambleArray.length) {
		return undefined;
	} else {
		const gamble = gambleArray[index];
		return gamble.id;
	}
}

function verifyGamble() {
	if (verifyButton.innerText === '收起验证输赢') {
		verifyButton.innerText = '验证输赢';
		verifyResultLabel.innerText = '';
	} else {
		const rpcUrl = document.getElementById(NodeUrlInputId).value;
		const contractAddress = document.getElementById('contractAddressInput').value;
		const gamble = gambleArray[currentIndexOfGambles];
		const isOdd = gamble.is_odd;
		const isOddAgainst = gamble.is_odd_against;
		const secret = gamble.secret;
		const gambleKeccak256Result = gamble.keccak256_result;
		const verifyButton = document.getElementById('verifyButton');
		verifyButton.innerText = "正在验证开盘结果...";
		const verifyResultLabel = document.getElementById('verifyResultLabel');
		verifyResultLabel.innerText = '验证开盘结果：';
		invokeTauriJs.contractKeccak256OddSecret(rpcUrl, contractAddress, isOdd, secret).then(result => {
			if (result.reportStr.length > 0) {
				verifyButton.innerText = '验证输赢';
				alert('出错了：' + result.reportStr);
			} else {
				verifyButton.innerText = '收起验证输赢';
				verifyResultLabel.innerText = '验证开盘结果如下：\n开盘人选择了单双值和密码，用本地 keccak256 哈希值作为开局的盘口：';
				verifyResultLabel.innerText += '\n' + gambleKeccak256Result;
				verifyResultLabel.innerText += '\n开盘时给出的是 ' + (isOdd ? '单' : '双') + ' ，密码是：' + secret + '，';
				verifyResultLabel.innerText += '\n远程调用本合约的 keccak256 方法哈希值返回：';
				verifyResultLabel.innerText += '\n' + result.keccak256Str;
				if (gambleKeccak256Result === result.keccak256Str) {
					verifyResultLabel.innerText += '\n两个哈希值是一致的，所以认为开盘有效。';
					verifyResultLabel.innerText += '\n\n开盘时给出的是 ' + (isOdd ? '单' : '双') + '对局人选择的是：' + (isOddAgainst ? '单' : '双');
					if (isOddAgainst === isOdd) {
						verifyResultLabel.innerText += '\n对了，所以本次局，对局人赢了！';
					} else {
						verifyResultLabel.innerText += '\n错了，所以本次局，开局人赢了！';
					}
				} else {
					verifyResultLabel.innerText += '\n两个哈希值不一致，所以认为开盘是无效的，这个很严重的错误，请告知开发者。';
				}
			}
		});
	}
}

function revealGamble() {
	const gamble = gambleArray[currentIndexOfGambles];
	if (gamble === undefined || gamble === null) {
		alert("这个局数据有错，请重新选择");
	} else {
		const rpcUrl = document.getElementById(NodeUrlInputId).value;
		const walletPrivateKey = document.getElementById('privateKeyInput').value;
		const contractAddress = document.getElementById('contractAddressInput').value;
		const revealSecretInput = document.getElementById('revealSecretInput');
		const secretInputValue = revealSecretInput.value;
		if (rpcUrl.length === 0) {
			alert('请输入网址');
		} else if (walletPrivateKey.length === 0) {
			alert('请输入钱包密钥才能开新局');
		} else if (contractAddress.length === 0) {
			alert('请输入合约地址');
		} else if (secretInputValue.length === 0) {
			alert('请输入密码');
		} else if (secretInputValue.length < 6) {
			alert('密码长度必须大于6位，您可以点击按钮随机生成');
		} else {
			const revealButton = document.getElementById('revealButton');
			revealButton.innerText = "正在提交，请稍侯...";
			const isOdd = document.getElementById('revealOddOption').checked;
			const gambleId = gamble.id;
			invokeTauriJs.revealGamble(rpcUrl, walletPrivateKey, contractAddress, parseInt(gambleId), isOdd, secretInputValue, gamble.keccak256_result).then(result => {
				let reportStr = result.reportStr;
				if (reportStr === undefined || reportStr === null || reportStr.length === 0) {
					const errorMsg = result.feeWei;
					reportStr = "开盘：" + errorMsg;
					alert(reportStr);
				} else {
					const walletBanlance = document.getElementById('walletBanlance');
					walletBanlance.innerText = result.walletBalance + ' eth';
					const contractBalanceLabel = document.getElementById('contractBalanceLabel');
					contractBalanceLabel.innerText = '余额：' + result.contractBalance + ' eth';
					alert("开盘成功，看看是谁赢了？");
					clearPageButtons();
					getLatestGambles(1, false, false, parseInt(gambleId)); // 刷新
				}
				revealButton.innerText = "开盘";
				showReportString(reportStr);
			});
		}
	}
}

function againstGamble() {
	const gamble = gambleArray[currentIndexOfGambles];
	if (gamble === undefined || gamble === null) {
		alert("这个局数据有错，请重新选择");
	} else {
		const rpcUrl = document.getElementById(NodeUrlInputId).value;
		const walletPrivateKey = document.getElementById('privateKeyInput').value;
		const contractAddress = document.getElementById('contractAddressInput').value;
		if (rpcUrl.length === 0) {
			alert('请输入网址');
		} else if (walletPrivateKey.length === 0) {
			alert('请输入钱包密钥才能对局');
		} else if (contractAddress.length === 0) {
			alert('请输入合约地址');
		} else {
			const againstButton = document.getElementById('againstButton');
			againstButton.innerText = "正在提交，请稍侯...";
			const isOdd = document.getElementById('againstOddOption').checked;
			const gambleId = gamble.id;
			invokeTauriJs.againstGamble(rpcUrl, walletPrivateKey, contractAddress, parseInt(gambleId), gamble.bet_wei, isOdd).then(result => {
				let reportStr = result.reportStr;
				if (reportStr === undefined || reportStr === null || reportStr.length === 0) {
					const errorMsg = result.feeWei;
					reportStr = "对局：" + errorMsg;
					alert(reportStr);
				} else {
					const walletBanlance = document.getElementById('walletBanlance');
					walletBanlance.innerText = result.walletBalance + ' eth';
					const contractBalanceLabel = document.getElementById('contractBalanceLabel');
					contractBalanceLabel.innerText = '余额：' + result.contractBalance + ' eth';
					alert("对局成功，等待开局人开盘，祝您稳赢！");
					clearPageButtons();
					getLatestGambles(1, false, false, parseInt(gambleId));
				}
				againstButton.innerText = "对局";
				showReportString(reportStr);
				refreshWalletBalance();
			});
		}
	}
}

function withdrawGamble() {
	const gamble = gambleArray[currentIndexOfGambles];
	if (gamble === undefined || gamble === null) {
		alert("这个局数据有错，请重新选择");
	} else {
		const rpcUrl = document.getElementById(NodeUrlInputId).value;
		const walletPrivateKey = document.getElementById('privateKeyInput').value;
		const contractAddress = document.getElementById('contractAddressInput').value;
		if (rpcUrl.length === 0) {
			alert('请输入网址');
		} else if (walletPrivateKey.length === 0) {
			alert('请输入钱包密钥才能提现这个局');
		} else if (contractAddress.length === 0) {
			alert('请输入合约地址');
		} else {
			const withdrawButton = document.getElementById('withdrawButton');
			withdrawButton.innerText = "正在提现，请稍侯...";
			const gambleId = gamble.id;
			invokeTauriJs.withdrawGamble(rpcUrl, walletPrivateKey, contractAddress, parseInt(gamble.id)).then(result => {
				let reportStr = result.reportStr;
				if (reportStr === undefined || reportStr === null || reportStr.length === 0) {
					const errorMsg = result.feeWei;
					reportStr = "提现：" + errorMsg;
					alert(reportStr);
				} else {
					const walletBanlance = document.getElementById('walletBanlance');
					walletBanlance.innerText = result.walletBalance + ' eth';
					const contractBalanceLabel = document.getElementById('contractBalanceLabel');
					contractBalanceLabel.innerText = '余额：' + result.contractBalance + ' eth';
					alert("提现成功，检查你的余额看是否到账了。");
					clearPageButtons();
					getLatestGambles(1, false, false, parseInt(gambleId));
				}
				withdrawButton.innerText = "提现到我钱包";
				showReportString(reportStr);
				refreshWalletBalance();
			});
		}
	}
}

function getKeccak256OddSecretForReveal() {
	getKeccak256OddSecretFor('revealKeccak256Result', 'revealOddOption', 'revealSecretInput');
}

function getKeccak256OddSecret() {
	getKeccak256OddSecretFor('keccak256Result', 'oddOption', 'secretInput');
}

function getKeccak256OddSecretFor(keccak256ResultId, oddOptionId, secretInputId) {
	const keccak256Result = document.getElementById(keccak256ResultId);
	keccak256Result.innerText = '加密盘口：';
	const isOdd = document.getElementById(oddOptionId).checked;
	const secret = document.getElementById(secretInputId).value;
	if (secret.length > 0) {
		invokeTauriJs.localKeccak256OddSecretString(isOdd, secret).then(result => {
			keccak256Result.innerText += result;
		});
	}
}

function getBettingTimestamp() {
	const bettingTimeHour = document.getElementById('bettingTimeHourSelect').value;
	const bettingTimeMinute = document.getElementById('bettingTimeMinuteSelect').value;
	const bettingTimeSecond = document.getElementById('bettingTimeSecondSelect').value;
	// bettingTimeSecond * 1 才能转变成整数，否则就变成了字符串
	const timestamp = bettingTimeHour * 60 * 60 + bettingTimeMinute * 60 + bettingTimeSecond * 1;
	return timestamp;
}

function getRevealTimestamp() {
	const revealTimeHour = document.getElementById('revealTimeHourSelect').value;
	const revealTimeMinute = document.getElementById('revealTimeMinuteSelect').value;
	const revealTimeSecond = document.getElementById('revealTimeSecondSelect').value;
	// bettingTimeSecond * 1 才能转变成整数，否则就变成了字符串
	const timestamp = revealTimeHour * 60 * 60 + revealTimeMinute * 60 + revealTimeSecond * 1;
	return timestamp;
}

function initBettingAndRevealTimeSelect() {
	const bettingTimeHour = document.getElementById('bettingTimeHourSelect');
	const bettingTimeMinuteSelect = document.getElementById('bettingTimeMinuteSelect');
	const bettingTimeSecondSelect = document.getElementById('bettingTimeSecondSelect');
	const revealTimeHourSelect = document.getElementById('revealTimeHourSelect');
	const revealTimeMinuteSelect = document.getElementById('revealTimeMinuteSelect');
	const revealTimeSecondSelect = document.getElementById('revealTimeSecondSelect');

	for (let i = 0; i < 24; i++) {
		let option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		bettingTimeHour.appendChild(option);

		option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		revealTimeHourSelect.appendChild(option);
	}
	bettingTimeHour.value = 1;
	revealTimeHourSelect.value = 1;
	for (let i = 0; i < 60; i++) {
		let option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		bettingTimeMinuteSelect.appendChild(option);
		option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		bettingTimeSecondSelect.appendChild(option);

		option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		revealTimeMinuteSelect.appendChild(option);
		option = document.createElement('option');
		option.value = i;
		option.textContent = i;
		revealTimeSecondSelect.appendChild(option);
	}
}

function submitStartGamble() {
	const rpcUrl = document.getElementById(NodeUrlInputId).value;
	const walletPrivateKey = document.getElementById('privateKeyInput').value;
	const contractAddress = document.getElementById('contractAddressInput').value;
	const gambleBetInputWei = document.getElementById('gambleBetInputWei');
	const betWei = gambleBetInputWei.value;
	const isOdd = document.getElementById('oddOption').checked;
	const secretInput = document.getElementById('secretInput');
	const secretInputValue = secretInput.value;
	const bettingTime = getBettingTimestamp();
	const revealTime = getRevealTimestamp();
	if (betWei === undefined || betWei.length == 0 || betWei === 0) {
		alert('请输入金额的金额');
	} else if (rpcUrl.length === 0) {
		alert('请输入网址');
	} else if (walletPrivateKey.length === 0) {
		alert('请输入钱包密钥才能开新局');
	} else if (contractAddress.length === 0) {
		alert('请输入合约地址');
	} else if (secretInputValue.length === 0) {
		alert('请输入密码');
	} else if (secretInputValue.length < 6) {
		alert('密码长度必须大于6位，您可以点击按钮随机生成');
	} else if (bettingTime == 0) {
		alert('允许对局的时长不能为 0');
	} else if (revealTime == 0) {
		alert('允许开盘的时长不能为 0');
	} else {
		const submitButtonOfStartedGamble = document.getElementById('submitButtonOfStartedGamble');
		submitButtonOfStartedGamble.innerText = "正在提交，请等待...";
		invokeTauriJs.startGamble(rpcUrl, walletPrivateKey, contractAddress, betWei, isOdd, secretInputValue, bettingTime, revealTime).then(result => {
			let fee = result.feeWei;
			let reportStr = result.reportStr;
			if (fee.length === 0) { // 费用一般不会为 0
				const errorMsg = reportStr;
				reportStr = "提交：" + errorMsg;
				alert(reportStr);
			} else {
				const walletBanlance = document.getElementById('walletBanlance');
				walletBanlance.innerText = result.walletBalance + ' eth';
				const contractBalanceLabel = document.getElementById('contractBalanceLabel');
				contractBalanceLabel.innerText = '余额：' + result.contractBalance + ' eth';
				alert("完成提交，等待他来对局吧。");
				isShowingMyGambles = true;
				refreshContractContents();	// 显示在我的局里
			}
			showReportString(reportStr);
			submitButtonOfStartedGamble.innerText = "提交";
			refreshWalletBalance();
		});
	}
}

function showContractEvent(event) {
	const contractAddressPrefix = event.payload.contract_address_prefix;
	const gambleId = event.payload.gamble_id;
	const eventStr = event.payload.message;
	const eventList = document.getElementById('eventList');
	const now = new Date();
	const dateString = now.toLocaleString();

	const id = toEventListLableID(contractAddressPrefix, gambleId); // 用来获取这个 labe 组件
	const innerText = '---- ' + dateString + ' 事件：---- ' + eventStr.replace(/\n/g, '<br />').replace(/ {4}/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
	let child = document.createElement('br');
	eventList.insertBefore(child, eventList.firstChild);
	child = document.createElement('label');
	child.id = id;
	child.className = "labelInList";
	child.innerText = innerText;
	child.addEventListener('click', onEventListLableClicked);
	eventList.insertBefore(child, eventList.firstChild);
}

function toEventListLableID(contractAddressPrefix, gambleId) {
	const id = EventListLabelPrefix + '_' + contractAddressPrefix + '_' + gambleId;
	return id;
}

function fromEventListLableID(labelId) {
	const words = labelId.split('_');
	if (words.length == 3) {
		const contractAddressPrefix = words[1];
		const gambleId = words[2];
		return {
			contractAddressPrefix: contractAddressPrefix, gambleId: gambleId
		};
	}
	return (null, null);
}

function onEventListLableClicked(event) {
	const labelId = event.target.id;
	const words = fromEventListLableID(labelId);
	const contractAddressPrefix = words.contractAddressPrefix;
	const gambleId = words.gambleId;
	const contractSelect = document.getElementById('deployedContractAddressSelect').value;
	if (!contractSelect.startsWith(contractAddressPrefix)) {
		alert("该事件所属合约和当前选择的合约地址不一致，无法查看！");
	} else {
		clearPageButtons();
		getLatestGambles(1, false, false, parseInt(gambleId));
	}
}

function showReportString(reportStr) {
	const reportList = document.getElementById('reportList');
	const now = new Date();
	const dateString = now.toLocaleString();
	reportList.innerHTML = '<label>---- ' + dateString + ' ----<br />'
		+ reportStr.replace(/\n/g, '<br />').replace(/ {4}/g, '&nbsp;&nbsp;&nbsp;&nbsp;'); + '</label><br />'
			+ reportList.innerHTML;

}

function createRandomSecret(length) {
	const chars = "012ABCDEFGHIJKLMN345OPQRSTUVWXYZabcdefg678hijklmnopqrstuvwxyz9";
	let random = '';
	for (let i = 0; i < length; i++) {
		random += chars[Math.floor(Math.random() * chars.length)];
	}
	return random;
}

function gambleDetailsLabelClicked(event) {
	event.preventDefault();

	const id = event.target.id.replace(GambleDetailsLabelPrefix, '');
	let index = getIndexOfGamebleArrayById(parseInt(id));
	showGambleDetails(index, false);
}

function showVerifyAction(gamble) {
	const verifyAction = document.getElementById('verifyAction');
	verifyAction.style.display = "none";
	if (gamble.secret.length > 0) {	// 有密码说明已经开盘
		verifyAction.style.display = 'block';
		const verifyButton = document.getElementById('verifyButton');
		verifyButton.innerText = "验证输赢";
		verifyResultLabel.innerText = "";
	}
}

function showWithdrawButton(gamble) {
	const walletInput = document.getElementById('walletInput');
	const walletAddress = walletInput.value.toLowerCase();
	const now = new Date();
	const nowTimestamp = now.getTime();
	let betAmount = removeUnitOfMoney(gamble.bet_amount);

	const withdrawButton = document.getElementById('withdrawButton');
	withdrawButton.style.display = "none";
	if (betAmount > 0) {
		if (gamble.starter === walletAddress) {	// 我开的局
			if (gamble.againster === NullAdress) { // 未有人对局
				withdrawButton.style.display = "block";
				if (nowTimestamp >= gamble.reveal_end * 1000) {	// 超过了开盘时间，利益归对局人
					gambleDetailsTitle.innerText += "\n已过开盘截止时间，局结束，请拿回您的金额。";
				} else {
					gambleDetailsTitle.innerText += "\n暂时没人和您对局，你可以随时拿回金额。";
				}
			} else if (gamble.secret.length === 0) { // 有人对局，但还没有开盘
				if (nowTimestamp >= gamble.reveal_end * 1000) {	// 超过了开盘时间，利益归对局人
					gambleDetailsTitle.innerText += "\n有人对局了，因您错过了开盘时间，所有金额都归对局人了。";
				} else {
					gambleDetailsTitle.innerText += "\n有人对局了，请先开盘，若错过了开盘时间，所有金额都归对局人。";
				}
			} else if (gamble.is_odd != gamble.is_odd_against) { // 有人对局，已经开盘，对局人押错了，我是开局人可以提现
				gambleDetailsTitle.innerText += "\n有人对局，但错了，欢迎提现！";
				withdrawButton.style.display = "block";
			}
		} else if (gamble.againster === walletAddress) {	// 我是对局人
			if (gamble.secret.length === 0) { // 有人对局，但还没有开盘
				if (nowTimestamp < gamble.reveal_end * 1000) {	// 还没到开盘时间
					gambleDetailsTitle.innerText += "\n您对局，如果开盘人错过了开盘时间，所有金额将归您。";
				} else {
					gambleDetailsTitle.innerText += "\n您对局，开盘人已错过开盘时间，所有金额都归您，请领取所有金额。";
					withdrawButton.style.display = "block";
				}
			} else if (gamble.is_odd === gamble.is_odd_against) { // 已经开盘，我是对局人，我对了，可以提现
				gambleDetailsTitle.innerText += "\n恭喜您对了，欢迎提现！";
				withdrawButton.style.display = "block";
			}
		} else { // 这个钱包不参与此局，所以没有提现按钮
			if (nowTimestamp >= gamble.reveal_end * 1000) {
				gambleDetailsTitle.innerText += "\n已过开盘截止时间，局结束。";
			} else if (nowTimestamp < gamble.bet_end * 1000) {	// 时间在对局截止日期前
				gambleDetailsTitle.innerText += "\n对局还未截止，让我们逐鹿中原！";
			} else if (gamble.againster != NullAdress // 有人对局
				&& gamble.secret.length === 0) // 还没有开盘
			{
				gambleDetailsTitle.innerText += "\n已过对局截止时间，还未开盘，坐看鹿死谁手！";
			}
		}
	}
}

function showRevealSection(gamble) {
	const walletInput = document.getElementById('walletInput');
	const walletAddress = walletInput.value.toLowerCase();
	const now = new Date();
	const nowTimestamp = now.getTime();
	let betAmount = removeUnitOfMoney(gamble.bet_amount);

	const revealOddOption = document.getElementById('revealOddOption');
	revealOddOption.checked = true;
	const revealSecretInput = document.getElementById('revealSecretInput');
	revealSecretInput.value = '';
	const revealKeccak256Result = document.getElementById('revealKeccak256Result');
	revealKeccak256Result.innerText = '加密盘口：';
	const revealAction = document.getElementById('revealAction');
	revealAction.style.display = "none";
	if (gamble.starter === walletAddress  // 自己是开局人
		&& gamble.againster != NullAdress // 已经有人对局了
		&& nowTimestamp < gamble.reveal_end * 1000// 时间在开盘截止日期前
		&& betAmount > 0  // 全部金额没有被领走，若已领走，在 showWithdrawButton 函数会添加文字的
		&& gamble.secret.length == 0) // 还没有开盘
	{
		revealAction.style.display = "grid";
	}
}

function showAgainstSection(gamble) {
	const walletInput = document.getElementById('walletInput');
	const walletAddress = walletInput.value.toLowerCase();
	const now = new Date();
	const nowTimestamp = now.getTime();
	let betAmount = removeUnitOfMoney(gamble.bet_amount);

	const againstOddOption = document.getElementById('againstOddOption');
	againstOddOption.checked = true;
	const againstEvenOption = document.getElementById('againstEvenOption');
	againstEvenOption.checked = false;
	const againstAction = document.getElementById('againstAction');
	againstAction.style.display = "none";
	if (betAmount <= 0) { // // 全部金额被领走
		gambleDetailsTitle.innerText += "\n总金额已被领走，局结束！";
	} else if (gamble.againster != NullAdress) { // 未有人对局
		gambleDetailsTitle.innerText += "\n对局人：" + gamble.againster;
	} else if (nowTimestamp >= gamble.bet_end * 1000) {	// 时间在对局截止日期前
		gambleDetailsTitle.innerText += "\n对局截止时间已过";
	} else if (gamble.starter != walletAddress) { // 自己不和自己对局
		againstAction.style.display = "grid";
	}
}

function removeUnitOfMoney(money) {
	let moneyResult = money.replace(" wei", "");
	moneyResult = moneyResult.replace(" eth", "");
	moneyResult = parseFloat(moneyResult);
	return moneyResult;
}

function showLatestGambles(isQuiet, isMyGambles) {
	isShowingMyGambles = isMyGambles;
	currentIndexOfGambles = 0;
	getLatestGambles(GetGamblesCount, isQuiet, isMyGambles, undefined);
}

function showLatestGamblesFrom(isQuiet, isNextPage) { // 返回可否前翻或后翻一页
	if (gambleArray.length == 0) { // 没有现有数据，得不到gamble id，无从翻页
		showLatestGambles(isQuiet, isShowingMyGambles);
	} else {
		if (isNextPage) {
			const gamble = gambleArray[0];
			fromIndex = gamble.id + count;
		}
		if (fromIndex < 0) {
		} else {
			getLatestGambles(GetGamblesCount, isQuiet, isMyGambles, fromIndex);
		}
	}
}

function getLatestGambles(count, isQuiet, isMyGambles, fromIndex) {
	clearGambleList();
	clearGambleDetails();
	const rpcUrl = document.getElementById(NodeUrlInputId).value;
	const contractAddress = document.getElementById('deployedContractAddressSelect').value;
	const walletAddress = document.getElementById('walletInput').value;
	if (count == 0) {
		if (!isQuiet) alert('获取 0 个局没有意义。');
	} else if (rpcUrl.length === 0) {
		if (!isQuiet) alert('请输入节点网址。');
	} else if (contractAddress.length === 0) {
		if (!isQuiet) alert('请输入合约地址。');
	} else {
		const gambleListTitle = document.getElementById('gambleListTitle');
		gambleListTitle.innerText = "正在获取...";
		isShowingMyGambles = isMyGambles;
		if (isMyGambles) { // 显示我的局列表			
			if (walletAddress.length === 0) {
				if (!isQuiet) alert('请输入钱包地址。');
			} else {
				if (fromIndex != null && fromIndex != undefined) { // 说明要翻页
					invokeTauriJs.batchGetContractMyGambles(rpcUrl, contractAddress, walletAddress, fromIndex, count).then(result => {
						handleGetLatestGamblesResult(result, isQuiet);
					});
				} else {
					invokeTauriJs.getMyLatestGambles(rpcUrl, contractAddress, count, walletAddress).then(result => {
						currentPageIndexOfGambles = Math.floor(result.gamblesAmount / GetGamblesCount); // 等于最后一页
						if (currentPageIndexOfGambles * GetGamblesCount < result.gamblesAmount) {
							currentPageIndexOfGambles++;
						}
						handleGetLatestGamblesResult(result, isQuiet);
					});
				}
			}
		} else {
			if (fromIndex != null && fromIndex != undefined) { // 说明要翻页
				invokeTauriJs.batchGetContractGambles(rpcUrl, contractAddress, fromIndex, count).then(result => {
					handleGetLatestGamblesResult(result, isQuiet);
				});
			} else {
				invokeTauriJs.getLatestGambles(rpcUrl, contractAddress, count).then(result => {
					currentPageIndexOfGambles = Math.floor(result.gamblesAmount / GetGamblesCount); // 等于最后一页
					if (currentPageIndexOfGambles * GetGamblesCount < result.gamblesAmount) {
						currentPageIndexOfGambles++;
					}
					handleGetLatestGamblesResult(result, isQuiet);
				});
			}
		}
	}
}
function clearPageButtons() {
	const pageLabel = document.getElementById('pageLabel');
	pageLabel.innerText = "";
	const previousPageButton = document.getElementById('previousPageButton');
	previousPageButton.disabled = true;
}

function showPageButtons() {
	let pageAmount = 0;
	if (isShowingMyGambles) {
		pageAmount = Math.floor(myGamblesAmount / GetGamblesCount);
		if (pageAmount * GetGamblesCount < myGamblesAmount) {
			pageAmount++;
		}
	} else {
		pageAmount = Math.floor(gamblesAmount / GetGamblesCount);
		if (pageAmount * GetGamblesCount < gamblesAmount) {
			pageAmount++;
		}
	}
	const pageLabel = document.getElementById('pageLabel');
	pageLabel.innerText = "第 " + currentPageIndexOfGambles + " / " + pageAmount + ' 页';
	const previousPageButton = document.getElementById('previousPageButton');
	if (currentPageIndexOfGambles <= 1) {
		previousPageButton.disabled = true;
	} else {
		previousPageButton.disabled = false;
	}
}

function handleGetLatestGamblesResult(result, isQuiet) {
	const gambleListTitle = document.getElementById('gambleListTitle');
	if (result.errorMsg.length > 0) {
		gambleListTitle.innerText = "出错了：" + result.errorMsg;
	} else {
		gambleArray = result.gambles;
		if (isShowingMyGambles) {
			myGamblesAmount = result.gamblesAmount;
		} else {
			gamblesAmount = result.gamblesAmount;
		}
		if (result.gamblesAmount == 0) {
			currentIndexOfGambles = 0;
		}
	}
	showGambleList();
	showGambleDetails(0, isQuiet);
	showPageButtons();
}

function clearGambleDetails() {
	const gambleDetailsTitle = document.getElementById('gambleDetailsTitle');
	gambleDetailsTitle.innerText = '局详情';
	const againstAction = document.getElementById('againstAction');
	againstAction.style.display = 'none';
	const revealAction = document.getElementById('revealAction');
	revealAction.style.display = 'none';
	const withdrawButton = document.getElementById('withdrawButton');
	withdrawButton.style.display = 'none';
	const verifyAction = document.getElementById('verifyAction');
	verifyAction.style.display = 'none';
}

// 右边显示局的详情
function showGambleDetails(index, isQuitet) {
	clearGambleDetails();
	if (index < 0 || index >= gambleArray.length) {
		if (!isQuitet && gambleArray.length > 0) {
			alert("指定局的序号超出了列表的范围");
		}
	} else {
		let gambleId = getIdOfGamebleByIndex(currentIndexOfGambles);
		let gambleDetailsLabelId = GambleDetailsLabelPrefix + gambleId;
		let gambleDetailsLabel = document.getElementById(gambleDetailsLabelId);
		if (gambleDetailsLabel != undefined && gambleDetailsLabel != null) {
			gambleDetailsLabel.style.border = "";
		}
		let gamble = gambleArray[index];
		gambleId = gamble.id;
		gambleDetailsLabelId = GambleDetailsLabelPrefix + gambleId;
		gambleDetailsLabel = document.getElementById(gambleDetailsLabelId);
		if (gambleDetailsLabel != undefined && gambleDetailsLabel != null) {
			gambleDetailsLabel.style.border = "1px solid blue";
		}
		currentIndexOfGambles = index;
		const gambleDetailsTitle = document.getElementById('gambleDetailsTitle');
		let date = new Date(gamble.bet_end * 1000);
		const betEnd = date.toLocaleString();
		date = new Date(gamble.reveal_end * 1000);
		const revealEnd = date.toLocaleString();
		gambleId = parseInt(gamble.id) + 1; // 显示要大一个，因为 gamble id 是从 0 开始
		gambleDetailsTitle.innerText = '第 ' + gambleId + ' 局'
			+ '\t\t开局钱包：' + gamble.starter + '，\n盘口：' + gamble.keccak256_result
			+ '，\n金额：' + gamble.bet + '，对局截止日期：' + betEnd
			+ ",\n开盘截止时间是：" + revealEnd;

		showAgainstSection(gamble);
		showRevealSection(gamble);
		showWithdrawButton(gamble);
		showVerifyAction(gamble);
	}
}

function showGambleList() {
	const gambleListTitle = document.getElementById('gambleListTitle');
	const walletInput = document.getElementById('walletInput');
	const walletAddress = walletInput.value.toLowerCase();
	const now = new Date();
	const nowTimestamp = now.getTime();
	if (isShowingMyGambles) {
		gambleListTitle.innerText = '我参与了 ' + myGamblesAmount + ' 个局';
	} else {
		gambleListTitle.innerText = '总共 ' + gamblesAmount + ' 个局';
	}
	const gambleList = document.getElementById('gambleList');
	gambleList.innerHTML = '';
	for (let index = 0; index < gambleArray.length; index++) {
		const gamble = gambleArray[index];
		const child = document.createElement('p');
		child.id = GambleDetailsLabelPrefix + gamble.id; // 用来获取这个 labe 组件
		const gambleId = parseInt(gamble.id) + 1;
		const date = new Date(gamble.bet_end * 1000);
		child.innerText = '第 ' + gambleId + ' 局' + '：金额 ' + gamble.bet;

		let status = '';
		const betAmount = removeUnitOfMoney(gamble.bet_amount);
		if (gamble.starter === walletAddress) {
			status = ' --- 我开局';
		} else if (gamble.againster === walletAddress) {
			status = ' --- 我对局';
		}
		if (betAmount <= 0) { // // 全部金额被领走
			status += "\n总金额已被领走，局结束！";
		} else if (gamble.secret.length > 0) { // 已开局
			status += '\n已经开局，';
			if (gamble.is_odd == gamble.is_odd_against) {
				status += '对局人对了，所有金额归对局人';
			} else {
				status += '对局人错了，所有金额归开局人';
			}
		} else if (gamble.againster === NullAdress) { // 没有人对局
			status += "\n还没人对局，";
			if (nowTimestamp > gamble.reveal_end * 1000) {	// 时间在开盘截止日期之后
				status += "开局时间已过，局结束";
			} else if (nowTimestamp > gamble.bet_end * 1000) {
				status += "对局时间已过，局结束";
			} else {
				status += " 快来对局！";
			}
		} else if (nowTimestamp > gamble.reveal_end * 1000) {	// 时间在开盘截止日期之后
			status += "\n开局时间已过，所有金额归对局人，局结束";
		} else { // 有人对局，还没有过开局时间
			status += "\n静静等待开盘那个高光时刻！";
		}
		child.innerText += status;
		child.addEventListener('click', gambleDetailsLabelClicked);
		gambleList.appendChild(child);
	}
}

function clearGambleList() {
	const gambleListTitle = document.getElementById('gambleListTitle');
	gambleListTitle.innerText = "所有局";
	const gambleList = document.getElementById('gambleList');
	gambleList.innerHTML = '';
	const pageLabel = document.getElementById('pageLabel');
	pageLabel.innerText = "";
}

function startGamble() {
	showGambleSection('startGambleSection');
	const walletInput = document.getElementById('walletInput');
	const starterAddressLabel = document.getElementById('starterAddressLabel');
	starterAddressLabel.innerText = "开局钱包：" + walletInput.value;
	const rpc_url = document.getElementById(NodeUrlInputId).value;
	const wallet_address = document.getElementById('walletSelect').value;
	invokeTauriJs.getWalletBalance(rpc_url, wallet_address).then(
		result => {
			if (result.includes("Connection refused")) {
				starterAddressLabel.innerText += '连接服务器失败：' + rpc_url;
			} else if (result.includes("ens name not found")) {
				starterAddressLabel.innerText += ' 该钱包没有余额记录'
			} else {
				starterAddressLabel.innerText += ' 余额：' + result;
			}
		}
	);

	document.getElementById('gambleBetInputWei').value = "";
	document.getElementById('gambleBetInputEth').value = "";
	document.getElementById('oddOption').checked = true;
	document.getElementById('secretInput').value = '';
	document.getElementById('bettingTimeHourSelect').value = '1';
	document.getElementById('bettingTimeMinuteSelect').value = '0';
	document.getElementById('bettingTimeSecondSelect').value = '0';
	document.getElementById('revealTimeHourSelect').value = '1';
	document.getElementById('revealTimeMinuteSelect').value = '0';
	document.getElementById('revealTimeSecondSelect').value = '0';
}

function showGambleSection(whichOne) {
	const startGambleSection = document.getElementById('startGambleSection');
	startGambleSection.style.display = 'none';
	const gambleListAndDetailsSection = document.getElementById('gambleListAndDetailsSection');
	gambleListAndDetailsSection.style.display = 'none';
	if (whichOne === 'startGambleSection') {
		startGambleSection.style.display = 'grid';
	} else if (whichOne === 'gambleListAndDetailsSection') {
		gambleListAndDetailsSection.style.display = 'grid';
	}
}

function refreshContractContents() {
	showGambleSection('gambleListAndDetailsSection');
	reloadDeployedContractAddressSelectFromLocalStorage();
	const deployedContractAddressSelect = document.getElementById(DeployedContractAddressSelectId);
	const contractAddressInput = document.getElementById('contractAddressInput');
	if (deployedContractAddressSelect.children.length > 0) {
		refreshContractBalance();
		refreshContractVersion();
		contractAddressInput.value = deployedContractAddressSelect.value;
	} else {
		contractAddressInput.value = '';
	}
	showLatestGambles(true, isShowingMyGambles);
	subscribeContractEvents(true);
}

function refreshContractVersion() {
	const rpcUrl = document.getElementById(NodeUrlInputId).value;
	const contractAddress = document.getElementById('deployedContractAddressSelect').value;
	contractVersionLabel.innerText = '版本：';
	if (rpcUrl.length === 0) {
		alert('请先输入节点网址');
	} else if (contractAddress.length === 0) {
		alert('请先输入一个合约');
	} else {
		const contractVersionLabel = document.getElementById('contractVersionLabel');
		contractVersionLabel.innerText = "正在查询...";
		invokeTauriJs.getContractVersion(rpcUrl, contractAddress).then(result => {
			if (result.errorMsg.length > 0) {
				if (result.errorMsg.includes("Connection refused")) {
					contractVersionLabel.innerText = '连接服务器失败：' + rpcUrl;
				} else if (result.errorMsg.includes("ens name not found")) {
					contractVersionLabel.innerText = '该合约地址无效'
				} else {
					contractVersionLabel.innerText = result.errorMsg;
				}
			} else {
				contractVersionLabel.innerText = '版本：' + result.contractVersion;
				const appVersionLabel = document.getElementById('appVersionLabel');
				if (appVersionLabel != null && appVersionLabel != undefined) { // 有可能被删掉
					appVersionLabel.innerText = '本应用的版本是：' + result.appVersion;
				}
				if (result.contractVersion != result.appVersion) {
					alert('合约版本和本应用的版本不一致，可能导致操作失败！');
				}
			}
		});
	}
}

// todo: 不需要钱包地址就能查阅合约的 get 方法？
function refreshContractBalance() {
	const rpcUrl = document.getElementById(NodeUrlInputId).value;
	const contractAddress = document.getElementById('deployedContractAddressSelect').value;
	if (rpcUrl.length === 0) {
		alert('请先输入节点网址');
	} else if (contractAddress.length === 0) {
		alert('请先输入一个合约');
	} else {
		const contractBalanceLabel = document.getElementById('contractBalanceLabel');
		contractBalanceLabel.innerText = "正在查询...";
		invokeTauriJs.getContractBalance(rpcUrl, contractAddress).then(result => {
			if (result.includes("Connection refused")) {
				contractBalanceLabel.innerText = '连接服务器失败：' + rpcUrl;
			} else if (result.includes("ens name not found")) {
				contractBalanceLabel.innerText = '该合约没有余额记录'
			} else {
				contractBalanceLabel.innerText = '余额：' + result;
			}
		});
	}
}

function removeCurrentContractAddress() {
	const contractBalanceLabel = document.getElementById('contractBalanceLabel');
	contractBalanceLabel.innerText = '余额：';
	const contractVersionLabel = document.getElementById('contractVersionLabel');
	contractVersionLabel.innerText = '版本：';
	const contractSelect = document.getElementById(DeployedContractAddressSelectId);
	const contractAddress = contractSelect.value;
	removeValueToListByLocalStorage(contractAddress, DeployedContractAddressSelectId);
	invokeTauriJs.unsubscribeEvent(contractAddress).then(result => { }); // 删掉了就不侦听这个合约的事件了
	refreshContractContents();
}

function deployContract() {
	const rpc_url = document.getElementById(NodeUrlInputId).value;
	const wallet_private_key = document.getElementById('privateKeyInput').value;
	if (wallet_private_key.length === 0) {
		alert("请在密钥输入框内输入密钥");
	} else {
		alert("请稍候片刻，正在部署合约");
		const contractVersionLabel = document.getElementById('contractVersionLabel');
		contractVersionLabel.innerText = "版本：";
		const deployContractButton = document.getElementById('deployContractButton');
		deployContractButton.innerText = "正在部署合约...";
		invokeTauriJs.deployContract(rpc_url, wallet_private_key).then(
			result => {
				const deployContractButton = document.getElementById('deployContractButton');
				deployContractButton.innerText = "部署合约";
				if (result.contractAddress.length == 0 && result.gasUsage.length == 0) {	// 0 代表出错了
					alert("部署合约出错了：" + result.reportStr);
				} else {
					const deployContractGasLabel = document.getElementById('deployContractGasLabel');
					deployContractGasLabel.innerText = "实际消耗:" + result.gasUsage;
					alert("成功部署合约，请留意合约的版本号，地址为：" + result.contractAddress);
					showReportString(result.reportStr);
					saveValueToListByLocalStorage(result.contractAddress, DeployedContractAddressSelectId);
					refreshContractContents();
				}
			}
		);
	}
}

function reloadDeployedContractAddressSelectFromLocalStorage() {
	const contractSelect = document.getElementById(DeployedContractAddressSelectId);
	contractSelect.innerHTML = '';	// 删除 <select> 元素中的所有 <option> 子元素
	const removeContractAddressButton = document.getElementById('removeContractAddressButton');
	removeContractAddressButton.disabled = true;
	let selectedIndex = localStorage.getItem(DeployedContractAddressSelectIndex);
	localStorage.removeItem(DeployedContractAddressSelectIndex); // 先删除掉，里面再保存
	const myListJson = localStorage.getItem(DeployedContractAddressSelectId);
	if (myListJson != null) {
		const myList = JSON.parse(myListJson);
		if (myList && myList.length > 0) {
			myList.forEach(element => {
				const option = document.createElement('option');
				option.value = element;
				option.textContent = element;
				contractSelect.appendChild(option);
			});
			if (selectedIndex === null || selectedIndex >= myList.length) {
				selectedIndex = 0;
			}
			contractSelect.selectedIndex = selectedIndex;
			localStorage.setItem(DeployedContractAddressSelectIndex, selectedIndex);
			removeContractAddressButton.disabled = false;
		}
	}
}

function saveValueToListByLocalStorage(itemValue, itemListId) {
	if (itemValue.length > 0) {
		let myListNew = [itemValue];
		const myListJson = localStorage.getItem(itemListId);
		if (myListJson != null) {
			const myList = JSON.parse(myListJson);
			if (myList && myList.length > 0) {
				let index = myList.indexOf(itemValue);
				if (index > -1) {
					myList.splice(index, 1);
				}
				if (myList.length > 0) {
					myListNew = myListNew.concat(myList);
				}
			}
		}
		localStorage.setItem(itemListId, JSON.stringify(myListNew));
		localStorage.setItem(DeployedContractAddressSelectIndex, 0); // 指向新增的，或移动到第一位的
	}
}

function removeValueToListByLocalStorage(itemValue, itemListId) {
	const myListJson = localStorage.getItem(itemListId);
	if (myListJson != null) {
		const myList = JSON.parse(myListJson);
		if (myList && myList.length > 0) {
			let index = myList.indexOf(itemValue);
			if (index > -1) {
				myList.splice(index, 1);
			}
		}
		if (myList && myList.length > 0) {
			localStorage.setItem(itemListId, JSON.stringify(myList));
			localStorage.setItem(DeployedContractAddressSelectIndex, 0); // 删掉了就用第一个
		} else {
			localStorage.removeItem(itemListId);
			localStorage.removeItem(DeployedContractAddressSelectIndex);
		}
	}
}

function getDeployContractEstimateGas() {
	const rpc_url = document.getElementById(NodeUrlInputId).value;
	invokeTauriJs.getDeployContractEstimateGas(rpc_url).then(
		result => {
			const deployContractEstimateGasLabel = document.getElementById('deployContractEstimateGasLabel');
			if (result.reportStr.length > 0) {
				deployContractEstimateGasLabel.innerText = '预计失败：' + result.reportStr;
			} else {
				deployContractEstimateGasLabel.innerText = '部署预计消耗：' + result.estimateGas;
			}
		}
	);
}

function showContractSourceCodeButtonClicked(event) {
	tauri.shell.open('showContractSourceCode.html');
}

function reloadWalletSelectFromLocalStorage() {
	const walletSelect = document.getElementById('walletSelect');
	let myWalletOptgroup = document.getElementById(MyWalletOptgroupId);
	if (myWalletOptgroup != null && myWalletOptgroup != undefined) {
		walletSelect.removeChild(myWalletOptgroup);
	}
	const myWalletListJson = localStorage.getItem(MyWalletOptgroupId);
	if (myWalletListJson != null) {
		const myWalletList = JSON.parse(myWalletListJson);
		if (myWalletList && myWalletList.length > 0) {
			myWalletOptgroup = document.createElement('optgroup');
			myWalletOptgroup.label = "我的钱包";
			myWalletOptgroup.id = MyWalletOptgroupId;
			myWalletList.forEach(element => {
				const option = document.createElement('option');
				option.value = element;
				option.textContent = element;
				myWalletOptgroup.appendChild(option);
			});
			const firstOptgroup = walletSelect.firstChild;
			walletSelect.insertBefore(myWalletOptgroup, firstOptgroup);
		}
	}
}

function refreshWalletBalance() {
	const rpc_url = document.getElementById(NodeUrlInputId).value;
	const walletAddress = document.getElementById('walletSelect').value;
	invokeTauriJs.getWalletBalance(rpc_url, walletAddress).then(
		result => {
			const walletBanlance = document.getElementById('walletBanlance');
			if (result.includes("Connection refused")) {
				walletBanlance.innerText = '连接服务器失败：' + rpc_url;
			} else if (result.includes("ens name not found")) {
				walletBanlance.innerText = '该钱包没有余额记录'
			} else {
				walletBanlance.innerText = '余额：' + result;
			}
		}
	);
	const walletInput = document.getElementById('walletInput');
	walletInput.value = walletAddress;
	const privateKeyInput = document.getElementById('privateKeyInput');
	const testWalletAndPrivateKey = TestWalletAndPrivateKey[walletAddress];
	if (testWalletAndPrivateKey != undefined) {
		privateKeyInput.value = testWalletAndPrivateKey;
	} else {
		let savePrivateKey = localStorage.getItem(walletAddress);
		privateKeyInput.value = (savePrivateKey === null || savePrivateKey === undefined) ? '' : savePrivateKey;
	}
	let isMyWallet = false;
	const myWalletOptgroup = document.getElementById(MyWalletOptgroupId);
	if (myWalletOptgroup != null) {
		for (const child of myWalletOptgroup.children) {
			if (child.nodeName === "OPTION" && child.value === walletAddress) {
				isMyWallet = true;
				break;
			}
		}
	}
	const useWalletButton = document.getElementById('useWalletButton');
	const notUseWalletButton = document.getElementById('notUseWalletButton');
	useWalletButton.disabled = !isMyWallet;
	notUseWalletButton.disabled = !isMyWallet;
}

function getGasPrice() {
	const nodeUrlInput = document.getElementById(NodeUrlInputId);
	const gasPriceLabel = document.getElementById('gasPriceLabel');
	const rpcUrl = nodeUrlInput.value;
	if (rpcUrl.length > 0) {
		invokeTauriJs.getGasPrice(rpcUrl).then(result => {
			if (result.reportStr.length > 0) {
				gasPriceLabel.innerText = "获取失败：" + result.reportStr;
			} else {
				gasPriceLabel.innerText = "Gas 价格：" + result.gasPriceEth;
			}
		});
	} else {
		gasPriceLabel.innerText = "Gas 价格：";
	}
}